"""
NexaChat Status screen (v11)
============================
    StatusShell   story list (left) + inline story viewer / empty state (right)
    StoryRows     "My status" card + recent updates with segmented story rings
    StoryPane     empty state, or the story viewer (progress bars, auto-advance, tap / hold, views, delete)

UI only. The application supplies data (plain dicts) and callbacks:

    stories = list of dict(id, uid, own, type 'text'|'image', content, path, bg, size, created, name, dp, views)
"""
import os
import tkinter as tk
from datetime import datetime
from PIL import Image, ImageDraw, ImageFilter, ImageTk

from fx import mix, hex_rgb
from fxkit import FONT, card_image, pill_image
from ui_components import get_icon
from chat_fx import Base, LIST_W, font, fit, av_colors, wheel_units, thumb_image

STORY_SECONDS = {"text": 5.0, "image": 6.5}


# ------------------------------------------------------------------ helpers
def ago(ts):
    try:
        t = datetime.strptime(str(ts)[:19], "%Y-%m-%d %H:%M:%S")
    except Exception:
        return ""
    secs = (datetime.now() - t).total_seconds()
    if secs < 60:
        return "Just now"
    if secs < 3600:
        return "%d min ago" % (secs // 60)
    if t.date() == datetime.now().date():
        return "Today, " + t.strftime("%I:%M %p").lstrip("0")
    return "Yesterday, " + t.strftime("%I:%M %p").lstrip("0")


_rings = {}


def story_ring(size, total, active, c1, c2, grey, w=3):
    """Segmented story ring: `total` arcs, the last `active` are gradient-coloured, the rest grey."""
    key = (size, total, active, c1, c2, grey, w)
    if key in _rings:
        return _rings[key]
    S = 3
    N = size * S
    mask_a = Image.new("L", (N, N), 0)
    mask_g = Image.new("L", (N, N), 0)
    da, dg = ImageDraw.Draw(mask_a), ImageDraw.Draw(mask_g)
    box = [w * S // 2, w * S // 2, N - w * S // 2 - 1, N - w * S // 2 - 1]
    total = max(1, min(total, 14))
    gap = 0 if total == 1 else 9
    for i in range(total):
        s = -90 + i * 360.0 / total + gap / 2.0
        e = -90 + (i + 1) * 360.0 / total - gap / 2.0
        grey_seg = i < (total - min(active, total))
        (dg if grey_seg else da).arc(box, s, e, fill=255, width=w * S)
    g = Image.linear_gradient("L").rotate(45).resize((N, N))
    grad = Image.composite(Image.new("RGB", (N, N), hex_rgb(c2)), Image.new("RGB", (N, N), hex_rgb(c1)), g)
    out = Image.new("RGBA", (N, N), (0, 0, 0, 0))
    out.paste(grad, (0, 0), mask_a)
    out.paste(Image.new("RGB", (N, N), hex_rgb(grey)), (0, 0), mask_g)
    ph = ImageTk.PhotoImage(out.resize((size, size), Image.LANCZOS))
    if len(_rings) > 200:
        _rings.clear()
    _rings[key] = ph
    return ph


_misc = {}


def _cache(key, build):
    if key not in _misc:
        if len(_misc) > 60:
            _misc.clear()
        _misc[key] = build()
    return _misc[key]


def story_backdrop(W, H, color):
    W, H = int(W), int(H)

    def build():
        top, bot = mix("#05070F", color, 0.16), mix("#05070F", color, 0.04)
        g = Image.linear_gradient("L").resize((W, H))
        base = Image.composite(Image.new("RGB", (W, H), hex_rgb(bot)), Image.new("RGB", (W, H), hex_rgb(top)), g)
        blob = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        ImageDraw.Draw(blob).ellipse([W * 0.2, H * 0.12, W * 0.8, H * 0.88], fill=hex_rgb(color) + (95,))
        out = base.convert("RGBA")
        out.alpha_composite(blob.filter(ImageFilter.GaussianBlur(120)))
        return ImageTk.PhotoImage(out.convert("RGB"))
    return _cache(("bd", W, H, color), build)


def story_shade(w, h, r=26, top_h=120, bot_h=140):
    """Dark top and bottom gradients for legibility, clipped to the card's rounded corners."""
    w, h = int(w), int(h)

    def build():
        ov = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        px = ov.load()
        for y in range(h):
            a = 0
            if y < top_h:
                t = 1 - y / float(top_h)
                a = int(150 * t * t)
            elif y > h - bot_h:
                t = (y - (h - bot_h)) / float(bot_h)
                a = int(175 * t * t)
            if a:
                for x in range(w):
                    px[x, y] = (0, 0, 0, a)
        S = 3
        mask = Image.new("L", (w * S, h * S), 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, w * S - 1, h * S - 1], r * S, fill=255)
        mask = mask.resize((w, h), Image.LANCZOS)
        alpha = Image.new("L", (w, h), 0)
        alpha.paste(ov.getchannel("A"), (0, 0), mask)
        ov.putalpha(alpha)
        return ImageTk.PhotoImage(ov)
    return _cache(("shade2", w, h, r), build)


def fit_image(path, bw, bh, radius=18):
    try:
        mt = os.path.getmtime(path)
    except OSError:
        return None

    def build():
        im = Image.open(path).convert("RGB")
        im.thumbnail((max(1, int(bw)), max(1, int(bh))), Image.LANCZOS)
        S = 3
        big = im.resize((im.width * S, im.height * S), Image.LANCZOS)
        mask = Image.new("L", big.size, 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, big.width - 1, big.height - 1], radius * S, fill=255)
        out = Image.new("RGBA", im.size, (0, 0, 0, 0))
        out.paste(im, (0, 0), mask.resize(im.size, Image.LANCZOS))
        return ImageTk.PhotoImage(out)
    try:
        return _cache(("fit", path, mt, int(bw), int(bh)), build)
    except Exception:
        return None


def luminance(c):
    r, g, b = hex_rgb(c)
    return 0.299 * r + 0.587 * g + 0.114 * b


def safe_color(c, default="#128C7E"):
    try:
        hex_rgb(c)
        return c if str(c).startswith("#") and len(str(c)) == 7 else default
    except Exception:
        return default


# --------------------------------------------------------------------- list
class StatusHeader(Base):
    def __init__(self, cv, look, cb):
        super().__init__(cv, look)
        self.cb = cb

    def build(self, W, H):
        L = self.look
        self.cv.create_rectangle(0, 0, W, H, fill=L.page, outline="")
        self.icon_btn(34, 40, 38, "←", self.cb["back"], tint=L.text)
        self.t(62, 40, "Status", size=17, weight="bold", anchor="w")
        self.icon_btn(W - 34, 40, 38, "＋", self.cb["add"], filled=True)
        self.t(18, 88, "Updates disappear after 24 hours", size=9, fill=L.muted, anchor="w")


class StoryRows(Base):
    ROW_H, GAP = 72, 8

    def __init__(self, cv, look, cb):
        super().__init__(cv, look)
        self.cb = cb
        self.mine = dict(name="", dp=None, count=0, views=0, latest="")
        self.others = []
        self.sel = None
        for ev in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            cv.bind(ev, lambda e: cv.yview_scroll(wheel_units(e), "units"), add="+")

    def set_data(self, mine, others, selected=None):
        self.mine, self.others, self.sel = mine, others, selected
        self.refresh()

    def build(self, W, H):
        L, cv = self.look, self.cv
        n = len(self.others)
        total = 12 + 22 + self.ROW_H + 14 + 22 + (max(n, 1)) * (self.ROW_H + self.GAP) + 20
        self.scroll_h = max(H, total)
        cv.configure(scrollregion=(0, 0, W, self.scroll_h))
        cv.create_rectangle(0, 0, W, self.scroll_h, fill=L.page, outline="")
        y = 10
        self.t(20, y + 6, "MY STATUS", size=8, weight="bold", fill=L.muted, anchor="w")
        y += 22
        self._row("mine", 14, y, W - 28, self.mine, True)
        y += self.ROW_H + 14
        self.t(20, y + 6, "RECENT UPDATES", size=8, weight="bold", fill=L.muted, anchor="w")
        y += 22
        if not self.others:
            self.t(W / 2.0, y + 44, "No recent updates", size=11, weight="bold", fill=L.muted, anchor="center")
            self.t(W / 2.0, y + 68, "When your contacts post, it shows up here.", size=9, fill=L.muted, anchor="center")
            return
        for i, r in enumerate(self.others):
            self._row(r["id"], 14, y, W - 28, r, False, i)
            y += self.ROW_H + self.GAP

    def _row(self, key, x, y, w, r, mine, idx=0):
        L, cv = self.look, self.cv
        h = self.ROW_H
        selected = (self.sel == key)
        mark = self.sc.mark()
        if selected:
            im, m = pill_image(w, h, 18, L.p1, L.a2, glow=L.a1b, horizontal=True, glow_a=95)
            self.img(x - m, y - m, im, "nw")
            ids, tcol, mcol = None, "#FFFFFF", mix("#FFFFFF", L.a2, 0.25)
        else:
            ids = self.card(x, y, w, h, r=18)
            tcol, mcol = L.text, L.muted
        ax, ay = x + 40, y + h / 2.0
        count = r.get("count", 0)
        name = "My status" if mine else r["name"]
        self.avatar(ax, ay, 40, r.get("name") or "?", r.get("dp"), key=("me" if mine else r["id"]))
        if count:
            active = (count if mine else r.get("unviewed", 0))
            ring = story_ring(58, count, active if active else 0, L.a3 if not mine else L.green, L.pink,
                              mix(L.muted, L.page, 0.45) if not selected else mix("#FFFFFF", L.a2, 0.35), 3)
            if mine:
                ring = story_ring(58, count, count, L.green, L.a3, "#94A3B8", 3)
            self.img(ax, ay, ring)
        if mine and not count:
            cv.create_oval(ax + 8, ay + 8, ax + 26, ay + 26, fill=L.a1b, outline=L.card_top if not selected else L.p1, width=2)
            self.t(ax + 17, ay + 16.5, "+", size=10, weight="bold", fill="#FFFFFF", anchor="center")
        self.t(x + 80, y + 22, fit(name, font(11, "bold"), w - 100), size=11, weight="bold", fill=tcol)
        if mine:
            sub = ("%d update%s · %d view%s" % (count, "" if count == 1 else "s", r.get("views", 0),
                                                 "" if r.get("views", 0) == 1 else "s")) if count else "Tap to add a status update"
        else:
            sub = ago(r.get("latest")) + ("   ·   %d new" % r["unviewed"] if r.get("unviewed") else "")
        self.t(x + 80, y + 46, fit(sub, font(9), w - 100), size=9, fill=mcol if not (not mine and r.get("unviewed") and not selected) else L.a1)
        self.grp("srow%s" % key, mark)
        enter = leave = None
        if ids:
            enter, leave = self.hover_card(ids, "srow%s" % key, lift=-2)
        if mine:
            cb = self.cb["mine"] if count else self.cb["add"]
        else:
            cb = (lambda r=r: self.cb["user"](r["id"], r["name"]))
        self.hit((x, y, x + w, y + h), cb, enter, leave)


# --------------------------------------------------------------------- pane
class StoryPane(Base):
    def __init__(self, cv, look, cb):
        super().__init__(cv, look)
        self.cb = cb
        self.mode = "empty"
        self.stories, self.idx = [], 0
        self.elapsed, self.paused = 0.0, False
        self._timer = None
        self._press_t = None
        self._seen = set()
        self._bar = None
        cv.bind("<ButtonPress-1>", self._press, add="+")
        cv.bind("<ButtonRelease-1>", self._release, add="+")
        cv.bind("<Left>", lambda e: (self.prev(), "break")[1], add="+")
        cv.bind("<Right>", lambda e: (self.next(), "break")[1], add="+")
        cv.bind("<space>", lambda e: (self._toggle_pause(), "break")[1], add="+")
        cv.bind("<Escape>", lambda e: (self.close(), "break")[1] if self.mode == "story" else None, add="+")

    # ---- public
    def show_empty(self):
        self._stop()
        self.mode, self.stories = "empty", []
        self.refresh()

    def show_story(self, stories, index=0):
        if not stories:
            return self.show_empty()
        self._stop()
        self.mode, self.stories, self.idx = "story", stories, max(0, min(index, len(stories) - 1))
        self._seen = set()
        self._begin()
        self.cv.focus_set()

    def close(self):
        self.show_empty()
        self.cb["closed"]()

    def next(self):
        if self.mode != "story":
            return
        if self.idx < len(self.stories) - 1:
            self.idx += 1
            self._begin()
        else:
            self.close()

    def prev(self):
        if self.mode != "story":
            return
        if self.idx > 0:
            self.idx -= 1
        self._begin()

    # ---- timer
    def _begin(self):
        self.elapsed, self.paused = 0.0, False
        st = self.stories[self.idx]
        if not st["own"] and st["id"] not in self._seen:
            self._seen.add(st["id"])
            self.cb["viewed"](st["id"])
        self.refresh()
        self._schedule()

    def _stop(self):
        if self._timer:
            try:
                self.cv.after_cancel(self._timer)
            except Exception:
                pass
        self._timer = None

    def _schedule(self):
        self._stop()
        self._timer = self.cv.after(40, self._tick)

    def _tick(self):
        self._timer = None
        if self.mode != "story" or not self.cv.winfo_exists():
            return
        if not self.paused:
            self.elapsed += 0.04
            st = self.stories[self.idx]
            dur = STORY_SECONDS.get(st["type"], 5.0)
            frac = min(1.0, self.elapsed / dur)
            self._set_bar(frac)
            if frac >= 1.0:
                self.next()
                return
        self._schedule()

    def _set_bar(self, frac):
        if self._bar:
            x1, y1, x2, y2 = self._bar
            try:
                self.cv.coords("progfill", x1, y1, x1 + (x2 - x1) * frac, y2)
            except tk.TclError:
                pass

    def _toggle_pause(self):
        self.paused = not self.paused

    # ---- mouse: tap = navigate, hold = pause
    def _press(self, e):
        if self.mode != "story":
            return
        self.cv.focus_set()
        z = getattr(self, "zone", None)
        x, y = self.cv.canvasx(e.x), self.cv.canvasy(e.y)
        if z and z[0] <= x <= z[2] and z[1] <= y <= z[3]:
            self._press_t = (datetime.now(), x)
            self.paused = True

    def _release(self, e):
        if self.mode != "story" or not self._press_t:
            return
        t0, x = self._press_t
        self._press_t = None
        self.paused = False
        if (datetime.now() - t0).total_seconds() < 0.25:
            z = self.zone
            if x < z[0] + (z[2] - z[0]) * 0.33:
                self.prev()
            else:
                self.next()

    # ---- drawing
    def build(self, W, H):
        if self.mode == "empty":
            self._empty(W, H)
        else:
            self._story(W, H)

    def _empty(self, W, H):
        from chat_fx import chat_bg
        L = self.look
        self.img(0, 0, chat_bg(W, H, L), "nw")
        cx, cy = W / 2.0, H / 2.0 - 80
        halo, m = pill_image(150, 150, 75, L.p1, L.a2, glow=L.a1b, horizontal=False, glow_a=120)
        mark = self.sc.mark()
        self.img(cx - 75 - m, cy - 75 - m, halo, "nw")
        self.img(cx, cy - 2, get_icon("status", 64, "#FFFFFF"))
        self.grp("hero", mark)
        self.sc.bob("hero", amp=5, period=3.4)
        self.t(cx, cy + 112, "Share a moment", size=21, weight="bold", anchor="center")
        self.t(cx, cy + 142, "Post a text or photo update. Your contacts see it for 24 hours.", size=10, fill=L.muted,
               anchor="center")
        bw, bh = 200, 48
        bim, bm = pill_image(bw, bh, 24, L.p1, L.a2, glow=L.a1b, glow_a=120)
        self.img(cx - bw / 2.0 - bm, cy + 172 - bm, bim, "nw")
        self.t(cx, cy + 172 + bh / 2.0, "＋   Add status", size=11, weight="bold", fill="#FFFFFF", anchor="center")
        self.hit((cx - bw / 2.0, cy + 172, cx + bw / 2.0, cy + 172 + bh), self.cb["add"])
        feats = [("24h", "Disappears in 24h", "Auto-cleans itself"), ("●", "See who viewed", "Views and repeat views"),
                 ("Aa", "Text or photo", "Colours and captions")]
        cw, gap = 224, 14
        x = cx - (cw * 3 + gap * 2) / 2.0
        y = cy + 246
        for i, (g, t1, t2) in enumerate(feats):
            mk = self.sc.mark()
            ids = self.card(x, y, cw, 80, r=16)
            ci, mm = pill_image(36, 36, 18, L.p1, L.a2, glow=L.a1b, glow_a=70)
            self.img(x + 20 - mm, y + 20 - mm, ci, "nw")
            self.t(x + 38, y + 38, g, size=9, weight="bold", fill="#FFFFFF", anchor="center")
            self.t(x + 66, y + 24, t1, size=10, weight="bold")
            self.t(x + 66, y + 46, t2, size=9, fill=L.muted)
            self.grp("sf%d" % i, mk, enter=(0, 24), delay=0.12 * i)
            on, off = self.hover_card(ids, "sf%d" % i, lift=-4)
            self.hit((x, y, x + cw, y + 80), None, on, off)
            x += cw + gap

    def _nav(self, cx, cy, d, cb):
        """Round chevron button (vector drawn, so it is crisp on every machine)."""
        r = 22
        bg = self.cv.create_oval(cx - r, cy - r, cx + r, cy + r, fill="#1A2238", outline="#2B3556")
        self.cv.create_line(cx - 4 * d, cy - 8, cx + 4 * d, cy, cx - 4 * d, cy + 8, fill="#FFFFFF", width=3,
                            capstyle="round", joinstyle="round")
        self.hit((cx - r, cy - r, cx + r, cy + r), cb, lambda: self.cv.itemconfigure(bg, fill="#2B3556"),
                 lambda: self.cv.itemconfigure(bg, fill="#1A2238"))

    def _story(self, W, H):
        L, cv = self.look, self.cv
        st = self.stories[self.idx]
        n = len(self.stories)
        color = safe_color(st.get("bg")) if st["type"] != "image" else mix(L.a2, "#000000", 0.2)
        self.img(0, 0, story_backdrop(W, H, color), "nw")

        ch = int(min(H - 40, 780))
        cw = int(min(ch * 0.58, W - 190))
        cw = max(cw, 260)
        ch = min(ch, int(cw / 0.5))
        x0, y0 = (W - cw) / 2.0, (H - ch) / 2.0
        self.zone = (x0, y0 + 96, x0 + cw, y0 + ch - 72)

        # ---- card body
        if st["type"] == "image":
            body, m = card_image(cw, ch, 26, "#0B1020", "#05070F", "#1C2540", (0, 0, 0, 150))
        else:
            body, m = card_image(cw, ch, 26, mix(color, "#FFFFFF", 0.14), mix(color, "#000000", 0.38),
                                 mix(color, "#000000", 0.45), (0, 0, 0, 150))
        self.img(x0 - m, y0 - m, body, "nw")

        if st["type"] == "image":
            ph = fit_image(st.get("path") or "", cw - 8, ch - 8, 22) if st.get("path") and os.path.exists(st["path"]) else None
            if ph is not None:
                self.img(x0 + cw / 2.0, y0 + ch / 2.0, ph)
            else:
                self.t(x0 + cw / 2.0, y0 + ch / 2.0, "⚠  Image not available", size=11, weight="bold", fill="#FFFFFF", anchor="center")
            if st.get("content"):
                cap = fit(st["content"], font(11), cw - 70)
                tw = font(11).measure(cap) + 28
                bx = x0 + cw / 2.0 - tw / 2.0
                by = y0 + ch - 128
                bim, bmm = pill_image(tw, 34, 17, "#10162A", "#10162A", glow=None)
                self.img(bx - bmm, by - bmm, bim, "nw")
                self.t(x0 + cw / 2.0, by + 17, cap, size=11, fill="#FFFFFF", anchor="center")
        else:
            txt = st.get("content") or ""
            size = int(max(16, min(40, float(st.get("size") or 20) * 1.4)))
            fcol = "#10162A" if luminance(color) > 175 else "#FFFFFF"
            cv.create_text(x0 + cw / 2.0, y0 + ch / 2.0, text=txt, width=cw - 70, font=(FONT, size, "bold"),
                           fill=fcol, justify="center", anchor="center")

        # ---- top shade + progress + header
        self.img(x0, y0, story_shade(cw, ch), "nw")
        gap = 5
        sw = (cw - 40 - gap * (n - 1)) / float(n)
        for i in range(n):
            sx = x0 + 20 + i * (sw + gap)
            cv.create_rectangle(sx, y0 + 16, sx + sw, y0 + 19, fill=mix("#FFFFFF", "#000000", 0.62), outline="")
            if i < self.idx:
                cv.create_rectangle(sx, y0 + 16, sx + sw, y0 + 19, fill="#FFFFFF", outline="")
            elif i == self.idx:
                self._bar = (sx, y0 + 16, sx + sw, y0 + 19)
                cv.create_rectangle(sx, y0 + 16, sx, y0 + 19, fill="#FFFFFF", outline="", tags="progfill")
        self._set_bar(min(1.0, self.elapsed / STORY_SECONDS.get(st["type"], 5.0)))

        self.avatar(x0 + 40, y0 + 52, 32, st["name"], st.get("dp"), key=st["uid"])
        self.t(x0 + 66, y0 + 46, fit(st["name"], font(11, "bold"), cw - 150), size=11, weight="bold", fill="#FFFFFF", anchor="w")
        self.t(x0 + 66, y0 + 64, ago(st["created"]), size=8, fill="#D6DCEB", anchor="w")
        self.icon_btn(x0 + cw - 34, y0 + 52, 34, "✕", self.close, tint="#FFFFFF")

        # ---- bottom bar
        by = y0 + ch - 44
        if st["own"]:
            v = st.get("views", 0)
            lab = "%d view%s" % (v, "" if v == 1 else "s")
            vw = font(10, "bold").measure(lab) + 56
            vim, vm = pill_image(vw, 34, 17, "#FFFFFF", "#FFFFFF", glow=None)
            self.img(x0 + 20 - vm, by - 17 - vm, vim, "nw")
            self.img(x0 + 40, by, get_icon("user", 15, "#334155"))
            self.t(x0 + 56, by, lab + "  ›", size=10, weight="bold", fill="#1E293B", anchor="w")
            self.hit((x0 + 20, by - 17, x0 + 20 + vw, by + 17), lambda: self.cb["details"](st["id"]))
            dim, dm = pill_image(88, 34, 17, "#B91C1C", "#DC2626", glow=None)
            self.img(x0 + cw - 20 - 88 - dm, by - 17 - dm, dim, "nw")
            self.t(x0 + cw - 20 - 44, by, "🗑  Delete", size=9, weight="bold", fill="#FFFFFF", anchor="center")
            self.hit((x0 + cw - 108, by - 17, x0 + cw - 20, by + 17), lambda: self.cb["delete"](st["id"]))
        else:
            mw = 150
            mim, mm = pill_image(mw, 36, 18, L.p1, L.a2, glow=L.a1b, glow_a=100)
            self.img(x0 + cw / 2.0 - mw / 2.0 - mm, by - 18 - mm, mim, "nw")
            self.t(x0 + cw / 2.0, by, "💬  Message", size=10, weight="bold", fill="#FFFFFF", anchor="center")
            self.hit((x0 + cw / 2.0 - mw / 2.0, by - 18, x0 + cw / 2.0 + mw / 2.0, by + 18),
                     lambda: self.cb["message"](st["uid"], st["name"]))

        # ---- side arrows
        if x0 > 70:
            if self.idx > 0:
                self._nav(x0 - 40, H / 2.0, -1, self.prev)
            self._nav(x0 + cw + 40, H / 2.0, 1, self.next)
        self.t(W / 2.0, H - 16, "Tap sides to navigate  ·  hold to pause  ·  Esc to close", size=8, fill="#8B96B2", anchor="center")


# -------------------------------------------------------------------- shell
class StatusShell(tk.Frame):
    def __init__(self, parent, look, cb):
        super().__init__(parent, bg=look.page)
        self.look, self.cb = look, cb
        left = tk.Frame(self, bg=look.page, width=LIST_W)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)
        tk.Frame(self, bg=look.line, width=1).pack(side="left", fill="y")
        self.hd_cv = tk.Canvas(left, height=108, bg=look.page, highlightthickness=0, bd=0)
        self.hd_cv.pack(fill="x")
        self.header = StatusHeader(self.hd_cv, look, dict(back=cb["back"], add=cb["add"]))
        self.rows_cv = tk.Canvas(left, bg=look.page, highlightthickness=0, bd=0)
        self.rows_cv.pack(fill="both", expand=True)
        self.rows = StoryRows(self.rows_cv, look, dict(mine=cb["mine"], add=cb["add"], user=cb["user"]))
        self.pane_cv = tk.Canvas(self, bg=look.page, highlightthickness=0, bd=0, takefocus=1)
        self.pane_cv.pack(side="left", fill="both", expand=True)
        self.pane = StoryPane(self.pane_cv, look, dict(
            add=cb["add"], viewed=cb["viewed"], details=cb["details"], delete=cb["delete"], message=cb["message"],
            closed=self._closed))

    def _closed(self):
        self.rows.sel = None
        self.rows.refresh()
        self.cb["closed"]()

    def set_data(self, mine, others):
        self.rows.set_data(mine, others, self.rows.sel)

    def open_stories(self, stories, index=0, selected=None):
        self.rows.sel = selected
        self.rows.refresh()
        self.pane.show_story(stories, index)

    def show_empty(self):
        self.pane.show_empty()
