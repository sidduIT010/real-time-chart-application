"""
NexaChat FX kit
===============
Theme-aware building blocks shared by the animated Dashboard, Analytics and
Themes screens. Built on top of fx.py (Scene / Orbs / ParticleNet / ticker).

* PALETTES / Look   - the six NexaChat themes + derived colours (dark/light aware)
* card_image        - glass card with soft shadow, or accent glow when hovered
* pill_image        - gradient pill / button with a coloured glow
* dp_avatar         - circular profile picture with a soft ring
* Page              - a Canvas "page": debounced rebuild on resize, hit-testing,
                      hover callbacks, aurora background, helpers for text,
                      cards, count-up numbers and sparklines.
"""
import math
import os
import tkinter as tk
from PIL import Image, ImageDraw, ImageFilter, ImageTk

from fx import (Scene, Orbs, ParticleNet, mix, hex_rgb, cached, catmull, clock,
                ease_out_cubic, ease_out_back, ease_in_out)

FONT = "Segoe UI"

PALETTES = {
    "Ocean Blue": {"PAGE": "#F5F8FC", "NAV": "#FFFFFF", "NAV_BORDER": "#E6ECF5", "TEXT": "#10233F", "MUTED": "#72819A", "BLUE": "#2563EB", "BLUE2": "#3B82F6", "CYAN": "#06B6D4", "PURPLE": "#7C3AED", "GREEN": "#10B981", "PINK": "#EC4899", "RED": "#EF4444", "LINE": "#E8EEF6", "WHITE": "#FFFFFF"},
    "Midnight Aurora": {"PAGE": "#08111F", "NAV": "#0D1728", "NAV_BORDER": "#22324A", "TEXT": "#F8FAFC", "MUTED": "#A7B4C7", "BLUE": "#38BDF8", "BLUE2": "#0EA5E9", "CYAN": "#22D3EE", "PURPLE": "#8B5CF6", "GREEN": "#34D399", "PINK": "#F472B6", "RED": "#FB7185", "LINE": "#263852", "WHITE": "#111C2E"},
    "Sunset Coral": {"PAGE": "#FFF7F2", "NAV": "#FFFFFF", "NAV_BORDER": "#F5DDD2", "TEXT": "#3B1D2A", "MUTED": "#80616B", "BLUE": "#F97316", "BLUE2": "#FB7185", "CYAN": "#F59E0B", "PURPLE": "#EC4899", "GREEN": "#10B981", "PINK": "#E11D48", "RED": "#DC2626", "LINE": "#F1DDD5", "WHITE": "#FFFFFF"},
    "Forest Mint": {"PAGE": "#F2FBF7", "NAV": "#FFFFFF", "NAV_BORDER": "#D8EEE6", "TEXT": "#12352D", "MUTED": "#648078", "BLUE": "#059669", "BLUE2": "#10B981", "CYAN": "#14B8A6", "PURPLE": "#0F766E", "GREEN": "#16A34A", "PINK": "#2DD4BF", "RED": "#EF4444", "LINE": "#DDEEE8", "WHITE": "#FFFFFF"},
    "Royal Violet": {"PAGE": "#F8F5FF", "NAV": "#FFFFFF", "NAV_BORDER": "#E9DFFF", "TEXT": "#24134A", "MUTED": "#756A8D", "BLUE": "#7C3AED", "BLUE2": "#8B5CF6", "CYAN": "#6366F1", "PURPLE": "#4F46E5", "GREEN": "#10B981", "PINK": "#D946EF", "RED": "#EF4444", "LINE": "#E9DFFF", "WHITE": "#FFFFFF"},
    "Cyber Neon": {"PAGE": "#080B16", "NAV": "#0C1020", "NAV_BORDER": "#25304A", "TEXT": "#F8FAFC", "MUTED": "#9AA6BD", "BLUE": "#22D3EE", "BLUE2": "#06B6D4", "CYAN": "#67E8F9", "PURPLE": "#A855F7", "GREEN": "#34D399", "PINK": "#F43F5E", "RED": "#FB7185", "LINE": "#25304A", "WHITE": "#111827"},
}
THEME_DESC = {
    "Ocean Blue": "Clean professional", "Midnight Aurora": "Dark glass & neon",
    "Sunset Coral": "Warm and energetic", "Forest Mint": "Fresh and calm",
    "Royal Violet": "Elegant and creative", "Cyber Neon": "Futuristic and bold",
}


def palette_for(name):
    return PALETTES.get(name, PALETTES["Ocean Blue"])


class Look:
    """Colours derived from one theme palette."""

    def __init__(self, C):
        self.C = C
        self.page, self.surface, self.line = C["PAGE"], C["WHITE"], C["LINE"]
        self.text, self.muted = C["TEXT"], C["MUTED"]
        self.a1, self.a2, self.a3 = C["BLUE"], C["PURPLE"], C["CYAN"]
        self.a1b = C["BLUE2"]
        self.green, self.pink, self.red = C["GREEN"], C["PINK"], C["RED"]
        r, g, b = hex_rgb(self.page)
        self.dark = (0.299 * r + 0.587 * g + 0.114 * b) < 110
        if self.dark:
            self.card_top = mix(self.surface, "#FFFFFF", 0.05)
            self.card_bot = self.surface
            self.shadow = (0, 0, 0, 120)
            self.orb_alpha = 78
        else:
            self.card_top = "#FFFFFF"
            self.card_bot = mix("#FFFFFF", self.a1, 0.035)
            self.shadow = hex_rgb(mix(self.a2, "#000000", 0.35)) + (46,)
            self.orb_alpha = 62
        self.p1 = mix(self.a1b, "#0A0F1E", 0.34) if self.dark else self.a1b   # button / banner gradient start (keeps white text legible)
        self.soft = mix(self.card_bot, self.a1, 0.10 if self.dark else 0.08)
        base = "#070518"
        self.sb_top = mix(base, self.a2, 0.20)
        self.sb_bot = mix(base, self.a1, 0.26)


# --------------------------------------------------------------- images ----
def card_image(w, h, r, top, bot, border, shadow=(60, 60, 120, 40), glow=None):
    """Rounded card with a soft shadow (or accent glow). Returns (PhotoImage, margin)."""
    w, h = int(w), int(h)
    key = ("nxcard", w, h, r, top, bot, border, shadow, glow)

    def build():
        m, S = 24, 2
        W, H = w + 2 * m, h + 2 * m
        out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        if glow:
            col, a, dy, blur = hex_rgb(glow), 150, 0, 10
        else:
            col, a, dy, blur = tuple(shadow[:3]), shadow[3], 5, 9
        ImageDraw.Draw(sh).rounded_rectangle([m, m + dy, m + w - 1, m + h - 1 + dy], r, fill=col + (a,))
        out.alpha_composite(sh.filter(ImageFilter.GaussianBlur(blur)))
        ww, hh = w * S, h * S
        g = Image.linear_gradient("L").resize((ww, hh))
        grad = Image.composite(Image.new("RGB", (ww, hh), hex_rgb(bot)), Image.new("RGB", (ww, hh), hex_rgb(top)), g)
        mask = Image.new("L", (ww, hh), 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, ww - 1, hh - 1], r * S, fill=255)
        body = Image.new("RGBA", (ww, hh), (0, 0, 0, 0))
        body.paste(grad, (0, 0), mask)
        ImageDraw.Draw(body).rounded_rectangle([0, 0, ww - 1, hh - 1], r * S, outline=hex_rgb(border) + (255,), width=S)
        out.alpha_composite(body.resize((w, h), Image.LANCZOS), (m, m))
        return ImageTk.PhotoImage(out), m

    return cached(key, build)


def pill_image(w, h, r, c1, c2, glow=None, horizontal=True, glow_a=130):
    """Gradient rounded rectangle with optional glow. Returns (PhotoImage, margin)."""
    w, h = int(w), int(h)
    key = ("nxpill", w, h, r, c1, c2, glow, horizontal, glow_a)

    def build():
        m, S = (20 if glow else 2), 2
        W, H = w + 2 * m, h + 2 * m
        out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        if glow:
            sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            ImageDraw.Draw(sh).rounded_rectangle([m + 2, m + 6, m + w - 3, m + h + 2], r, fill=hex_rgb(glow) + (glow_a,))
            out.alpha_composite(sh.filter(ImageFilter.GaussianBlur(8)))
        ww, hh = w * S, h * S
        g = Image.linear_gradient("L").resize((256, 256))
        if horizontal:
            g = g.rotate(90, expand=True)   # black(top) -> left, white(bottom) -> right
        g = g.resize((ww, hh))
        grad = Image.composite(Image.new("RGB", (ww, hh), hex_rgb(c2)), Image.new("RGB", (ww, hh), hex_rgb(c1)), g)
        mask = Image.new("L", (ww, hh), 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, ww - 1, hh - 1], r * S, fill=255)
        body = Image.new("RGBA", (ww, hh), (0, 0, 0, 0))
        body.paste(grad, (0, 0), mask)
        # top sheen
        sheen = Image.new("RGBA", (ww, hh), (255, 255, 255, 0))
        fade = Image.linear_gradient("L").transpose(Image.FLIP_TOP_BOTTOM).resize((ww, hh)).point(lambda v: v * 46 // 255)
        sheen.putalpha(Image.composite(fade, Image.new("L", (ww, hh), 0), mask))
        body.alpha_composite(sheen)
        out.alpha_composite(body.resize((w, h), Image.LANCZOS), (m, m))
        return ImageTk.PhotoImage(out), m

    return cached(key, build)


def vgrad_image(w, h, top, bot, grid=None):
    w, h = max(2, int(w)), max(2, int(h))

    def build():
        g = Image.linear_gradient("L").resize((w, h))
        img = Image.composite(Image.new("RGB", (w, h), hex_rgb(bot)), Image.new("RGB", (w, h), hex_rgb(top)), g).convert("RGBA")
        if grid:
            d = ImageDraw.Draw(img)
            for gx in range(16, w, 28):
                for gy in range(16, h, 28):
                    d.point((gx, gy), fill=hex_rgb(grid) + (255,))
        return ImageTk.PhotoImage(img)

    return cached(("nxvg", w, h, top, bot, grid), build)


def dp_avatar(path, size, ring_color):
    """Circular profile picture with a soft ring; None when the file can't be read."""
    if not path or not os.path.exists(path):
        return None
    try:
        mt = os.path.getmtime(path)
    except OSError:
        return None

    def build():
        S, pad = 3, 4
        total = size + pad * 2
        im = Image.open(path).convert("RGB")
        side = min(im.size)
        l, t = (im.width - side) // 2, (im.height - side) // 2
        im = im.crop((l, t, l + side, t + side)).resize((size * S, size * S), Image.LANCZOS)
        out = Image.new("RGBA", (total * S, total * S), (0, 0, 0, 0))
        ImageDraw.Draw(out).ellipse([0, 0, total * S - 1, total * S - 1], fill=hex_rgb(ring_color) + (80,))
        mask = Image.new("L", (size * S, size * S), 0)
        ImageDraw.Draw(mask).ellipse([0, 0, size * S - 1, size * S - 1], fill=255)
        out.paste(im, (pad * S, pad * S), mask)
        return ImageTk.PhotoImage(out.resize((total, total), Image.LANCZOS))

    try:
        return cached(("nxdp", path, mt, size, ring_color), build)
    except Exception:
        return None


# ----------------------------------------------------------------- page ----
class Page:
    """A Canvas that (re)builds itself on resize, with hit-testing and hover callbacks."""

    min_w, min_h = 300, 200
    scroll_h = 0

    def __init__(self, cv, look):
        self.cv, self.look = cv, look
        self.sc = Scene(cv)
        self.hits, self.cur = [], None
        self.first = True
        self.net = None
        self._size, self._job = (0, 0), None
        cv.bind("<Configure>", self._cfg, add="+")
        cv.bind("<Motion>", self._motion, add="+")
        cv.bind("<Leave>", self._leave, add="+")
        cv.bind("<Button-1>", self._click, add="+")

    # ---- lifecycle
    def _cfg(self, e):
        size = (e.width, e.height)
        if size == self._size:
            return
        delay = 30 if self._size == (0, 0) else 110
        self._size = size
        if self._job:
            try:
                self.cv.after_cancel(self._job)
            except Exception:
                pass
        self._job = self.cv.after(delay, self._rebuild)

    def _rebuild(self):
        try:
            if not self.cv.winfo_exists():
                return
            W, H = self.cv.winfo_width(), self.cv.winfo_height()
            if W < self.min_w or H < self.min_h:
                return
            self.sc.reset()
            self.cv.delete("all")
            self.hits, self.cur, self.net = [], None, None
            self.cv.configure(scrollregion=(0, 0, W, max(H, self.scroll_h)))
            self.build(W, H)
            self.first = False
        except tk.TclError:
            pass

    def build(self, W, H):  # pragma: no cover - overridden
        pass

    def dur(self, d):
        return d if self.first else 0.001

    def grp(self, tag, mark, enter=None, delay=0.0):
        return self.sc.group(tag, mark, enter if self.first else None, delay)

    # ---- hit testing
    def hit(self, box, cb=None, enter=None, leave=None, move=None):
        r = {"box": box, "cb": cb, "enter": enter, "leave": leave, "move": move}
        self.hits.append(r)
        return r

    def _find(self, e):
        x, y = self.cv.canvasx(e.x), self.cv.canvasy(e.y)
        for r in reversed(self.hits):
            x1, y1, x2, y2 = r["box"]
            if x1 <= x <= x2 and y1 <= y <= y2:
                return r, x, y
        return None, x, y

    def _motion(self, e):
        r, x, y = self._find(e)
        if self.net:
            self.net.mouse = (x, y)
        if r is not self.cur:
            old, self.cur = self.cur, r
            try:
                if old and old["leave"]:
                    old["leave"]()
                if r and r["enter"]:
                    r["enter"]()
                self.cv.configure(cursor="hand2" if (r and r["cb"]) else "")
            except tk.TclError:
                pass
        if r and r["move"]:
            r["move"](x, y)

    def _leave(self, e):
        if self.net:
            self.net.mouse = None
        old, self.cur = self.cur, None
        try:
            if old and old["leave"]:
                old["leave"]()
            self.cv.configure(cursor="")
        except tk.TclError:
            pass

    def _click(self, e):
        r, _, _ = self._find(e)
        if r and r["cb"]:
            r["cb"]()

    # ---- drawing helpers
    def t(self, x, y, s, size=10, weight="normal", fill=None, anchor="nw", tags=()):
        return self.cv.create_text(x, y, anchor=anchor, text=s, font=(FONT, size, weight),
                                   fill=fill or self.look.text, tags=tags)

    def img(self, x, y, image, anchor="center", state="normal"):
        self.sc.keep.append(image)
        return self.cv.create_image(x, y, image=image, anchor=anchor, state=state)

    def card(self, x, y, w, h, r=16, top=None, bot=None, border=None, glow=None):
        """Draws base + hover(glow) card images. Returns (base_id, hover_id)."""
        L = self.look
        top, bot, border = top or L.card_top, bot or L.card_bot, border or L.line
        base, m = card_image(w, h, r, top, bot, border, L.shadow)
        hov, m2 = card_image(w, h, r, top, bot, mix(border, glow or L.a1, 0.75), L.shadow, glow=glow or L.a1)
        b = self.img(x - m, y - m, base, "nw")
        hv = self.img(x - m2, y - m2, hov, "nw", state="hidden")
        return b, hv

    def hover_card(self, ids, tag, lift=-4):
        def on():
            self.cv.itemconfigure(ids[0], state="hidden")
            self.cv.itemconfigure(ids[1], state="normal")
            self.sc.hover_group(tag, 0, lift)

        def off():
            self.cv.itemconfigure(ids[0], state="normal")
            self.cv.itemconfigure(ids[1], state="hidden")
            self.sc.hover_group(tag, 0, 0)

        return on, off

    def num(self, item, val, delay=0.0, dur=1.1, fmt="{:,}"):
        if self.first and val:
            self.sc.count_up(item, val, dur, delay, fmt)

    def aurora(self, W, H, n_particles=22):
        """Page backdrop: drifting colour orbs + a faint, mouse-reactive constellation."""
        L, sc, cv = self.look, self.sc, self.cv
        cv.create_rectangle(0, 0, W, max(H, self.scroll_h), fill=L.page, outline="")
        a = L.orb_alpha
        Orbs(sc, [
            dict(color=L.a1, d=520, alpha=a, cx=W * 0.92, cy=H * 0.06, ax=44, ay=30, sx=0.30, sy=0.24, ph=0.0),
            dict(color=L.a2, d=560, alpha=a, cx=W * 0.06, cy=H * 0.96, ax=50, ay=36, sx=0.24, sy=0.30, ph=1.7),
            dict(color=L.a3, d=380, alpha=int(a * 0.8), cx=W * 0.55, cy=H * 0.90, ax=60, ay=26, sx=0.20, sy=0.26, ph=3.0),
        ])
        if n_particles:
            self.net = ParticleNet(sc, (0, 0, W, H), n_particles, L.a2, L.page, link=105, speed=9,
                                   seed=11, link_strength=0.30 if not L.dark else 0.45,
                                   radius=(1.0, 2.2), max_links=40)

    def spark(self, x, y, w, h, vals, color, tag, delay=0.0, fill_bg=None, width=2.2):
        """Animated smooth sparkline that draws itself, then keeps a glowing dot travelling along it."""
        L, sc, cv = self.look, self.sc, self.cv
        vals = list(vals) if len(vals) >= 3 else [0, 0, 0]
        lo, hi = min(vals), max(vals)
        n = len(vals)
        norm = [0.5 if hi == lo else (v - lo) / float(hi - lo) for v in vals]
        pts = [(x + i * w / float(n - 1), y + h - (0.08 + 0.84 * norm[i]) * h) for i in range(n)]
        fill = mix(fill_bg or L.card_bot, color, 0.16 if not L.dark else 0.22)
        dur = self.dur(1.15)
        sc.line_chart(pts, color, fill, y + h, width=width, delay=delay, duration=dur, follow=tag)
        dense = catmull(pts, 8)
        ys_ = [p[1] for p in pts]
        dense = [(a, min(max(ys_), max(min(ys_), b))) for a, b in dense]
        halo = cv.create_oval(0, 0, 0, 0, outline="", fill="")
        dot = cv.create_oval(0, 0, 0, 0, fill=color, outline="", state="hidden")
        t0 = clock() + delay + dur

        def step(dt, now):
            if now < t0:
                return
            ox, oy = sc.off(tag)
            f = (((now - t0) / 3.2) % 1.0) * (len(dense) - 1)
            i = int(f)
            px, py = dense[i][0] + ox, dense[i][1] + oy
            r = 4.2 + 1.2 * math.sin(now * 5)
            cv.coords(dot, px - r, py - r, px + r, py + r)
            cv.itemconfigure(dot, state="normal", fill=mix(color, "#FFFFFF", 0.35))
            cv.coords(halo, px - r - 4, py - r - 4, px + r + 4, py + r + 4)
            cv.itemconfigure(halo, outline=mix(fill, color, 0.55))

        sc.on(step, every=2)
