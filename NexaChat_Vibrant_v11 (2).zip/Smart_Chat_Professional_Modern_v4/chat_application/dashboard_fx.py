"""
NexaChat animated dashboard
===========================
Sidebar + content canvases built on fxkit.Page. Everything is theme-aware
(all six themes, light and dark) and driven by the shared 60 fps ticker.
"""
import math
import tkinter.font as tkfont
from datetime import datetime, timedelta

from fx import Orbs, ParticleNet, glass_image, mix, rr_points, clock, ease_out_back, ease_out_cubic, clamp01
from fxkit import (Page, Look, FONT, card_image, pill_image, vgrad_image, dp_avatar)
from ui_components import get_icon, make_avatar

WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


# ----------------------------------------------------------------- data ----
def parse_ts(v):
    try:
        return datetime.strptime(str(v).replace("T", " ")[:19], "%Y-%m-%d %H:%M:%S")
    except Exception:
        return None


def daily_counts(msgs, uid, days, which="all"):
    """Messages per day for the last `days` days (oldest first). which: all | sent | received."""
    today = datetime.now().date()
    keys = [today - timedelta(days=days - 1 - i) for i in range(days)]
    out = {k: 0 for k in keys}
    for m in msgs:
        t = parse_ts(m[3])
        if not t or t.date() not in out:
            continue
        mine = m[0] == uid
        if which == "all" or (which == "sent" and mine) or (which == "received" and not mine):
            out[t.date()] += 1
    return keys, [out[k] for k in keys]


def trend_pct(series):
    """% change between the last half and the first half of a series."""
    h = len(series) // 2
    prev, cur = sum(series[:h]), sum(series[h:])
    if prev == 0:
        return 100 if cur else 0
    return int(round((cur - prev) * 100.0 / prev))


def greeting():
    h = datetime.now().hour
    return "Good morning" if h < 12 else "Good afternoon" if h < 17 else "Good evening"


# -------------------------------------------------------------- sidebar ----
class SidebarPage(Page):
    min_w, min_h = 100, 300

    def __init__(self, cv, look, app, data):
        super().__init__(cv, look)
        self.app, self.d = app, data
        self.hv = {"y": None, "cur": None, "amt": 0.0}

    def build(self, W, H):
        L, cv, sc, d, app = self.look, self.cv, self.sc, self.d, self.app
        self.hv.update(y=None, cur=None, amt=0.0)
        bg = vgrad_image(W, H, L.sb_top, L.sb_bot, grid=mix(L.sb_top, "#FFFFFF", 0.07))
        sc.keep.append(bg)
        cv.create_image(0, 0, anchor="nw", image=bg)
        mid = mix(L.sb_top, L.sb_bot, 0.55)
        Orbs(sc, [
            dict(color=L.a1, d=340, alpha=100, cx=W * 0.15, cy=H * 0.97, ax=26, ay=22, sx=0.32, sy=0.25, ph=0.4),
            dict(color=L.a2, d=300, alpha=90, cx=W * 0.95, cy=H * 0.10, ax=22, ay=26, sx=0.27, sy=0.33, ph=2.1),
            dict(color=L.a3, d=200, alpha=50, cx=W * 0.60, cy=H * 0.55, ax=30, ay=40, sx=0.20, sy=0.22, ph=4.0),
        ])
        self.net = ParticleNet(sc, (0, 0, W, H), 14, "#C4BBFF", L.sb_top, link=0, speed=6,
                               radius=(0.9, 1.9), seed=3, max_links=1)
        cv.create_line(W - 1, 0, W - 1, H, fill=mix(L.sb_top, "#FFFFFF", 0.10))

        # ---- brand
        m = sc.mark()
        lx, ly = 42, 42
        cv.create_oval(lx - 21, ly - 21, lx + 21, ly + 21, fill=L.a2, outline="")
        cv.create_oval(lx - 17, ly - 17, lx + 17, ly + 17, fill=L.a1, outline="")
        cv.create_oval(lx - 13, ly - 13, lx + 13, ly + 13, fill="#FFFFFF", outline="")
        self.img(lx, ly + 1, get_icon("chat", 17, L.a2))
        sc.pulse_rings(lx, ly, 22, 33, mix(L.a3, "#FFFFFF", 0.3), mix(L.sb_top, L.sb_bot, 0.1), period=2.8, count=2)
        sc.spin_ring(lx, ly, 27, "#FFFFFF", L.a3, mid, width=2, segs=16, sweep=250, speed=130)
        self.t(82, 24, "NexaChat", 14, "bold", "#FFFFFF")
        tag_item = self.t(83, 49, "", 7, "bold", mix(L.a3, "#FFFFFF", 0.45))
        self.grp("sb_logo", m, (-26, 0), 0.0)
        if self.first:
            sc.typewrite(tag_item, "CONNECT  \u2022  CHAT  \u2022  GROW", cps=24, delay=0.4)
        else:
            cv.itemconfigure(tag_item, text="CONNECT  \u2022  CHAT  \u2022  GROW")

        label_col = mix(L.sb_bot, "#FFFFFF", 0.70)
        dim_col = mix(L.sb_bot, "#FFFFFF", 0.38)
        self.t(26, 98, "MAIN MENU", 7, "bold", dim_col, "w")

        # ---- sliding hover pill (spring-follows the pointer between rows)
        x1, x2, rh = 12, W - 12, 38
        pill = cv.create_polygon(rr_points(x1, 0, x2, rh, 12), smooth=True, fill=mid, outline="", state="hidden")
        hv = self.hv

        def hover_step(dt, now):
            k = 1 - math.exp(-dt * 14)
            if hv["y"] is not None:
                hv["cur"] = hv["y"] if hv["cur"] is None else hv["cur"] + (hv["y"] - hv["cur"]) * k
                hv["amt"] += (1 - hv["amt"]) * k
            else:
                hv["amt"] += (0 - hv["amt"]) * k
            if hv["amt"] < 0.03 or hv["cur"] is None:
                cv.itemconfigure(pill, state="hidden")
                return
            y = hv["cur"]
            cv.coords(pill, *rr_points(x1, y - rh / 2, x2, y + rh / 2, 12))
            cv.itemconfigure(pill, state="normal", fill=mix(mid, L.a1, 0.30 * hv["amt"]))

        sc.on(hover_step)

        # ---- navigation
        nav = [
            ("home", "Dashboard", None, True, None),
            ("chat", "Start Chatting", app.show_chat_screen, False, None),
            ("people", "My Groups", app.show_groups_screen, False, None),
            ("status", "Status", app.show_status_screen, False, d.get("status_count") or None),
            ("bars", "Chat Analytics", app.open_chat_analytics, False, None),
            ("star", "Starred Messages", app.open_starred_messages, False, None),
            ("sun", "Themes", app.show_themes_screen, False, None),
            ("settings", "Settings", app.show_settings_screen, False, None),
        ]
        y0, pitch = 124, 44

        def row(i, y, icon, label, cb, active=False, badge=None, delay=0.0):
            tag = "nav%d" % i
            mk = sc.mark()
            txt = ico = None
            if active:
                im, mg = pill_image(x2 - x1, rh, 12, L.p1, L.a2, glow=L.a1)
                self.img(x1 - mg, y - rh / 2 - mg, im, "nw")
                cv.create_oval(x2 - 20, y - 3, x2 - 14, y + 3, fill="#FFFFFF", outline="")
                self.img(x1 + 22, y, get_icon(icon, 19, "#FFFFFF"))
                txt = self.t(x1 + 44, y, label, 10, "bold", "#FFFFFF", "w")
            else:
                self.img(x1 + 22, y, get_icon(icon, 19, label_col))
                txt = self.t(x1 + 44, y, label, 10, "normal", label_col, "w")
                if badge:
                    bx = x2 - 22
                    sc.pulse_rings(bx, y, 8, 15, L.red, mid, period=1.8, count=2, follow=tag)
                    cv.create_oval(bx - 9, y - 9, bx + 9, y + 9, fill=L.red, outline="")
                    self.t(bx, y, str(min(99, badge)), 7, "bold", "#FFFFFF", "center")
            self.grp(tag, mk, (-34, 0), delay)
            if not active:
                def enter(y=y, tag=tag, txt=txt):
                    hv["y"] = y
                    cv.itemconfigure(txt, fill="#FFFFFF")
                    sc.hover_group(tag, 5, 0)

                def leave(tag=tag, txt=txt):
                    hv["y"] = None
                    cv.itemconfigure(txt, fill=label_col)
                    sc.hover_group(tag, 0, 0)
                self.hit((x1, y - rh / 2, x2, y + rh / 2), cb, enter, leave)

        y = y0
        for i, (icon, label, cb, active, badge) in enumerate(nav):
            row(i, y, icon, label, cb, active, badge, 0.10 + 0.05 * i)
            y += pitch

        sep = y - 10
        cv.create_line(20, sep, W - 20, sep, fill=mix(L.sb_bot, "#FFFFFF", 0.12))
        self.t(26, sep + 20, "ACCOUNT", 7, "bold", dim_col, "w")
        y = sep + 46
        row(20, y, "user", "Profile", app.upload_profile_pic, delay=0.55)
        y += pitch
        row(21, y, "power", "Logout", app.handle_logout, delay=0.60)

        # ---- user chip (only when there is room)
        cy = H - 46
        if cy - 26 > y + 28:
            self._user_chip(W, cy)

    def _user_chip(self, W, cy):
        L, cv, sc, d = self.look, self.cv, self.sc, self.d
        mk = sc.mark()
        w, h = W - 24, 50
        gi = glass_image(w, h, 14, fill=(255, 255, 255, 18), border=(255, 255, 255, 40))
        self.img(12, cy - h / 2, gi, "nw")
        name = d.get("username") or "?"
        dp = dp_avatar(d.get("dp_path"), 30, L.a1)
        if dp is not None:
            self.img(34, cy, dp)
        else:
            self.img(34, cy, make_avatar(30, L.a1b, L.a2))
            self.t(34, cy, name[0].upper(), 11, "bold", "#FFFFFF", "center")
        self.t(60, cy - 8, name, 9, "bold", "#FFFFFF", "w")
        self.t(70, cy + 9, "Online", 7, "bold", mix(L.green, "#FFFFFF", 0.25), "w")
        gx, gy = 63, cy + 9
        cv.create_oval(gx - 3, gy - 3, gx + 3, gy + 3, fill=L.green, outline="")
        self.sc.pulse_rings(gx, gy, 3, 8, L.green, mix(L.sb_top, L.sb_bot, 0.9), period=2.0, count=1, follow="sb_chip")
        self.grp("sb_chip", mk, (0, 30), 0.7)


# -------------------------------------------------------------- content ----
class ContentPage(Page):
    min_w, min_h = 500, 250
    scroll_h = 720

    TIPS = [
        ("Press this to jump straight to chat search", "Ctrl + K"),
        ("Right-click any message to reply, edit or star it", "Right-click"),
        ("Press Esc anywhere to return to your dashboard", "Esc"),
        ("Create a group to chat with everyone at once", "My Groups"),
        ("Pick a new look any time from the Themes page", "Themes"),
    ]

    def __init__(self, cv, look, app, data):
        super().__init__(cv, look)
        self.app, self.d = app, data
        self.uid = app.current_user_id
        self.msgs = data.get("msgs") or []

    # -------------------------------------------------------- build ----
    def build(self, W, H):
        L = self.look
        self.aurora(W, H)
        m, rw, gap = 26, 250, 20
        mw = W - 2 * m - rw - gap
        rx = m + mw + gap
        self._header(m, mw)
        self._stats(m, 92, mw)
        y2, rh2 = 216, 310
        if mw >= 480:
            w1 = int(mw * 0.57)
            self._recent(m, y2, w1, rh2)
            self._weekly(m + w1 + 16, y2, mw - w1 - 16, rh2)
        else:                      # very narrow window: recent conversations take the full width
            self._recent(m, y2, mw, rh2)
        self._banner(m, y2 + rh2 + 16, mw, 80)
        self._right(rx, rw)
        fy = max(y2 + rh2 + 16 + 80 + 18, H - 44)
        self.t(m, fy, "Better conversations.  Real connections.", 9, "normal", L.muted)
        self.t(m + mw, fy, "Smart Chat \u2022 Secure \u2022 Modern", 8, "bold", L.a1, "ne")

    # ------------------------------------------------------- header ----
    def _header(self, m, mw):
        L, cv, sc, d, app = self.look, self.cv, self.sc, self.d, self.app
        name = d.get("username") or ""
        t1 = self.t(m, 20, "Welcome back,", 15, "bold", L.muted)
        nx = m + tkfont.Font(family=FONT, size=15, weight="bold").measure("Welcome back, ") + 4
        t2 = self.t(nx, 20, name + "!", 15, "bold", L.a1)
        sub_txt = "Stay connected. Build stronger relationships."
        t3 = self.t(m, 50, "" if self.first else sub_txt, 9, "normal", L.muted)
        if self.first:
            sc.typewrite(t1, "Welcome back,", cps=34, delay=0.05)
            sc.typewrite(t2, name + "!", cps=14, delay=0.5)
            sc.typewrite(t3, sub_txt, cps=55, delay=0.7)

        # search pill + bell
        bell_cx = m + mw - 18
        left_w = max(tkfont.Font(family=FONT, size=9).measure(sub_txt),
                     tkfont.Font(family=FONT, size=15, weight="bold").measure("Welcome back, " + name + "!"))
        avail = mw - left_w - 24 - 52
        sw = int(min(300, avail)) if avail >= 130 else 40          # squeezed -> icon-only button
        sx = bell_cx - 34 - sw
        mk = sc.mark()
        ids = self.card(sx, 18, sw, 40, 20)
        self.img(sx + (20 if sw > 60 else sw / 2.0), 38, get_icon("search", 16, L.muted))
        phrases = ["Search conversations...", "Find a friend...", "Try Ctrl + K", "Jump to a chat..."]
        ph = self.t(sx + 40, 38, phrases[0] if sw > 60 else "", 9, "normal", L.muted, "w")
        t0 = clock()

        def ph_step(dt, now):
            if sw <= 60:
                return False
            c = ((now - t0) / 3.4)
            i = int(c) % len(phrases)
            f = clamp01((c % 1.0) / 0.28)
            s = phrases[i]
            cv.itemconfigure(ph, text=s[:max(1, int(round(len(s) * f)))])

        sc.on(ph_step, every=3)
        self.grp("hd_search", mk, (0, -16), 0.15)
        on, off = self.hover_card(ids, "hd_search", 0)
        self.hit((sx, 18, sx + sw, 58), app._focus_global_search, on, off)

        mk = sc.mark()
        cv.create_oval(bell_cx - 19, 38 - 19 + 0, bell_cx + 19, 38 + 19, fill=L.card_top, outline=L.line)
        self.img(bell_cx, 39, get_icon("bell", 16, L.a1))
        if d.get("status_count"):
            sc.pulse_rings(bell_cx + 9, 28, 4, 11, L.red, L.page, period=1.7, count=2, follow="hd_bell")
            cv.create_oval(bell_cx + 5, 24, bell_cx + 13, 32, fill=L.red, outline=L.card_top, width=2)
        self.grp("hd_bell", mk, (0, -16), 0.25)
        self.hit((bell_cx - 19, 19, bell_cx + 19, 57), app.show_status_screen,
                 lambda: sc.hover_group("hd_bell", 0, -2), lambda: sc.hover_group("hd_bell", 0, 0))

    # -------------------------------------------------------- stats ----
    def _stats(self, m, y, mw):
        L, cv, sc, d, app = self.look, self.cv, self.sc, self.d, self.app
        gap, h = 12, 108
        sw = (mw - 2 * gap) / 3.0
        uid = self.uid
        _, sent14 = daily_counts(self.msgs, uid, 14, "sent")
        rows = d.get("group_rows") or []
        today = datetime.now().date()
        groups14 = []
        for i in range(14):
            day = today - timedelta(days=13 - i)
            n = 0
            for g in rows:
                t = parse_ts(g[3])
                if t is None or t.date() <= day:
                    n += 1
            groups14.append(n)
        sv = d.get("status_updates", 0)
        status14 = [sv * (0.35 + 0.65 * i / 13.0) for i in range(14)]
        tp = trend_pct(sent14)
        specs = [
            ("chat", "Messages", d.get("sent", 0), L.a1, L.a1b, sent14, ("%s%d%%" % ("+" if tp >= 0 else "\u2212", abs(tp)), L.green if tp >= 0 else L.red), app.show_chat_screen),
            ("people", "Groups", d.get("groups", 0), L.green, L.a3, groups14, ("total", L.green), app.show_groups_screen),
            ("megaphone", "Status", sv, L.a2, L.pink, status14, ("active", L.a2), app.show_status_screen),
        ]
        for i, (icon, label, val, c1, c2, series, chip, cb) in enumerate(specs):
            x = m + i * (sw + gap)
            tag = "stat%d" % i
            mk = sc.mark()
            ids = self.card(x, y, sw, h, 16)
            self.img(x + 34, y + 33, make_avatar(36, c1, c2))
            self.img(x + 34, y + 33, get_icon(icon, 17, "#FFFFFF"))
            self.t(x + 64, y + 17, label, 9, "normal", L.muted)
            n = self.t(x + 64, y + 33, "{:,}".format(val), 21, "bold", L.text)
            self.num(n, val, 0.35 + 0.12 * i)
            if sw >= 172:
                cw = max(36, 12 + len(chip[0]) * 6)
                cx2 = x + sw - 16
                cv.create_polygon(rr_points(cx2 - cw, y + 13, cx2, y + 31, 9), smooth=True,
                                  fill=mix(L.card_bot, chip[1], 0.16), outline="")
                self.t(cx2 - cw / 2, y + 22, chip[0], 8, "bold", chip[1], "center")
            self.spark(x + 16, y + 72, sw - 32, 26, series, c1, tag, delay=0.55 + 0.12 * i)
            self.grp(tag, mk, (0, 30), 0.12 + 0.1 * i)
            on, off = self.hover_card(ids, tag, -5)
            self.hit((x, y, x + sw, y + h), cb, on, off)

    # ------------------------------------------------------- recent ----
    def _recent(self, x, y, w, h):
        L, cv, sc, d, app = self.look, self.cv, self.sc, self.d, self.app
        mk = sc.mark()
        self.card(x, y, w, h, 16)
        self.t(x + 20, y + 22, "Recent Conversations", 11, "bold", L.text)
        va = self.t(x + w - 20, y + 23, "View all  \u2192", 9, "bold", L.a1, "ne")
        cv.create_line(x + 20, y + 50, x + w - 20, y + 50, fill=L.line)
        self.grp("rc_head", mk, (0, 30), 0.38)
        self.hit((x + w - 110, y + 8, x + w - 8, y + 40), app.show_chat_screen,
                 lambda: cv.itemconfigure(va, fill=L.a2), lambda: cv.itemconfigure(va, fill=L.a1))
        rows = (d.get("recent") or [])[:5]
        if not rows:
            self._empty(x, y, w, h)
            return
        maxc = max([r[2] for r in rows] + [1])
        pal = [(L.a1b, L.a1), (L.green, L.a3), (L.a2, L.pink), ("#F59E0B", "#EF4444"), (L.a3, L.a1)]
        rowh = 46
        for i, (cid, uname, cnt, ago) in enumerate(rows):
            ry = y + 62 + i * rowh
            tag = "rc%d" % i
            mk = sc.mark()
            hov = cv.create_polygon(rr_points(x + 10, ry - 2, x + w - 10, ry + rowh - 6, 12), smooth=True,
                                    fill=mix(L.card_bot, L.a1, 0.09), outline="", state="hidden")
            c1, c2 = pal[i % len(pal)]
            self.img(x + 38, ry + 19, make_avatar(34, c1, c2))
            self.t(x + 38, ry + 19, (uname or "?")[0].upper(), 12, "bold", "#FFFFFF", "center")
            self.t(x + 66, ry + 7, uname, 10, "bold", L.text)
            self.t(x + 66, ry + 25, "%d messages" % cnt, 8, "normal", L.muted)
            if ago:
                self.t(x + w - 52, ry + 19, ago, 8, "normal", L.muted, "e")
            # activity bar (only when the card is wide enough to fit it beside the name)
            bw, bx, by = 56, x + w - 196, ry + 19
            fr = max(0.08, cnt / float(maxc))
            if w >= 320:
                cv.create_line(bx, by, bx + bw, by, fill=L.line, width=5, capstyle="round")
                bar = cv.create_line(bx, by, bx + 1, by, fill=c1, width=5, capstyle="round")
            else:
                bar = None
            chev = self.img(x + w - 24, ry + 19, get_icon("chevron", 11, L.muted))
            self.grp(tag, mk, (36, 0), 0.45 + 0.07 * i)

            if bar is not None:
                def grow(p, bar=bar, bx=bx, by=by, bw=bw, fr=fr, tag=tag):
                    ox, oy = sc.off(tag)
                    cv.coords(bar, bx + ox, by + oy, bx + ox + max(1.0, bw * fr * p), by + oy)
                sc.tween(self.dur(0.9), grow, delay=(0.9 + 0.07 * i) if self.first else 0.0, ease=ease_out_back)

            def enter(hov=hov, tag=tag, chev=chev):
                cv.itemconfigure(hov, state="normal")
                sc.hover_group(tag, 4, 0)

            def leave(hov=hov, tag=tag):
                cv.itemconfigure(hov, state="hidden")
                sc.hover_group(tag, 0, 0)
            self.hit((x + 8, ry - 2, x + w - 8, ry + rowh - 6),
                     (lambda c=cid, n=uname: app._open_chat_with(c, n)), enter, leave)
        # hover polygons sit above the card but below rows because they are created per-row before the row text

    def _empty(self, x, y, w, h):
        L, cv, sc, app = self.look, self.cv, self.sc, self.app
        cx, cy = x + w / 2.0, y + 128
        bgc = mix(L.card_top, L.card_bot, 0.5)
        mk = sc.mark()
        sc.pulse_rings(cx, cy, 36, 62, L.a1, bgc, period=3.0, count=2, strength=0.6, follow="emp")
        self.img(cx, cy, make_avatar(70, mix(L.a1b, "#FFFFFF", 0.55), mix(L.a1, "#FFFFFF", 0.30)))
        self.img(cx, cy, get_icon("chat", 30, L.a1))
        sc.spin_ring(cx, cy, 45, L.a1, L.a3, bgc, width=2, segs=14, sweep=240, speed=110)
        self.t(cx, y + 206, "No conversations yet", 12, "bold", L.text, "center")
        self.t(cx, y + 228, "Start chatting to connect with friends.", 9, "normal", L.muted, "center")
        bw, bh = 168, 36
        im, mg = pill_image(bw, bh, 18, L.p1, L.a2, glow=L.a1)
        imh, mgh = pill_image(bw, bh, 18, L.a2, L.p1, glow=L.a1, glow_a=200)
        b1 = self.img(cx - bw / 2 - mg, y + 252 - mg, im, "nw")
        b2 = self.img(cx - bw / 2 - mgh, y + 252 - mgh, imh, "nw", state="hidden")
        self.t(cx, y + 252 + bh / 2, "Start chatting  \u2192", 10, "bold", "#FFFFFF", "center")
        self.grp("emp", mk, (0, 26), 0.5)
        # floating chat bubbles
        for k, (dx, dy, bwid, col, ph) in enumerate([(-92, -52, 46, L.a3, 0.0), (86, -34, 38, L.pink, 1.9), (70, 36, 30, L.a2, 3.6)]):
            mk = sc.mark()
            bx, by = cx + dx - bwid / 2, cy + dy - 11
            cv.create_polygon(rr_points(bx, by, bx + bwid, by + 22, 11), smooth=True, fill=mix(bgc, col, 0.22), outline=mix(bgc, col, 0.5))
            for j in range(3):
                dxj = bx + bwid / 2 - 8 + j * 8
                cv.create_oval(dxj - 2, by + 9, dxj + 2, by + 13, fill=col, outline="")
            self.grp("eb%d" % k, mk, None, 0)
            sc.bob("eb%d" % k, 4.5, 3.2 + k * 0.6, ph)

        def on():
            cv.itemconfigure(b1, state="hidden")
            cv.itemconfigure(b2, state="normal")

        def off():
            cv.itemconfigure(b1, state="normal")
            cv.itemconfigure(b2, state="hidden")
        self.hit((cx - bw / 2, y + 252, cx + bw / 2, y + 252 + bh), app.show_chat_screen, on, off)

    # ------------------------------------------------------- weekly ----
    def _weekly(self, x, y, w, h):
        L, cv, sc = self.look, self.cv, self.sc
        keys, vals = daily_counts(self.msgs, self.uid, 7, "all")
        total = sum(vals)
        mk = sc.mark()
        self.card(x, y, w, h, 16)
        self.t(x + 20, y + 22, "Weekly Activity", 11, "bold", L.text)
        self.t(x + 20, y + 42, "Messages \u00b7 last 7 days", 8, "normal", L.muted)
        tn = self.t(x + w - 20, y + 20, "{:,}".format(total), 18, "bold", L.a1, "ne")
        self.num(tn, total, 0.5)
        self.grp("wk_head", mk, (0, 30), 0.46)

        top_y, base_y = y + 92, y + h - 46
        mh = base_y - top_y
        n = 7
        x0, x1 = x + 22, x + w - 22
        slot = (x1 - x0) / float(n)
        bwid = max(12, min(30, slot * 0.52))
        vmax = max(vals + [1])
        best = vals.index(max(vals)) if total else -1
        tip_bg = cv.create_polygon(rr_points(0, 0, 10, 10, 6), smooth=True, fill=L.text, outline="", state="hidden")
        tip_tx = cv.create_text(0, 0, text="", font=(FONT, 8, "bold"), fill=L.card_top, state="hidden")
        mk = sc.mark()
        bars = []
        for i, v in enumerate(vals):
            cx = x0 + slot * (i + 0.5)
            track = cv.create_polygon(rr_points(cx - bwid / 2, top_y, cx + bwid / 2, base_y, bwid / 2), smooth=True,
                                      fill=L.soft, outline="")
            col = L.a2 if i == best else L.a1
            bar = cv.create_polygon(rr_points(cx - bwid / 2, base_y - 4, cx + bwid / 2, base_y, 2), smooth=True,
                                    fill=mix(L.soft, col, 0.85 if v else 0.35), outline="")
            today = keys[i] == datetime.now().date()
            self.t(cx, base_y + 18, WEEKDAYS[keys[i].weekday()][:2 if slot < 30 else 3], 8, "bold" if today else "normal",
                   L.a1 if today else L.muted, "center")
            bars.append((cx, track, bar, v))
        self.grp("wk_bars", mk, (0, 34), 0.5)
        if not total:
            self.t(x + w / 2, top_y + mh / 2 - 6, "No activity yet", 10, "bold", L.muted, "center")
            self.t(x + w / 2, top_y + mh / 2 + 12, "Send a message to see your week", 8, "normal", L.muted, "center")

        def grow(p):
            ox, oy = sc.off("wk_bars")
            for i, (cx, track, bar, v) in enumerate(bars):
                q = clamp01(p * 1.25 - i * 0.07)
                hh = 4 + (mh - 4) * (v / float(vmax)) * ease_out_back(q) if v else 4
                hh = max(4, min(mh, hh))
                cv.coords(bar, *rr_points(cx - bwid / 2 + ox, base_y - hh + oy, cx + bwid / 2 + ox, base_y + oy, min(bwid / 2, hh / 2)))
        sc.tween(self.dur(1.1), grow, delay=0.85 if self.first else 0.0, ease=lambda t: t)

        for i, (cx, track, bar, v) in enumerate(bars):
            def enter(i=i, cx=cx, track=track, v=v):
                cv.itemconfigure(track, fill=mix(L.soft, L.a1, 0.22))
                ox, oy = sc.off("wk_bars")
                hh = 4 + (mh - 4) * (v / float(vmax)) if v else 4
                s = "%d msg%s" % (v, "" if v == 1 else "s")
                wd = 12 + len(s) * 5.4
                ty = base_y - hh - 20 + oy
                cv.coords(tip_bg, *rr_points(cx - wd / 2 + ox, ty - 9, cx + wd / 2 + ox, ty + 9, 7))
                cv.coords(tip_tx, cx + ox, ty)
                cv.itemconfigure(tip_tx, text=s, state="normal")
                cv.itemconfigure(tip_bg, state="normal")
                cv.tag_raise(tip_bg)
                cv.tag_raise(tip_tx)

            def leave(track=track):
                cv.itemconfigure(track, fill=L.soft)
                cv.itemconfigure(tip_bg, state="hidden")
                cv.itemconfigure(tip_tx, state="hidden")
            self.hit((cx - slot / 2, top_y - 24, cx + slot / 2, base_y + 4), None, enter, leave)

    # ------------------------------------------------------- banner ----
    def _banner(self, x, y, w, h):
        L, cv, sc = self.look, self.cv, self.sc
        mk = sc.mark()
        im, mg = pill_image(w, h, 18, L.p1, L.a2, glow=L.a2, glow_a=90)
        self.img(x - mg, y - mg, im, "nw")
        lab = self.t(x + 26, y + 17, "PRO TIP", 7, "bold", mix(L.p1, "#FFFFFF", 0.70))
        tip = self.t(x + 26, y + 34, self.TIPS[0][0], 11, "bold", "#FFFFFF")
        chip_w = 96
        cx2 = x + w - 24
        chip = cv.create_polygon(rr_points(cx2 - chip_w, y + h / 2 - 14, cx2, y + h / 2 + 14, 14), smooth=True,
                                 fill=mix(L.p1, "#FFFFFF", 0.20), outline=mix(L.p1, "#FFFFFF", 0.45))
        chip_t = self.t(cx2 - chip_w / 2, y + h / 2, self.TIPS[0][1], 9, "bold", "#FFFFFF", "center")
        # flowing waves along the bottom edge (kept inside the rounded rect)
        base_col = mix(L.p1, L.a2, 0.35)
        wx0, wx1 = x + 24, x + w - 24
        n = max(12, int((wx1 - wx0) / 14))
        waves = [cv.create_line(0, 0, 0, 0, fill=mix(base_col, "#FFFFFF", f), width=2, smooth=True)
                 for f in (0.30, 0.48, 0.70)]
        self.grp("banner", mk, (0, 30), 0.7)

        def step(dt, now):
            ox, oy = sc.off("banner")
            for k, wv in enumerate(waves):
                pts = []
                for i in range(n + 1):
                    px = wx0 + (wx1 - wx0) * i / float(n)
                    py = y + h - 17 - k * 3.0 + math.sin(now * (0.9 + k * 0.35) + i * 0.42 + k) * (5.4 - k * 0.8)
                    pts += [px + ox, py + oy]
                cv.coords(wv, *pts)
            c = (now / 5.0)
            i = int(c) % len(self.TIPS)
            f = c % 1.0
            vis = clamp01(f / 0.07) * clamp01((1 - f) / 0.07)
            s, k2 = self.TIPS[i]
            cv.itemconfigure(tip, text=s, fill=mix(base_col, "#FFFFFF", vis))
            cv.itemconfigure(chip_t, text=k2, fill=mix(base_col, "#FFFFFF", vis))
        sc.on(step, every=2)

    # -------------------------------------------------------- right ----
    def _right(self, rx, rw):
        L, cv, sc, d, app = self.look, self.cv, self.sc, self.d, self.app
        name = d.get("username") or "?"
        cxm = rx + rw / 2.0
        # profile card
        mk = sc.mark()
        top = mix(L.card_top, L.a1, 0.07 if not L.dark else 0.10)
        ids = self.card(rx, 20, rw, 200, 20, top=top)
        self.t(rx + 20, 42, "Profile", 10, "bold", L.text)
        self.t(rx + rw - 20, 40, "\u203a", 16, "normal", L.a1, "ne")
        self.grp("pf_card", mk, (30, 0), 0.2)
        on, off = self.hover_card(ids, "pf_card", 0)
        self.hit((rx, 20, rx + rw, 220), app.show_settings_screen, on, off)
        mk = sc.mark()
        acy = 96
        bgc = mix(top, L.card_bot, 0.5)
        sc.pulse_rings(cxm, acy, 36, 56, L.a1, bgc, period=3.2, count=2, strength=0.55, follow="pf_av")
        dp = dp_avatar(d.get("dp_path"), 68, L.a1)
        if dp is not None:
            self.img(cxm, acy, dp)
        else:
            self.img(cxm, acy, make_avatar(68, L.a1b, L.a2))
            self.t(cxm, acy, name[0].upper(), 23, "bold", "#FFFFFF", "center")
        sc.spin_ring(cxm, acy, 42, L.a3, L.a2, bgc, width=3, segs=18, sweep=250, speed=120)
        self.grp("pf_av", mk, (30, 0), 0.3)
        sc.bob("pf_av", 2.5, 3.8, 0.0)
        mk = sc.mark()
        self.t(cxm, 154, name, 12, "bold", L.text, "center")
        gx, gy = cxm - 22, 179
        cv.create_oval(gx - 5, gy - 5, gx + 5, gy + 5, fill=L.green, outline="")
        sc.pulse_rings(gx, gy, 5, 12, L.green, bgc, period=2.0, count=2, strength=0.8, follow="pf_txt")
        self.t(gx + 12, gy, "Online", 9, "bold", L.green, "w")
        self.grp("pf_txt", mk, (30, 0), 0.34)

        # action rows
        def action(i, y, icon, label, cb, color, h=48, fill=None, border=None, txt_col=None, delay=0.0, glow=None):
            tag = "ar%d" % i
            mk = sc.mark()
            ids = self.card(rx, y, rw, h, 14, top=fill, bot=fill, border=border, glow=glow or color)
            cyy = y + h / 2.0
            cv.create_oval(rx + 14, cyy - 14, rx + 42, cyy + 14, fill=mix(fill or L.card_top, color, 0.16), outline="")
            self.img(rx + 28, cyy, get_icon(icon, 16, color))
            self.t(rx + 54, cyy, label, 9, "bold", txt_col or L.text, "w")
            self.grp(tag, mk, (36, 0), delay)
            mk = sc.mark()
            self.t(rx + rw - 18, cyy - 1, "\u203a", 15, "normal", txt_col or L.muted, "e")
            self.grp(tag + "c", mk, (36, 0), delay)
            on, off = self.hover_card(ids, tag, -3)

            def enter():
                on()
                sc.hover_group(tag + "c", 5, 0)

            def leave():
                off()
                sc.hover_group(tag + "c", 0, 0)
            self.hit((rx, y, rx + rw, y + h), cb, enter, leave)
            return cyy

        action(0, 234, "image", "Update Profile Picture", app.upload_profile_pic, L.a1, delay=0.38)
        warm = L.dark
        star_fill = mix(L.surface, "#F59E0B", 0.14) if warm else "#FFFBEB"
        star_border = mix(L.surface, "#F59E0B", 0.40) if warm else "#FDE68A"
        scy = action(1, 292, "star", "Starred Messages", app.open_starred_messages, "#F59E0B", fill=star_fill,
                     border=star_border, txt_col="#FBBF24" if warm else "#B45309", delay=0.44)
        # twinkling sparkle next to the star icon
        spark = cv.create_polygon(0, 0, 0, 0, 0, 0, 0, 0, fill="#FBBF24", outline="")

        def twinkle(dt, now):
            ox, oy = sc.off("ar1")
            r = 3.0 + 2.2 * (0.5 + 0.5 * math.sin(now * 3.1))
            cxs, cys = rx + 38 + ox, scy - 11 + oy
            q = r * 0.28
            cv.coords(spark, cxs, cys - r, cxs + q, cys - q, cxs + r, cys, cxs + q, cys + q,
                      cxs, cys + r, cxs - q, cys + q, cxs - r, cys, cxs - q, cys - q)
        sc.on(twinkle, every=2)

        mk = sc.mark()
        self.t(rx, 366, "Quick Actions", 10, "bold", L.text)
        self.grp("qa_t", mk, (30, 0), 0.5)
        acts = [("chat", "New Chat", app.show_chat_screen, L.a1),
                ("people", "Create Group", app.show_groups_screen, L.a2),
                ("settings", "Open Settings", app.show_settings_screen, L.a3)]
        for k, (icon, label, cb, col) in enumerate(acts):
            action(2 + k, 388 + k * 54, icon, label, cb, col, h=46, delay=0.54 + 0.06 * k)


class DashboardFX:
    """Owns the sidebar + content pages of one dashboard instance."""

    def __init__(self, app, side_cv, content_cv, C, data):
        self.look = Look(C)
        self.side = SidebarPage(side_cv, self.look, app, data)
        self.content = ContentPage(content_cv, self.look, app, data)
