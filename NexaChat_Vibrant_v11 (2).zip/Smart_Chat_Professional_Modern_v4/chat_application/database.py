import sqlite3
from datetime import datetime

# ==================== MOTIVATION MODE DATA ====================

SITUATIONS = [
    {"id": "study",   "label": "📚 Study / Exams",       "color": "#4A90D9"},
    {"id": "work",    "label": "💼 Work / Productivity",  "color": "#27AE60"},
    {"id": "breakup", "label": "💔 Breakup / Emotional",  "color": "#E74C3C"},
    {"id": "low",     "label": "😔 Feeling Low",          "color": "#8E44AD"},
    {"id": "lazy",    "label": "😴 Lazy / No Motivation", "color": "#F39C12"},
    {"id": "anger",   "label": "😠 Anger / Frustration",  "color": "#C0392B"},
    {"id": "goals",   "label": "🎯 Goals / Success",      "color": "#2ECC71"},
    {"id": "peace",   "label": "🕊️ Peace / Spiritual",   "color": "#1ABC9C"},
]

QUOTES = [
    # ── STUDY / EXAMS ──────────────────────────────────────────────────────
    {"id": "Q001", "text_en": "Education is the most powerful weapon which you can use to change the world.",
     "text_te": "విద్య అనేది మీరు ప్రపంచాన్ని మార్చడానికి ఉపయోగించగల అత్యంత శక్తివంతమైన ఆయుధం.",
     "source": "Nelson Mandela", "category": "Philosophy", "tags": ["study", "goals"]},
    {"id": "Q002", "text_en": "Success is the sum of small efforts, repeated day in and day out.",
     "text_te": "విజయం అనేది రోజూ పునరావృతమయ్యే చిన్న చిన్న ప్రయత్నాల మొత్తం.",
     "source": "Robert Collier", "category": "Success", "tags": ["study", "work", "goals", "lazy"]},
    {"id": "Q003", "text_en": "The mind is everything. What you think, you become.",
     "text_te": "మనసే సర్వస్వం. మీరు ఏమి అనుకుంటే అదే అవుతారు.",
     "source": "Buddha", "category": "Philosophy", "tags": ["study", "goals", "peace", "low"]},
    {"id": "Q004", "text_en": "Arise, awake, and stop not till the goal is reached.",
     "text_te": "లేచి, మేల్కొని, లక్ష్యం సాధించే వరకు ఆగకు.",
     "source": "Swami Vivekananda", "category": "Philosophy", "tags": ["study", "goals", "lazy", "work"]},
    {"id": "Q005", "text_en": "A person who never made a mistake never tried anything new.",
     "text_te": "ఎప్పుడూ తప్పు చేయని వ్యక్తి ఎప్పుడూ కొత్తది ప్రయత్నించలేదు.",
     "source": "Albert Einstein", "category": "Psychology", "tags": ["study", "work", "goals"]},
    {"id": "Q006", "text_en": "The secret of getting ahead is getting started.",
     "text_te": "ముందుకు వెళ్ళే రహస్యం మొదలుపెట్టడమే.",
     "source": "Mark Twain", "category": "Success", "tags": ["study", "lazy", "work"]},
    {"id": "Q007", "text_en": "Without knowledge, action is useless. Without action, knowledge is futile.",
     "text_te": "జ్ఞానం లేకుండా చర్య నిరర్థకం. చర్య లేకుండా జ్ఞానం వ్యర్థం.",
     "source": "Abu Bakr", "category": "Philosophy", "tags": ["study", "work"]},
    # ── WORK / PRODUCTIVITY ────────────────────────────────────────────────
    {"id": "Q008", "text_en": "The only way to do great work is to love what you do.",
     "text_te": "గొప్ప పని చేయడానికి ఏకైక మార్గం మీరు చేసేది ప్రేమించడం.",
     "source": "Steve Jobs", "category": "Success", "tags": ["work", "goals"]},
    {"id": "Q009", "text_en": "Karm kar, phal ki chinta mat kar — Do your duty, do not worry about the fruit.",
     "text_te": "కర్మ చేయి, ఫలితం గురించి ఆందోళన చేయకు. — భగవద్గీత",
     "source": "Bhagavad Gita", "category": "Bhagavad Gita", "tags": ["work", "goals", "anger", "lazy"]},
    {"id": "Q010", "text_en": "You have the right to perform your actions, but not to the fruits of the actions.",
     "text_te": "మీకు కర్మ చేసే హక్కు ఉంది, కానీ ఫలాలపై హక్కు లేదు.",
     "source": "Bhagavad Gita 2.47", "category": "Bhagavad Gita", "tags": ["work", "goals", "peace"]},
    {"id": "Q011", "text_en": "It always seems impossible until it is done.",
     "text_te": "పూర్తయ్యే వరకు అది ఎప్పుడూ అసాధ్యంగా అనిపిస్తుంది.",
     "source": "Nelson Mandela", "category": "Success", "tags": ["work", "goals", "lazy"]},
    # ── BREAKUP / EMOTIONAL ───────────────────────────────────────────────
    {"id": "Q012", "text_en": "The wound is the place where the Light enters you.",
     "text_te": "గాయం అనేది వెలుతురు మీలోకి ప్రవేశించే స్థలం.",
     "source": "Rumi", "category": "Philosophy", "tags": ["breakup", "low"]},
    {"id": "Q013", "text_en": "Out of suffering have emerged the strongest souls.",
     "text_te": "బాధ నుండే అత్యంత బలమైన ఆత్మలు పుట్టుకొస్తాయి.",
     "source": "Kahlil Gibran", "category": "Philosophy", "tags": ["breakup", "low"]},
    {"id": "Q014", "text_en": "Letting go gives us freedom, and freedom is the only condition for happiness.",
     "text_te": "వదులుకోవడం మనకు స్వేచ్ఛనిస్తుంది, స్వేచ్ఛ మాత్రమే ఆనందానికి షరతు.",
     "source": "Thich Nhat Hanh", "category": "Philosophy", "tags": ["breakup", "peace"]},
    {"id": "Q015", "text_en": "Sometimes good things fall apart so better things can fall together.",
     "text_te": "కొన్నిసార్లు మంచి విషయాలు విడిపోతాయి, తద్వారా మెరుగైన విషయాలు కలుసుకోవచ్చు.",
     "source": "Marilyn Monroe", "category": "Psychology", "tags": ["breakup", "low"]},
    {"id": "Q016", "text_en": "Pain is inevitable. Suffering is optional.",
     "text_te": "నొప్పి తప్పనిసరి. బాధపడడం ఐచ్ఛికం.",
     "source": "Haruki Murakami", "category": "Psychology", "tags": ["breakup", "low", "anger"]},
    {"id": "Q017", "text_en": "In the Ramayana, Sita endured the greatest hardship with unshaken faith. Strength comes from within.",
     "text_te": "రామాయణంలో, సీత అచంచలమైన విశ్వాసంతో గొప్ప కష్టాన్ని భరించింది. బలం లోపల నుండే వస్తుంది.",
     "source": "Ramayana", "category": "Ramayana", "tags": ["breakup", "low", "peace"]},
    # ── FEELING LOW ───────────────────────────────────────────────────────
    {"id": "Q018", "text_en": "Even the darkest night will end and the sun will rise.",
     "text_te": "చీకటి రాత్రి కూడా ముగుస్తుంది మరియు సూర్యుడు ఉదయిస్తాడు.",
     "source": "Victor Hugo", "category": "Philosophy", "tags": ["low", "breakup"]},
    {"id": "Q019", "text_en": "You are stronger than you think. You have survived 100% of your worst days.",
     "text_te": "మీరు అనుకున్నదానికంటే బలంగా ఉన్నారు. మీరు మీ అత్యంత చెడు రోజులన్నింటినీ 100% మనుగడలో ఉన్నారు.",
     "source": "Unknown", "category": "Psychology", "tags": ["low", "breakup"]},
    {"id": "Q020", "text_en": "The Lotus rises from mud. So do you.",
     "text_te": "తామర మట్టి నుండి లేస్తుంది. మీరూ అలాగే లేస్తారు.",
     "source": "Buddhist Wisdom", "category": "Philosophy", "tags": ["low", "peace"]},
    {"id": "Q021", "text_en": "Krishna said: Never be depressed. Rise up, take courage, and fight.",
     "text_te": "కృష్ణుడు అన్నాడు: నిరాశపడకు. లేచి, ధైర్యం తీసుకో, పోరాడు.",
     "source": "Bhagavad Gita", "category": "Bhagavad Gita", "tags": ["low", "goals", "work"]},
    {"id": "Q022", "text_en": "One step at a time is all it takes to get you there.",
     "text_te": "ఒక్కో అడుగు వేయడమే మీకు అక్కడికి చేరుకోవడానికి అవసరం.",
     "source": "Emily Dickinson", "category": "Psychology", "tags": ["low", "lazy", "goals"]},
    # ── LAZY / NO MOTIVATION ──────────────────────────────────────────────
    {"id": "Q023", "text_en": "Do not wait to strike till the iron is hot, but make it hot by striking.",
     "text_te": "ఇనుము వేడెక్కే వరకు వేచి ఉండకు, కొట్టి వేడెక్కించు.",
     "source": "W.B. Yeats", "category": "Success", "tags": ["lazy", "work", "goals"]},
    {"id": "Q024", "text_en": "Discipline is choosing between what you want now and what you want most.",
     "text_te": "క్రమశిక్షణ అంటే మీకు ఇప్పుడు కావలసిన దానికి మరియు అత్యంత అవసరమైన దానికి మధ్య ఎంపిక.",
     "source": "Abraham Lincoln", "category": "Success", "tags": ["lazy", "study", "goals"]},
    {"id": "Q025", "text_en": "Action is the foundational key to all success.",
     "text_te": "చర్య అన్ని విజయాలకు పునాది కీలకం.",
     "source": "Pablo Picasso", "category": "Success", "tags": ["lazy", "goals", "work"]},
    {"id": "Q026", "text_en": "Small daily improvements over time lead to stunning results.",
     "text_te": "రోజువారీ చిన్న మెరుగుదలలు కాలక్రమేణా అద్భుతమైన ఫలితాలకు దారితీస్తాయి.",
     "source": "Robin Sharma", "category": "Success", "tags": ["lazy", "study", "work"]},
    {"id": "Q027", "text_en": "Hanuman crossed the ocean not by waiting but by leaping. Take your leap.",
     "text_te": "హనుమంతుడు వేచి ఉండటం వల్ల కాదు, దూకడం వల్ల సముద్రాన్ని దాటాడు. మీ దూకు వేయండి.",
     "source": "Ramayana", "category": "Ramayana", "tags": ["lazy", "goals", "work"]},
    # ── ANGER / FRUSTRATION ───────────────────────────────────────────────
    {"id": "Q028", "text_en": "Holding on to anger is like grasping a hot coal with the intent of throwing it at someone else.",
     "text_te": "కోపాన్ని పట్టుకోవడం వేరెవరికైనా విసరాలని వేడి బొగ్గు పట్టుకున్నట్లే.",
     "source": "Buddha", "category": "Philosophy", "tags": ["anger", "peace"]},
    {"id": "Q029", "text_en": "For every minute you remain angry, you give up sixty seconds of peace of mind.",
     "text_te": "మీరు కోపంగా ఉన్న ప్రతి నిమిషం, మీరు అరవై సెకన్ల మనశ్శాంతిని వదులుకుంటున్నారు.",
     "source": "Ralph Waldo Emerson", "category": "Philosophy", "tags": ["anger", "peace"]},
    {"id": "Q030", "text_en": "Anger is an acid that can do more harm to the vessel in which it is stored.",
     "text_te": "కోపం ఒక ఆమ్లం, ఇది పోసే దానికంటే నిల్వ చేసే పాత్రకు ఎక్కువ హాని చేస్తుంది.",
     "source": "Mark Twain", "category": "Philosophy", "tags": ["anger", "peace"]},
    {"id": "Q031", "text_en": "In the Mahabharata, Dharma always prevailed over ego and rage. Let dharma guide you.",
     "text_te": "మహాభారతంలో, ధర్మం ఎప్పుడూ అహంకారం మరియు రాగంపై విజయం సాధించింది.",
     "source": "Mahabharata", "category": "Mahabharata", "tags": ["anger", "peace", "goals"]},
    # ── GOALS / SUCCESS ───────────────────────────────────────────────────
    {"id": "Q032", "text_en": "The future belongs to those who believe in the beauty of their dreams.",
     "text_te": "భవిష్యత్తు తమ కలల అందాన్ని విశ్వసించేవారికి చెందుతుంది.",
     "source": "Eleanor Roosevelt", "category": "Success", "tags": ["goals", "study"]},
    {"id": "Q033", "text_en": "Excellence is not a destination; it is a continuous journey that never ends.",
     "text_te": "శ్రేష్ఠత ఒక గమ్యం కాదు; ఇది ఎప్పటికీ ముగియని నిరంతర ప్రయాణం.",
     "source": "Brian Tracy", "category": "Success", "tags": ["goals", "work", "study"]},
    {"id": "Q034", "text_en": "Arjuna fought not for glory, but for dharma. Fight your battle with purpose.",
     "text_te": "అర్జునుడు కీర్తి కోసం కాదు, ధర్మం కోసం పోరాడాడు. మీ యుద్ధాన్ని లక్ష్యంతో చేయండి.",
     "source": "Mahabharata", "category": "Mahabharata", "tags": ["goals", "work", "study"]},
    {"id": "Q035", "text_en": "Whatever you can do, or dream you can, begin it. Boldness has genius, power and magic in it.",
     "text_te": "మీరు ఏమి చేయగలిగినా, లేదా కలలు కనగలిగినా, దానిని ప్రారంభించండి.",
     "source": "Goethe", "category": "Philosophy", "tags": ["goals", "lazy"]},
    # ── PEACE / SPIRITUAL ─────────────────────────────────────────────────
    {"id": "Q036", "text_en": "Peace comes from within. Do not seek it without.",
     "text_te": "శాంతి లోపల నుండి వస్తుంది. దాన్ని బయట వెతకకండి.",
     "source": "Buddha", "category": "Philosophy", "tags": ["peace", "anger"]},
    {"id": "Q037", "text_en": "You are the universe experiencing itself.",
     "text_te": "మీరు తనను తాను అనుభవిస్తున్న విశ్వం.",
     "source": "Alan Watts", "category": "Philosophy", "tags": ["peace", "low"]},
    {"id": "Q038", "text_en": "Let go of what has passed. Let come what will.",
     "text_te": "జరిగిపోయింది వదిలేయండి. వచ్చేది రానీయండి.",
     "source": "Rumi", "category": "Philosophy", "tags": ["peace", "breakup", "anger"]},
    {"id": "Q039", "text_en": "The Gita teaches: Remain unattached to outcomes. Act in love and truth.",
     "text_te": "గీత నేర్పిస్తుంది: ఫలాలపై ఆసక్తి లేకుండా ఉండు. ప్రేమ మరియు సత్యంలో కర్మ చేయి.",
     "source": "Bhagavad Gita", "category": "Bhagavad Gita", "tags": ["peace", "work", "anger"]},
    {"id": "Q040", "text_en": "Breathe. You are exactly where you are supposed to be.",
     "text_te": "శ్వాస తీసుకో. మీరు సరిగ్గా ఉండాల్సిన చోట ఉన్నారు.",
     "source": "Lao Tzu", "category": "Philosophy", "tags": ["peace", "low", "breakup"]},
    {"id": "Q041", "text_en": "Surrender to what is, let go of what was, and have faith in what will be.",
     "text_te": "ఉన్నదానికి లొంగిపో, ఉన్నదాన్ని వదులుకో, మరియు ఉండబోయేదిపై విశ్వాసం ఉంచు.",
     "source": "Sonia Ricotti", "category": "Philosophy", "tags": ["peace", "breakup", "low"]},
    {"id": "Q042", "text_en": "Every day may not be good, but there is something good in every day.",
     "text_te": "ప్రతి రోజూ మంచిదిగా ఉండకపోవచ్చు, కానీ ప్రతి రోజూ ఏదో మంచిది ఉంటుంది.",
     "source": "Alice Morse Earle", "category": "Psychology", "tags": ["breakup", "low", "peace"]},
]


def get_quotes_for_situation(situation_id: str) -> list:
    """Return all quotes matching the given situation tag."""
    return [q for q in QUOTES if situation_id in q["tags"]]


def get_situation_by_id(situation_id: str):
    for s in SITUATIONS:
        if s["id"] == situation_id:
            return s
    return None


class ChatDB:
    def __init__(self, db_name="smart_chat.db"):
        self.conn = sqlite3.connect(db_name, check_same_thread=False)
        self.cursor = self.conn.cursor()
        self.create_tables()
        self.upgrade_database()

    def create_tables(self):
        # 1. Users Table
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                is_logged_in INTEGER DEFAULT 0,
                is_online INTEGER DEFAULT 0,
                last_seen TEXT,
                is_typing INTEGER DEFAULT 0,
                profile_pic TEXT DEFAULT ''
            )
        ''')

        # 2. Messages Table (reply_to column added for Reply feature)
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS messages (
                msg_id INTEGER PRIMARY KEY AUTOINCREMENT,
                sender_id INTEGER,
                recipient_id INTEGER,
                message_text TEXT,
                message_type TEXT DEFAULT 'text',
                file_path TEXT DEFAULT NULL,
                timestamp TEXT,
                is_deleted INTEGER DEFAULT 0, 
                status TEXT DEFAULT 'sent',
                is_starred INTEGER DEFAULT 0,
                reply_to INTEGER DEFAULT NULL,
                FOREIGN KEY (sender_id) REFERENCES users(user_id),
                FOREIGN KEY (recipient_id) REFERENCES users(user_id),
                FOREIGN KEY (reply_to) REFERENCES messages(msg_id)
            )
        ''')

        # 3. Blocked Messages Log
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS blocked_messages (
                msg_id INTEGER PRIMARY KEY AUTOINCREMENT,
                sender_id INTEGER,
                recipient_id INTEGER,
                message_text TEXT,
                timestamp TEXT,
                FOREIGN KEY (recipient_id) REFERENCES users(user_id),
                FOREIGN KEY (sender_id) REFERENCES users(user_id)
            )
        ''')

        # 4. Blocked Users Relationship
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS blocked_users (
                blocker_id INTEGER,
                blocked_id INTEGER,
                PRIMARY KEY (blocker_id, blocked_id),
                FOREIGN KEY (blocker_id) REFERENCES users(user_id),
                FOREIGN KEY (blocked_id) REFERENCES users(user_id)
            )
        ''')

        # 5. Groups Table
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS groups (
                group_id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_name TEXT NOT NULL,
                created_by INTEGER,
                created_at TEXT,
                group_icon TEXT DEFAULT '',
                FOREIGN KEY (created_by) REFERENCES users(user_id)
            )
        ''')

        # 6. Group Members Table
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS group_members (
                group_id INTEGER,
                user_id INTEGER,
                is_admin INTEGER DEFAULT 0,
                joined_at TEXT,
                PRIMARY KEY (group_id, user_id),
                FOREIGN KEY (group_id) REFERENCES groups(group_id),
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')

        # 7. Group Messages Table
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS group_messages (
                msg_id INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id INTEGER,
                sender_id INTEGER,
                message_text TEXT,
                message_type TEXT DEFAULT 'text',
                file_path TEXT DEFAULT NULL,
                timestamp TEXT,
                is_deleted INTEGER DEFAULT 0,
                is_starred INTEGER DEFAULT 0,
                FOREIGN KEY (group_id) REFERENCES groups(group_id),
                FOREIGN KEY (sender_id) REFERENCES users(user_id)
            )
        ''')

        # 8. Status Table (WhatsApp Style)
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS statuses (
                status_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                status_type TEXT DEFAULT 'text',
                content TEXT,
                file_path TEXT DEFAULT NULL,
                bg_color TEXT DEFAULT '#128C7E',
                font_size INTEGER DEFAULT 20,
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                is_deleted INTEGER DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        ''')

        # 9. Status Views Table (unique view per user — for "seen" badge tracking)
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS status_views (
                view_id INTEGER PRIMARY KEY AUTOINCREMENT,
                status_id INTEGER NOT NULL,
                viewer_id INTEGER NOT NULL,
                viewed_at TEXT NOT NULL,
                UNIQUE(status_id, viewer_id),
                FOREIGN KEY (status_id) REFERENCES statuses(status_id),
                FOREIGN KEY (viewer_id) REFERENCES users(user_id)
            )
        ''')

        # 10. Status View Logs Table (every view stored including repeats)
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS status_view_logs (
                log_id INTEGER PRIMARY KEY AUTOINCREMENT,
                status_id INTEGER NOT NULL,
                viewer_id INTEGER NOT NULL,
                viewed_at TEXT NOT NULL,
                FOREIGN KEY (status_id) REFERENCES statuses(status_id),
                FOREIGN KEY (viewer_id) REFERENCES users(user_id)
            )
        ''')


        self.conn.commit()

    def upgrade_database(self):
        # Existing DB ki new columns add chestundi (already exist aithe skip avutundi)
        columns = {
            "messages": [
                ("is_deleted", "INTEGER DEFAULT 0"),
                ("status", "TEXT DEFAULT 'sent'"),
                ("message_type", "TEXT DEFAULT 'text'"),
                ("file_path", "TEXT DEFAULT NULL"),
                ("is_starred", "INTEGER DEFAULT 0"),
                ("reply_to", "INTEGER DEFAULT NULL"),
                ("is_edited", "INTEGER DEFAULT 0"),
                ("edited_at", "TEXT DEFAULT NULL")
            ],
            "users": [
                ("last_seen", "TEXT"),
                ("is_typing", "INTEGER DEFAULT 0"),
                ("is_online", "INTEGER DEFAULT 0"),
                ("profile_pic", "TEXT DEFAULT ''")
            ]
        }
        for table, cols in columns.items():
            for col_name, col_type in cols:
                try:
                    self.cursor.execute(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_type}")
                except sqlite3.OperationalError:
                    pass


        # scheduled_messages table — Secret Delivery System
        # Receiver ki message existence theliyadu until unlock_time
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS scheduled_messages (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                sender_id    INTEGER NOT NULL,
                receiver_id  INTEGER NOT NULL,
                message_text TEXT NOT NULL,
                message_type TEXT DEFAULT 'text',
                file_path    TEXT DEFAULT NULL,
                unlock_time  TEXT NOT NULL,
                delivered    INTEGER DEFAULT 0,
                recurring    TEXT DEFAULT 'none',
                created_at   TEXT NOT NULL,
                FOREIGN KEY (sender_id)   REFERENCES users(user_id),
                FOREIGN KEY (receiver_id) REFERENCES users(user_id)
            )
        ''')

        self.conn.commit()

    # ==================== REPLY FUNCTIONS ====================

    def get_message_by_id(self, msg_id):
        """
        Reply feature kosam: oka specific message ni msg_id tho fetch chestundi.
        Returns: (msg_id, sender_id, message_text, username) or None
        """
        try:
            self.cursor.execute("""
                SELECT m.msg_id, m.sender_id, m.message_text, u.username
                FROM messages m
                JOIN users u ON m.sender_id = u.user_id
                WHERE m.msg_id = ?
            """, (msg_id,))
            return self.cursor.fetchone()
        except Exception as e:
            print(f"get_message_by_id error: {e}")
            return None

    # ==================== EDIT FUNCTIONS ====================

    def edit_message(self, msg_id, new_text, sender_id):
        """
        Edit feature: existing message text update chestundi.
        New message create cheyyadu — only UPDATE.
        sender_id check: only own messages edit cheyyachu.
        Returns True on success, False on failure.
        """
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.cursor.execute("""
                UPDATE messages
                SET message_text = ?, is_edited = 1, edited_at = ?
                WHERE msg_id = ? AND sender_id = ?
            """, (new_text, now, msg_id, sender_id))
            self.conn.commit()
            return self.cursor.rowcount > 0
        except Exception as e:
            print(f"edit_message error: {e}")
            return False

    # ==================== NOTIFICATION FUNCTIONS ====================

    def get_unread_count(self, sender_id, recipient_id):
        try:
            self.cursor.execute("""
                SELECT COUNT(*) FROM messages
                WHERE sender_id = ?
                  AND recipient_id = ?
                  AND status = 'sent'
                  AND (is_deleted = 0 OR is_deleted IS NULL)
            """, (sender_id, recipient_id))
            result = self.cursor.fetchone()
            return result[0] if result else 0
        except Exception as e:
            print(f"get_unread_count error: {e}")
            return 0

    def get_all_unread_counts(self, current_user_id):
        try:
            self.cursor.execute("""
                SELECT sender_id, COUNT(*) as unread
                FROM messages
                WHERE recipient_id = ?
                  AND status = 'sent'
                  AND (is_deleted = 0 OR is_deleted IS NULL)
                GROUP BY sender_id
            """, (current_user_id,))
            rows = self.cursor.fetchall()
            return {row[0]: row[1] for row in rows}
        except Exception as e:
            print(f"get_all_unread_counts error: {e}")
            return {}

    # ==================== STATUS FUNCTIONS ====================

    def post_status(self, user_id, content, status_type='text', file_path=None, bg_color='#128C7E', font_size=20):
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            from datetime import timedelta
            expires = (datetime.now() + timedelta(hours=24)).strftime("%Y-%m-%d %H:%M:%S")
            
            self.cursor.execute("""
                INSERT INTO statuses (user_id, status_type, content, file_path, bg_color, font_size, created_at, expires_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (user_id, status_type, content, file_path, bg_color, font_size, now, expires))
            self.conn.commit()
            return self.cursor.lastrowid
        except Exception as e:
            print(f"Post status error: {e}")
            return None

    def get_my_statuses(self, user_id):
        """
        My statuses — view_count uses status_view_logs (repeat views included).
        """
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.cursor.execute("""
                SELECT s.status_id, s.user_id, s.status_type, s.content, s.file_path,
                       s.bg_color, s.font_size, s.created_at, s.expires_at,
                       (SELECT COUNT(*) FROM status_view_logs svl
                        WHERE svl.status_id = s.status_id) as view_count
                FROM statuses s
                WHERE s.user_id = ? AND s.is_deleted = 0 AND s.expires_at > ?
                ORDER BY s.created_at DESC
            """, (user_id, now))
            return self.cursor.fetchall()
        except Exception as e:
            print(f"Get my statuses error: {e}")
            return []

    def get_contacts_statuses(self, current_user_id):
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.cursor.execute("""
                SELECT s.status_id, s.user_id, u.username, u.profile_pic,
                       s.status_type, s.content, s.file_path,
                       s.bg_color, s.font_size, s.created_at,
                       CASE WHEN sv.view_id IS NOT NULL THEN 1 ELSE 0 END as is_viewed
                FROM statuses s
                JOIN users u ON s.user_id = u.user_id
                LEFT JOIN status_views sv ON s.status_id = sv.status_id AND sv.viewer_id = ?
                WHERE s.user_id != ? AND s.is_deleted = 0 AND s.expires_at > ?
                ORDER BY is_viewed ASC, s.created_at DESC
            """, (current_user_id, current_user_id, now))
            return self.cursor.fetchall()
        except Exception as e:
            print(f"Get contacts statuses error: {e}")
            return []

    def get_users_with_statuses(self, current_user_id):
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.cursor.execute("""
                SELECT u.user_id, u.username, u.profile_pic,
                       COUNT(s.status_id) as status_count,
                       MAX(s.created_at) as latest_status,
                       SUM(CASE WHEN sv.view_id IS NULL THEN 1 ELSE 0 END) as unviewed_count
                FROM users u
                JOIN statuses s ON u.user_id = s.user_id
                LEFT JOIN status_views sv ON s.status_id = sv.status_id AND sv.viewer_id = ?
                WHERE u.user_id != ? AND s.is_deleted = 0 AND s.expires_at > ?
                GROUP BY u.user_id
                ORDER BY unviewed_count DESC, latest_status DESC
            """, (current_user_id, current_user_id, now))
            return self.cursor.fetchall()
        except Exception as e:
            print(f"Get users with statuses error: {e}")
            return []

    def mark_status_viewed(self, status_id, viewer_id):
        """
        Status view record chestundi:
        1. status_views  — UNIQUE per user (seen badge kosam)
        2. status_view_logs — every view including repeats (detailed tracking kosam)
        """
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            # Unique view — badge/unread count kosam
            self.cursor.execute("""
                INSERT OR IGNORE INTO status_views (status_id, viewer_id, viewed_at)
                VALUES (?, ?, ?)
            """, (status_id, viewer_id, now))
            # Every view log — repeat views kuda store cheyyadam
            self.cursor.execute("""
                INSERT INTO status_view_logs (status_id, viewer_id, viewed_at)
                VALUES (?, ?, ?)
            """, (status_id, viewer_id, now))
            self.conn.commit()
            return True
        except Exception as e:
            print(f"Mark status viewed error: {e}")
            return False

    def get_status_viewers(self, status_id):
        """Unique viewers list — latest view time per user."""
        try:
            self.cursor.execute("""
                SELECT u.username, sv.viewed_at
                FROM status_views sv
                JOIN users u ON sv.viewer_id = u.user_id
                WHERE sv.status_id = ?
                ORDER BY sv.viewed_at DESC
            """, (status_id,))
            return self.cursor.fetchall()
        except Exception as e:
            print(f"Get status viewers error: {e}")
            return []

    def get_status_view_details(self, status_id):
        """
        Detailed view tracking — repeat views included.
        Returns list of (username, view_count, [timestamps])
        StatusViewDetailsPopup kosam use avutundi.
        """
        try:
            self.cursor.execute("""
                SELECT u.username, svl.viewed_at
                FROM status_view_logs svl
                JOIN users u ON svl.viewer_id = u.user_id
                WHERE svl.status_id = ?
                ORDER BY u.username ASC, svl.viewed_at ASC
            """, (status_id,))
            rows = self.cursor.fetchall()

            # Group by username
            details = {}
            for username, viewed_at in rows:
                if username not in details:
                    details[username] = {'count': 0, 'times': []}
                details[username]['count'] += 1
                details[username]['times'].append(viewed_at)

            # Return as sorted list: (username, count, times_list)
            return [(uname, data['count'], data['times'])
                    for uname, data in sorted(details.items())]
        except Exception as e:
            print(f"Get status view details error: {e}")
            return []

    def get_status_total_views(self, status_id):
        """Total view count including repeat views."""
        try:
            self.cursor.execute(
                "SELECT COUNT(*) FROM status_view_logs WHERE status_id = ?",
                (status_id,)
            )
            return self.cursor.fetchone()[0]
        except:
            return 0

    def delete_status(self, status_id, user_id):
        try:
            self.cursor.execute("""
                UPDATE statuses SET is_deleted = 1
                WHERE status_id = ? AND user_id = ?
            """, (status_id, user_id))
            self.conn.commit()
            return self.cursor.rowcount > 0
        except Exception as e:
            print(f"Delete status error: {e}")
            return False

    def get_status_count(self, user_id):
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.cursor.execute("""
                SELECT COUNT(*) FROM statuses
                WHERE user_id = ? AND is_deleted = 0 AND expires_at > ?
            """, (user_id, now))
            return self.cursor.fetchone()[0]
        except:
            return 0

    def cleanup_expired_statuses(self):
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.cursor.execute("""
                UPDATE statuses SET is_deleted = 1
                WHERE expires_at <= ? AND is_deleted = 0
            """, (now,))
            self.conn.commit()
        except Exception as e:
            print(f"Cleanup error: {e}")

    # ==================== GROUP CHAT FUNCTIONS ====================

    def create_group(self, group_name, created_by, member_ids):
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.cursor.execute(
                "INSERT INTO groups (group_name, created_by, created_at) VALUES (?, ?, ?)",
                (group_name, created_by, now)
            )
            group_id = self.cursor.lastrowid

            self.cursor.execute(
                "INSERT INTO group_members (group_id, user_id, is_admin, joined_at) VALUES (?, ?, 1, ?)",
                (group_id, created_by, now)
            )

            for uid in member_ids:
                if uid != created_by:
                    self.cursor.execute(
                        "INSERT OR IGNORE INTO group_members (group_id, user_id, is_admin, joined_at) VALUES (?, ?, 0, ?)",
                        (group_id, uid, now)
                    )

            self.conn.commit()
            return group_id
        except Exception as e:
            print(f"Create group error: {e}")
            return None

    def get_user_groups(self, user_id):
        try:
            self.cursor.execute("""
                SELECT g.group_id, g.group_name, g.created_by, g.created_at,
                       (SELECT COUNT(*) FROM group_members WHERE group_id = g.group_id) as member_count
                FROM groups g
                JOIN group_members gm ON g.group_id = gm.group_id
                WHERE gm.user_id = ?
                ORDER BY g.created_at DESC
            """, (user_id,))
            return self.cursor.fetchall()
        except Exception as e:
            print(f"Get groups error: {e}")
            return []

    def get_group_members(self, group_id):
        try:
            self.cursor.execute("""
                SELECT u.user_id, u.username, u.profile_pic, u.is_online, gm.is_admin
                FROM users u
                JOIN group_members gm ON u.user_id = gm.user_id
                WHERE gm.group_id = ?
            """, (group_id,))
            return self.cursor.fetchall()
        except Exception as e:
            print(f"Get members error: {e}")
            return []

    def send_group_message(self, group_id, sender_id, text, msg_type='text', file_path=None):
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.cursor.execute("""
                INSERT INTO group_messages (group_id, sender_id, message_text, message_type, file_path, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (group_id, sender_id, text, msg_type, file_path, now))
            self.conn.commit()
            return True
        except Exception as e:
            print(f"Send group message error: {e}")
            return False

    def get_group_messages(self, group_id):
        try:
            self.cursor.execute("""
                SELECT gm.sender_id, u.username, gm.message_text, gm.timestamp,
                       gm.msg_id, gm.message_type, gm.file_path, gm.is_starred
                FROM group_messages gm
                JOIN users u ON gm.sender_id = u.user_id
                WHERE gm.group_id = ? AND (gm.is_deleted = 0 OR gm.is_deleted IS NULL)
                ORDER BY gm.timestamp ASC
            """, (group_id,))
            return self.cursor.fetchall()
        except Exception as e:
            print(f"Get group messages error: {e}")
            return []

    def delete_group_message(self, msg_id):
        try:
            self.cursor.execute("UPDATE group_messages SET is_deleted = 1 WHERE msg_id = ?", (msg_id,))
            self.conn.commit()
            return True
        except Exception as e:
            print(f"Delete group message error: {e}")
            return False

    def add_group_member(self, group_id, user_id):
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.cursor.execute(
                "INSERT OR IGNORE INTO group_members (group_id, user_id, is_admin, joined_at) VALUES (?, ?, 0, ?)",
                (group_id, user_id, now)
            )
            self.conn.commit()
            return True
        except Exception as e:
            print(f"Add member error: {e}")
            return False

    def remove_group_member(self, group_id, user_id):
        try:
            self.cursor.execute(
                "DELETE FROM group_members WHERE group_id = ? AND user_id = ?",
                (group_id, user_id)
            )
            self.conn.commit()
            return True
        except Exception as e:
            print(f"Remove member error: {e}")
            return False

    def is_group_admin(self, group_id, user_id):
        self.cursor.execute(
            "SELECT is_admin FROM group_members WHERE group_id = ? AND user_id = ?",
            (group_id, user_id)
        )
        res = self.cursor.fetchone()
        return res and res[0] == 1

    def get_group_info(self, group_id):
        try:
            self.cursor.execute("SELECT group_id, group_name, created_by, created_at FROM groups WHERE group_id = ?", (group_id,))
            return self.cursor.fetchone()
        except:
            return None

    def search_group_messages(self, group_id, keyword):
        try:
            self.cursor.execute("""
                SELECT gm.sender_id, u.username, gm.message_text, gm.timestamp,
                       gm.msg_id, gm.message_type, gm.file_path, gm.is_starred
                FROM group_messages gm
                JOIN users u ON gm.sender_id = u.user_id
                WHERE gm.group_id = ? AND (gm.is_deleted = 0 OR gm.is_deleted IS NULL)
                AND gm.message_text LIKE ?
                ORDER BY gm.timestamp ASC
            """, (group_id, f"%{keyword}%"))
            return self.cursor.fetchall()
        except Exception as e:
            print(f"Search group messages error: {e}")
            return []

    # ==================== EXISTING FUNCTIONS ====================

    def search_messages(self, user_id, recipient_id, keyword):
        """
        Returns 10 columns:
        sender_id, message_text, timestamp, msg_id, status,
        message_type, file_path, is_starred, reply_to, is_edited
        Falls back to 8-col query if new columns don't exist yet.
        """
        try:
            query = """
                SELECT sender_id, message_text, timestamp, msg_id, status, message_type,
                       file_path, is_starred,
                       COALESCE(reply_to, NULL)   AS reply_to,
                       COALESCE(is_edited, 0)     AS is_edited
                FROM messages
                WHERE (
                    (sender_id = ? AND recipient_id = ?) OR
                    (sender_id = ? AND recipient_id = ?)
                )
                AND (is_deleted = 0 OR is_deleted IS NULL)
                AND message_text LIKE ?
                ORDER BY timestamp ASC
            """
            self.cursor.execute(query, (user_id, recipient_id, recipient_id, user_id, f"%{keyword}%"))
            return self.cursor.fetchall()
        except Exception:
            # Fallback: old DB without reply_to/is_edited — pad with None/0
            try:
                self.cursor.execute("""
                    SELECT sender_id, message_text, timestamp, msg_id, status, message_type,
                           file_path, is_starred
                    FROM messages
                    WHERE (
                        (sender_id = ? AND recipient_id = ?) OR
                        (sender_id = ? AND recipient_id = ?)
                    )
                    AND (is_deleted = 0 OR is_deleted IS NULL)
                    AND message_text LIKE ?
                    ORDER BY timestamp ASC
                """, (user_id, recipient_id, recipient_id, user_id, f"%{keyword}%"))
                rows = self.cursor.fetchall()
                return [row + (None, 0) for row in rows]
            except Exception as e:
                print(f"Search Error: {e}")
                return []

    def toggle_star_message(self, msg_id):
        try:
            self.cursor.execute("UPDATE messages SET is_starred = 1 - is_starred WHERE msg_id = ?", (msg_id,))
            self.conn.commit()
            return True
        except Exception as e:
            print(f"Error toggling star: {e}")
            return False

    def get_starred_messages(self, user_id):
        try:
            self.cursor.execute("""
                SELECT m.msg_id, m.message_text, m.timestamp, u.username, m.message_type, m.file_path
                FROM messages m
                JOIN users u ON m.sender_id = u.user_id
                WHERE (m.sender_id = ? OR m.recipient_id = ?) 
                AND m.is_starred = 1 
                AND (m.is_deleted = 0 OR m.is_deleted IS NULL)
                ORDER BY m.timestamp DESC
            """, (user_id, user_id))
            return self.cursor.fetchall()
        except Exception as e:
            print(f"Error fetching starred messages: {e}")
            return []

    def update_user_online_status(self, user_id, status):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.cursor.execute("UPDATE users SET is_online = ?, last_seen = ? WHERE user_id = ?", (status, now, user_id))
        self.conn.commit()

    def get_user_status(self, user_id):
        self.cursor.execute("SELECT is_online, last_seen, is_typing FROM users WHERE user_id = ?", (user_id,))
        res = self.cursor.fetchone()
        return res if res else (0, "Never", 0)

    def save_message(self, s_id, r_id, text, msg_type='text', file_path=None, reply_to=None):
        """
        Message save chestundi.
        reply_to: original message id (Reply feature kosam, optional)
        """
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if self.is_blocked(s_id, r_id):
            return "blocked_by_me"
        if self.is_blocked(r_id, s_id):
            status = 'blocked'
            self.cursor.execute(
                "INSERT INTO blocked_messages (sender_id, recipient_id, message_text, timestamp) VALUES (?, ?, ?, ?)",
                (s_id, r_id, text, now)
            )
        else:
            status = 'sent'
        # reply_to column include chesindi
        self.cursor.execute("""
            INSERT INTO messages (sender_id, recipient_id, message_text, message_type, file_path, timestamp, status, is_deleted, is_starred, reply_to) 
            VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0, ?)
        """, (s_id, r_id, text, msg_type, file_path, now, status, reply_to))
        self.conn.commit()
        return True

    def get_chat_history(self, u1, u2):
        """
        Returns 10 columns:
        sender_id, message_text, timestamp, msg_id, status,
        message_type, file_path, is_starred, reply_to, is_edited
        Falls back to 8-col query if new columns don't exist yet.
        """
        try:
            self.cursor.execute("""
                SELECT sender_id, message_text, timestamp, msg_id, status, message_type,
                       file_path, is_starred,
                       COALESCE(reply_to, NULL)   AS reply_to,
                       COALESCE(is_edited, 0)     AS is_edited
                FROM messages
                WHERE ((sender_id=? AND recipient_id=?) OR (sender_id=? AND recipient_id=?))
                AND (is_deleted = 0 OR is_deleted IS NULL)
                AND NOT (recipient_id = ? AND status = 'blocked')
                ORDER BY timestamp ASC
            """, (u1, u2, u2, u1, u1))
            return self.cursor.fetchall()
        except Exception:
            # Fallback: old DB without reply_to/is_edited — pad with None/0
            try:
                self.cursor.execute("""
                    SELECT sender_id, message_text, timestamp, msg_id, status, message_type,
                           file_path, is_starred
                    FROM messages
                    WHERE ((sender_id=? AND recipient_id=?) OR (sender_id=? AND recipient_id=?))
                    AND (is_deleted = 0 OR is_deleted IS NULL)
                    AND NOT (recipient_id = ? AND status = 'blocked')
                    ORDER BY timestamp ASC
                """, (u1, u2, u2, u1, u1))
                rows = self.cursor.fetchall()
                # Pad each row with reply_to=None, is_edited=0
                return [row + (None, 0) for row in rows]
            except:
                return []

    def block_user(self, blocker_id, blocked_id):
        try:
            self.cursor.execute("INSERT OR IGNORE INTO blocked_users (blocker_id, blocked_id) VALUES (?, ?)", (blocker_id, blocked_id))
            self.conn.commit()
            return True
        except: return False

    def unblock_user(self, blocker_id, blocked_id):
        try:
            self.cursor.execute("DELETE FROM blocked_users WHERE blocker_id = ? AND blocked_id = ?", (blocker_id, blocked_id))
            self.cursor.execute("UPDATE messages SET status = 'sent' WHERE sender_id = ? AND recipient_id = ? AND status = 'blocked'", (blocked_id, blocker_id))
            self.conn.commit()
            return True
        except: return False

    def is_blocked(self, blocker_id, blocked_id):
        self.cursor.execute("SELECT 1 FROM blocked_users WHERE blocker_id = ? AND blocked_id = ?", (blocker_id, blocked_id))
        return self.cursor.fetchone() is not None

    def get_users_list(self, current_user_id):
        try:
            self.cursor.execute("SELECT user_id, username, profile_pic, is_online, last_seen FROM users WHERE user_id != ?", (current_user_id,))
            return self.cursor.fetchall()
        except: return []

    def login_user(self, username, password):
        self.cursor.execute("SELECT user_id FROM users WHERE username = ? AND password = ?", (username, password))
        result = self.cursor.fetchone()
        if result:
            self.update_user_online_status(result[0], 1)
            return result[0]
        return None

    def register_user(self, username, password):
        try:
            self.cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            self.conn.commit()
            return True
        except: return False

    def logout_user(self, user_id):
        self.update_user_online_status(user_id, 0)
        self.cursor.execute("UPDATE users SET is_typing = 0 WHERE user_id = ?", (user_id,))
        self.conn.commit()

    def update_last_seen(self, user_id):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.cursor.execute("UPDATE users SET last_seen = ?, is_online = 1 WHERE user_id = ?", (now, user_id))
        self.conn.commit()

    def update_typing_status(self, user_id, status):
        self.cursor.execute("UPDATE users SET is_typing = ? WHERE user_id = ?", (status, user_id))
        self.conn.commit()

    def get_user_dp(self, user_id):
        self.cursor.execute("SELECT profile_pic FROM users WHERE user_id = ?", (user_id,))
        res = self.cursor.fetchone()
        return res[0] if res else ""

    def update_user_dp(self, user_id, path):
        try:
            self.cursor.execute("UPDATE users SET profile_pic = ? WHERE user_id = ?", (path, user_id))
            self.conn.commit()
            return True
        except: return False

    def mark_messages_as_seen(self, sender_id, recipient_id):
        try:
            self.cursor.execute("UPDATE messages SET status = 'seen' WHERE sender_id = ? AND recipient_id = ? AND status = 'sent'", (sender_id, recipient_id))
            self.conn.commit()
            return True
        except: return False

    def delete_single_message(self, msg_id):
        try:
            self.cursor.execute("UPDATE messages SET is_deleted = 1 WHERE msg_id = ?", (msg_id,))
            self.conn.commit()
            return True
        except: return False

    def clear_full_chat(self, u1, u2):
        try:
            self.cursor.execute("UPDATE messages SET is_deleted = 1 WHERE (sender_id=? AND recipient_id=?) OR (sender_id=? AND recipient_id=?)", (u1, u2, u2, u1))
            self.conn.commit()
            return True
        except: return False

    def get_analytics_messages(self, user_id):
        """
        Analytics kosam: user send/receive chesina anni messages fetch chestundi.
        Returns list of (sender_id, recipient_id, message_text, timestamp, status)
        """
        try:
            self.cursor.execute("""
                SELECT sender_id, recipient_id, message_text, timestamp, status
                FROM messages
                WHERE (sender_id = ? OR recipient_id = ?)
                  AND (is_deleted = 0 OR is_deleted IS NULL)
                  AND message_type = 'text'
                  AND message_text IS NOT NULL
                  AND message_text != ''
                  AND message_text != '[Image]'
                ORDER BY timestamp ASC
            """, (user_id, user_id))
            return self.cursor.fetchall()
        except Exception as e:
            print(f"get_analytics_messages error: {e}")
            return []

    def get_analytics_contacts(self, user_id):
        """
        Analytics kosam: user chat chesina contacts list with message counts.
        Returns list of (contact_id, username, sent_count, received_count)
        """
        try:
            self.cursor.execute("""
                SELECT
                    u.user_id,
                    u.username,
                    SUM(CASE WHEN m.sender_id = ? THEN 1 ELSE 0 END) as sent,
                    SUM(CASE WHEN m.recipient_id = ? THEN 1 ELSE 0 END) as received
                FROM messages m
                JOIN users u ON (
                    CASE WHEN m.sender_id = ? THEN m.recipient_id ELSE m.sender_id END
                    = u.user_id
                )
                WHERE (m.sender_id = ? OR m.recipient_id = ?)
                  AND (m.is_deleted = 0 OR m.is_deleted IS NULL)
                GROUP BY u.user_id
                ORDER BY (sent + received) DESC
                LIMIT 10
            """, (user_id, user_id, user_id, user_id, user_id))
            return self.cursor.fetchall()
        except Exception as e:
            print(f"get_analytics_contacts error: {e}")
            return []

    # ==================== SCHEDULED MESSAGES — SECRET DELIVERY ====================

    def schedule_message(self, sender_id, receiver_id, message_text,
                         unlock_time, message_type='text', file_path=None,
                         recurring='none'):
        """
        Secret Delivery: message schedule chestundi.
        Receiver ki message existence theliyadu until unlock_time.
        unlock_time: 'YYYY-MM-DD HH:MM:SS' format
        """
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.cursor.execute("""
                INSERT INTO scheduled_messages
                    (sender_id, receiver_id, message_text, message_type,
                     file_path, unlock_time, delivered, recurring, created_at)
                VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?)
            """, (sender_id, receiver_id, message_text, message_type,
                  file_path, unlock_time, recurring, now))
            self.conn.commit()
            return self.cursor.lastrowid
        except Exception as e:
            print(f"schedule_message error: {e}")
            return None

    def deliver_due_messages(self, receiver_id=None):
        """
        Background scheduler call chestundi — every 1 second.
        Due messages (unlock_time <= now, delivered=0) ni:
        1. messages table lo insert chestundi (normal chat lo appear avutundi)
        2. delivered=1 ga mark chestundi
        Returns: list of (receiver_id, sender_name, message_text) for notification
        """
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            # Find all due undelivered messages
            if receiver_id:
                self.cursor.execute("""
                    SELECT id, sender_id, receiver_id, message_text, message_type, file_path, recurring
                    FROM scheduled_messages
                    WHERE receiver_id = ? AND delivered = 0 AND unlock_time <= ?
                """, (receiver_id, now))
            else:
                self.cursor.execute("""
                    SELECT id, sender_id, receiver_id, message_text, message_type, file_path, recurring
                    FROM scheduled_messages
                    WHERE delivered = 0 AND unlock_time <= ?
                """, (now,))

            due = self.cursor.fetchall()
            delivered_list = []

            for (sid, sender_id, recv_id, msg_text, msg_type, file_path, recurring) in due:
                try:
                    # Insert directly into messages table — normal chat lo appear avutundi
                    # No prefix, no label — plain message text only
                    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    self.cursor.execute("""
                        INSERT INTO messages
                            (sender_id, recipient_id, message_text, message_type,
                             file_path, timestamp, status, is_deleted, is_starred)
                        VALUES (?, ?, ?, ?, ?, ?, 'sent', 0, 0)
                    """, (sender_id, recv_id, msg_text,
                          msg_type if msg_type else 'text', file_path, ts))

                    # Mark as delivered
                    self.cursor.execute(
                        "UPDATE scheduled_messages SET delivered = 1 WHERE id = ?", (sid,))

                    # Handle recurring — schedule next occurrence
                    if recurring and recurring != 'none':
                        self.cursor.execute(
                            "SELECT unlock_time FROM scheduled_messages WHERE id = ?", (sid,))
                        row = self.cursor.fetchone()
                        if row:
                            old_time = datetime.strptime(row[0], "%Y-%m-%d %H:%M:%S")
                            if recurring == 'monthly':
                                month = old_time.month % 12 + 1
                                year  = old_time.year + (1 if old_time.month == 12 else 0)
                                next_time = old_time.replace(year=year, month=month)
                            elif recurring == 'yearly':
                                next_time = old_time.replace(year=old_time.year + 1)
                            else:
                                next_time = None
                            if next_time:
                                self.schedule_message(
                                    sender_id=sender_id,
                                    receiver_id=recv_id,
                                    message_text=msg_text,
                                    unlock_time=next_time.strftime("%Y-%m-%d %H:%M:%S"),
                                    message_type=msg_type,
                                    file_path=file_path,
                                    recurring=recurring
                                )

                    # Get sender name for notification
                    self.cursor.execute("SELECT username FROM users WHERE user_id = ?", (sender_id,))
                    srow = self.cursor.fetchone()
                    sender_name = srow[0] if srow else "Someone"
                    delivered_list.append((recv_id, sender_name, capsule_text))

                except Exception as e:
                    print(f"deliver_due_messages item error: {e}")

            if due:
                self.conn.commit()

            return delivered_list
        except Exception as e:
            print(f"deliver_due_messages error: {e}")
            return []

    def get_scheduled_sent(self, sender_id):
        """Sender ki scheduled (undelivered) messages list."""
        try:
            self.cursor.execute("""
                SELECT sm.id, sm.receiver_id, u.username AS receiver_name,
                       sm.message_text, sm.message_type, sm.file_path,
                       sm.unlock_time, sm.delivered, sm.recurring, sm.created_at
                FROM scheduled_messages sm
                JOIN users u ON sm.receiver_id = u.user_id
                WHERE sm.sender_id = ?
                ORDER BY sm.unlock_time ASC
            """, (sender_id,))
            return self.cursor.fetchall()
        except Exception as e:
            print(f"get_scheduled_sent error: {e}")
            return []

    def delete_scheduled_message(self, msg_id, sender_id):
        """Scheduled message delete chestundi (sender only, undelivered only)."""
        try:
            self.cursor.execute(
                "DELETE FROM scheduled_messages WHERE id = ? AND sender_id = ? AND delivered = 0",
                (msg_id, sender_id)
            )
            self.conn.commit()
            return self.cursor.rowcount > 0
        except Exception as e:
            print(f"delete_scheduled_message error: {e}")
            return False

    def get_scheduled_unlocked_count(self, receiver_id):
        """Receiver ki deliver avvaboye messages count (for dashboard badge)."""
        try:
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.cursor.execute("""
                SELECT COUNT(*) FROM scheduled_messages
                WHERE receiver_id = ? AND delivered = 0 AND unlock_time <= ?
            """, (receiver_id, now))
            return self.cursor.fetchone()[0]
        except:
            return 0

    def __del__(self):
        try: self.conn.close()
        except: pass
