"""
NexaChat Settings screen (v11)
==============================
    SettingsPage   scrolling, theme-aware Canvas page made of glass cards:
                   Profile · Appearance (live theme previews) · Shortcuts · Account · About

UI only; actions go back to the application through the callback dict:
    back, upload_dp, remove_dp, theme(name), forget_user, logout
"""
import tkinter as tk

from fx import mix
from fxkit import FONT, Look, PALETTES, THEME_DESC, card_image, pill_image
from chat_fx import Base, font, fit, wheel_units

THEME_ORDER = ["Ocean Blue", "Midnight Aurora", "Sunset Coral", "Forest Mint", "Royal Violet", "Cyber Neon"]
SHORTCUTS = [("Ctrl + K", "Search your chats"), ("Esc", "Back to dashboard / close viewer"),
             ("Enter", "Send a message"), ("Double-click", "Reply to a message"),
             ("Right-click", "Copy, edit, star or delete"), ("← →", "Move between statuses")]


class SettingsPage(Base):
    PAD = 30

    def __init__(self, cv, look, cb, username="", dp=None, theme="Ocean Blue", remembered=""):
        super().__init__(cv, look)
        self.cb, self.username, self.dp = cb, username, dp
        self.theme, self.remembered = theme, remembered
        for ev in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            cv.bind(ev, lambda e: cv.yview_scroll(wheel_units(e), "units"), add="+")

    # ------------------------------------------------------------ pieces
    def _card(self, x, y, w, h, title=None, sub=None):
        L = self.look
        im, m = card_image(w, h, 22, L.card_top, L.card_bot, L.line, L.shadow)
        self.img(x - m, y - m, im, "nw")
        if title:
            self.t(x + 26, y + 26, title, size=13, weight="bold", anchor="w")
        if sub:
            self.t(x + 26, y + 48, sub, size=9, fill=L.muted, anchor="w")
        return y + 72

    def _button(self, x, y, w, h, label, cb, primary=True, danger=False):
        L, cv = self.look, self.cv
        if primary:
            im, m = pill_image(w, h, h // 2, L.p1, L.a2, glow=L.a1b, glow_a=110)
            self.img(x - m, y - m, im, "nw")
            self.t(x + w / 2.0, y + h / 2.0, label, size=10, weight="bold", fill="#FFFFFF", anchor="center")
            self.hit((x, y, x + w, y + h), cb)
            return
        col = L.red if danger else L.a1b
        r = h // 2
        base = mix(L.card_bot, col, 0.07)
        nor, m = card_image(w, h, r, base, base, mix(L.line, col, 0.55), (0, 0, 0, 0))
        hov, m2 = card_image(w, h, r, col, col, col, (0, 0, 0, 0))
        a_ = self.img(x - m, y - m, nor, "nw")
        b_ = self.img(x - m2, y - m2, hov, "nw", state="hidden")
        tx = self.t(x + w / 2.0, y + h / 2.0, label, size=10, weight="bold", fill=col, anchor="center")

        def on():
            cv.itemconfigure(a_, state="hidden")
            cv.itemconfigure(b_, state="normal")
            cv.itemconfigure(tx, fill="#FFFFFF")

        def off():
            cv.itemconfigure(a_, state="normal")
            cv.itemconfigure(b_, state="hidden")
            cv.itemconfigure(tx, fill=col)
        self.hit((x, y, x + w, y + h), cb, on, off)

    @staticmethod
    def _rr(x1, y1, x2, y2, r):
        return [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2, x1, y2,
                x1, y2 - r, x1, y1 + r, x1, y1]

    # ------------------------------------------------------------- cards
    def _profile(self, x, y, w):
        L = self.look
        h = 176
        self._card(x, y, w, h)
        self.avatar(x + 76, y + h / 2.0, 92, self.username or "?", self.dp, key="me", online=True, ring_bg=L.card_top)
        tx = x + 148
        self.t(tx, y + 44, fit(self.username or "", font(18, "bold"), w - 180), size=18, weight="bold", anchor="w")
        self.t(tx, y + 72, "●  Online  ·  NexaChat member", size=9, weight="bold", fill=L.green, anchor="w")
        self._button(tx, y + 98, 150, 38, "Change photo", self.cb["upload_dp"])
        if self.dp:
            self._button(tx + 162, y + 98, 100, 38, "Remove", self.cb["remove_dp"], primary=False)
        return h

    def _appearance(self, x, y, w):
        L = self.look
        tile_w = (w - 52 - 24) / 3.0
        prev_h, lab_h = 78, 40
        rows = 2
        h = 72 + rows * (prev_h + lab_h) + (rows - 1) * 14 + 22
        self._card(x, y, w, h, "Appearance", "Pick a theme. Every screen restyles instantly.")
        for i, name in enumerate(THEME_ORDER):
            r, c = divmod(i, 3)
            tx = x + 26 + c * (tile_w + 12)
            ty = y + 72 + r * (prev_h + lab_h + 14)
            self._tile(tx, ty, tile_w, prev_h, name)
        return h

    def _tile(self, x, y, w, h, name):
        L, cv = self.look, self.cv
        T = Look(PALETTES[name])
        sel = (name == self.theme)
        im, m = card_image(w, h, 14, T.page, T.page, T.a1b if sel else T.line, T.shadow if not sel else (0, 0, 0, 0),
                           glow=T.a1b if sel else None)
        self.img(x - m, y - m, im, "nw")
        # mini sidebar
        cv.create_rectangle(x + 8, y + 8, x + 28, y + h - 8, fill=T.sb_top, outline="")
        for j in range(3):
            cv.create_oval(x + 14, y + 16 + j * 14, x + 22, y + 24 + j * 14, fill=mix(T.sb_top, "#FFFFFF", 0.4 if j else 0.9),
                           outline="")
        # mini bubbles
        bx = x + 38
        rim, rm = pill_image(int(w * 0.42), 14, 7, T.card_top, T.card_bot, glow=None)
        self.img(bx - rm, y + 14 - rm, rim, "nw")
        sim, sm = pill_image(int(w * 0.42), 14, 7, T.p1, T.a2, glow=None)
        self.img(x + w - 10 - int(w * 0.42) - sm, y + 34 - sm, sim, "nw")
        cv.create_rectangle(bx, y + 54, x + w - 10, y + 62, fill=T.card_bot, outline=T.line)
        cv.create_rectangle(bx, y + 54, bx + (w - 48) * 0.45, y + 62, fill=T.a1b, outline="")
        # label
        self.t(x + 2, y + h + 14, name, size=9, weight="bold", anchor="w")
        self.t(x + 2, y + h + 30, THEME_DESC.get(name, ""), size=8, fill=L.muted, anchor="w")
        if sel:
            cv.create_oval(x + w - 24, y - 8, x + w + 2, y + 18, fill=T.a1b, outline=L.card_top, width=2)
            self.t(x + w - 11, y + 5, "✓", size=9, weight="bold", fill="#FFFFFF", anchor="center")
        self.hit((x, y, x + w, y + h + 36), lambda n=name: self.cb["theme"](n))

    def _shortcuts(self, x, y, w):
        L, cv = self.look, self.cv
        row = 42
        h = 72 + len(SHORTCUTS) * row + 14
        self._card(x, y, w, h, "Shortcuts", "Move faster with the keyboard and mouse.")
        for i, (k, d) in enumerate(SHORTCUTS):
            ry = y + 72 + i * row
            kw = font(9, "bold").measure(k) + 26
            cap, m = card_image(kw, 28, 9, L.card_top, mix(L.card_bot, L.a1, 0.08), mix(L.line, L.a1, 0.35), (0, 0, 0, 25))
            self.img(x + 26 - m, ry + 4 - m, cap, "nw")
            self.t(x + 26 + kw / 2.0, ry + 18, k, size=9, weight="bold", fill=L.a1b, anchor="center")
            self.t(x + 26 + 150, ry + 18, fit(d, font(10), w - 26 - 150 - 24), size=10, anchor="w")
        return h

    def _account(self, x, y, w):
        L = self.look
        h = 72 + 52 + 70 + 12
        self._card(x, y, w, h, "Account", "Session and sign-in preferences.")
        ry = y + 76
        self.t(x + 26, ry + 8, "Saved username", size=9, fill=L.muted, anchor="w")
        self.t(x + 26, ry + 28, self.remembered or "Nothing saved on this device", size=11, weight="bold",
               fill=L.text if self.remembered else L.muted, anchor="w")
        if self.remembered:
            self._button(x + w - 26 - 90, ry + 6, 90, 34, "Forget", self.cb["forget_user"], primary=False)
        self._button(x + 26, ry + 64 - 6 + 12, w - 52, 44, "Log out of NexaChat", self.cb["logout"], primary=False,
                     danger=True)
        return h

    def _about(self, x, y, w):
        L = self.look
        h = 124
        self._card(x, y, w, h, "About NexaChat", None)
        self.t(x + 26, y + 56, "Version 11  ·  Connect  •  Chat  •  Grow", size=10, weight="bold", fill=L.a1b, anchor="w")
        self.t(x + 26, y + 80, "Private chats, groups, status updates and smart analytics,", size=9, fill=L.muted, anchor="w")
        self.t(x + 26, y + 98, "all stored locally on this device.", size=9, fill=L.muted, anchor="w")
        return h

    # -------------------------------------------------------------- build
    def build(self, W, H):
        L, cv = self.look, self.cv
        pad = self.PAD
        two = W >= 900
        colw = (W - 3 * pad) / 2.0 if two else W - 2 * pad
        # compute a first pass height so the scroll region is right
        self.scroll_h = H
        cv.create_rectangle(0, 0, W, 4000, fill=L.page, outline="")
        top = 92
        # top bar
        cv.create_rectangle(0, 0, W, 78, fill=mix(L.page, L.surface, 0.85 if not L.dark else 0.6), outline="")
        cv.create_line(0, 78, W, 78, fill=L.line)
        self.icon_btn(pad + 18, 39, 38, "←", self.cb["back"], tint=L.text)
        self.t(pad + 52, 33, "Settings", size=19, weight="bold", anchor="w")
        self.t(pad + 52, 57, "Personalize NexaChat your way", size=9, fill=L.muted, anchor="w")

        if two:
            lx, rx = pad, pad * 2 + colw
            ly = ry = top
            ly += self._profile(lx, ly, colw) + 18
            ly += self._account(lx, ly, colw) + 18
            ly += self._about(lx, ly, colw) + 18
            ry += self._appearance(rx, ry, colw) + 18
            ry += self._shortcuts(rx, ry, colw) + 18
            bottom = max(ly, ry)
        else:
            y = top
            for fn in (self._profile, self._appearance, self._shortcuts, self._account, self._about):
                y += fn(pad, y, colw) + 18
            bottom = y
        self.scroll_h = max(H, bottom + 12)
        cv.configure(scrollregion=(0, 0, W, self.scroll_h))
