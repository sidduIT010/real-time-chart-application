"""
NexaChat FX engine
==================
A small, dependency-free (Tkinter + Pillow only) animation and graphics toolkit.

* One shared 60 fps ticker per window (adaptive: drops to 30 fps if a machine is slow,
  pauses completely while the window is minimised).
* Easing functions + a tiny tween helper.
* Scene: attaches to a Canvas and gives you spring-eased item *groups* (slide-in,
  hover-lift, bobbing), count-up numbers, typewriter text, animated line charts,
  spinning comet rings and pulse rings.
* Orbs (soft drifting aurora glows) and ParticleNet (a floating constellation that
  can react to the mouse).
* AuthHero: the animated brand panel used on the login screen.

Everything is pure drawing code: no new files, no network, no extra packages.
"""
import math
import random
import time
import traceback
import tkinter as tk
import tkinter.font as tkfont
from PIL import Image, ImageDraw, ImageFilter, ImageTk

# ------------------------------------------------------------------ clock ---
_clock = time.perf_counter


def clock():
    return _clock()


# ----------------------------------------------------------------- colour ---
def hex_rgb(c):
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def clamp01(t):
    return 0.0 if t < 0 else 1.0 if t > 1 else t


def mix(a, b, t):
    """Blend hex colour a -> b by t (0..1)."""
    try:
        t = clamp01(t)
        ar, ag, ab = hex_rgb(a)
        br, bg, bb = hex_rgb(b)
        return "#%02x%02x%02x" % (int(ar + (br - ar) * t), int(ag + (bg - ag) * t), int(ab + (bb - ab) * t))
    except Exception:
        return a


# ----------------------------------------------------------------- easing ---
def ease_out_cubic(t):
    t = clamp01(t)
    return 1 - (1 - t) ** 3


def ease_in_out(t):
    t = clamp01(t)
    return t * t * (3 - 2 * t)


def ease_out_back(t, s=1.70158):
    t = clamp01(t) - 1
    return 1 + (s + 1) * t ** 3 + s * t ** 2


def ease_out_expo(t):
    t = clamp01(t)
    return 1.0 if t >= 1 else 1 - 2 ** (-10 * t)


# ------------------------------------------------------------ image cache ---
_IMG = {}
_IMG_ROOT = [None]


def cached(key, builder):
    """PhotoImage cache that resets itself if the Tk interpreter changes."""
    cur = tk._default_root
    if _IMG_ROOT[0] is not cur:
        _IMG.clear()
        _IMG_ROOT[0] = cur
    v = _IMG.get(key)
    if v is None:
        if len(_IMG) > 260:
            _IMG.clear()
        v = builder()
        _IMG[key] = v
    return v


def rr_points(x1, y1, x2, y2, r):
    r = max(0, min(r, (x2 - x1) / 2, (y2 - y1) / 2))
    return [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
            x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]


def orb_image(d, color, alpha):
    """Soft radial glow (RGBA) used for aurora lighting."""
    d = int(d)

    def build():
        g = Image.radial_gradient("L").resize((d, d), Image.BILINEAR)
        mask = g.point(lambda v: int(alpha * (max(0.0, 1 - v / 255.0) ** 2.2)))
        img = Image.new("RGBA", (d, d), hex_rgb(color) + (0,))
        img.putalpha(mask)
        return ImageTk.PhotoImage(img)

    return cached(("orb", d, color, int(alpha)), build)


def glass_image(w, h, radius, fill=(255, 255, 255, 20), border=(255, 255, 255, 48), shine=True):
    """Translucent rounded 'glass' panel with a hairline border and soft top sheen."""
    w, h = int(w), int(h)

    def build():
        S = 2
        W, H = w * S, h * S
        img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        d.rounded_rectangle([0, 0, W - 1, H - 1], radius * S, fill=fill)
        if shine:
            fade = Image.linear_gradient("L").transpose(Image.FLIP_TOP_BOTTOM).resize((W, H))
            fade = fade.point(lambda v: int(v * 22 / 255.0 * (1 if v > 90 else v / 90.0)))
            clip = Image.new("L", (W, H), 0)
            ImageDraw.Draw(clip).rounded_rectangle([0, 0, W - 1, H - 1], radius * S, fill=255)
            sheen = Image.new("RGBA", (W, H), (255, 255, 255, 0))
            sheen.putalpha(Image.composite(fade, Image.new("L", (W, H), 0), clip))
            img.alpha_composite(sheen)
        d.rounded_rectangle([0, 0, W - 1, H - 1], radius * S, outline=border, width=S)
        return ImageTk.PhotoImage(img.resize((w, h), Image.LANCZOS))

    return cached(("glass", w, h, radius, fill, border, shine), build)


def catmull(points, steps=8):
    """Smooth a list of (x, y) points with a Catmull-Rom spline."""
    if len(points) < 3:
        return list(points)
    p = [points[0]] + list(points) + [points[-1]]
    out = []
    for i in range(1, len(p) - 2):
        p0, p1, p2, p3 = p[i - 1], p[i], p[i + 1], p[i + 2]
        for s in range(steps):
            t = s / float(steps)
            t2, t3 = t * t, t * t * t
            out.append(tuple(
                0.5 * ((2 * p1[k]) + (-p0[k] + p2[k]) * t + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * t2
                       + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * t3) for k in (0, 1)))
    out.append(points[-1])
    return out


# ----------------------------------------------------------------- ticker ---
class _Handle:
    __slots__ = ("fn", "owner", "every", "acc", "dead")

    def __init__(self, fn, owner, every):
        self.fn, self.owner, self.every, self.acc, self.dead = fn, owner, max(1, every), 0.0, False


class Ticker:
    """Shared animation clock. Callbacks are fn(dt, now) and return False to stop."""

    def __init__(self, root):
        self.root = root
        self.items = []
        self.running = False
        self.last = 0.0
        self.frame = 0
        self.interval = 16
        self.ema = 0.0
        self._warned = False

    def add(self, fn, owner=None, every=1):
        h = _Handle(fn, owner, every)
        self.items.append(h)
        self._ensure()
        return h

    def remove(self, h):
        if h is not None:
            h.dead = True

    def _ensure(self):
        if not self.running:
            self.running = True
            self.last = clock()
            try:
                self.root.after(self.interval, self._tick)
            except tk.TclError:
                self.running = False

    def _tick(self):
        t0 = clock()
        dt = min(0.1, max(0.0, t0 - self.last))
        self.last = t0
        self.frame += 1
        try:
            iconic = self.root.state() == "iconic"
        except Exception:
            iconic = False
        if not iconic:
            for h in list(self.items):
                if h.dead:
                    continue
                if h.owner is not None:
                    try:
                        alive = bool(h.owner.winfo_exists())
                    except Exception:
                        alive = False
                    if not alive:
                        h.dead = True
                        continue
                h.acc += dt
                if self.frame % h.every:
                    continue
                d, h.acc = h.acc, 0.0
                try:
                    r = h.fn(d, t0)
                except tk.TclError:
                    h.dead = True
                except Exception:
                    h.dead = True
                    if not self._warned:
                        self._warned = True
                        traceback.print_exc()
                else:
                    if r is False:
                        h.dead = True
        self.items = [h for h in self.items if not h.dead]
        work = clock() - t0
        self.ema = self.ema * 0.9 + work * 0.1
        if self.ema > 0.015:
            self.interval = 33
        elif self.ema < 0.008:
            self.interval = 16
        if self.items:
            delay = 250 if iconic else max(1, int(self.interval - work * 1000))
            try:
                self.root.after(delay, self._tick)
            except tk.TclError:
                self.running = False
        else:
            self.running = False


def get_ticker(widget):
    root = widget.winfo_toplevel()
    t = getattr(root, "_nx_ticker", None)
    if t is None:
        t = Ticker(root)
        root._nx_ticker = t
    return t


def tween(ticker, owner, duration, update, done=None, ease=ease_out_cubic, delay=0.0):
    st = {"t": -float(delay)}

    def step(dt, now):
        st["t"] += dt
        if st["t"] < 0:
            return True
        p = st["t"] / duration if duration > 0 else 1.0
        update(ease(p) if p < 1 else ease(1.0))
        if p >= 1:
            if done:
                done()
            return False
        return True

    return ticker.add(step, owner)


# ------------------------------------------------------------------ scene ---
class Scene:
    """Animation helpers bound to one Canvas. Call reset() before every full redraw."""

    def __init__(self, canvas):
        self.cv = canvas
        self.ticker = get_ticker(canvas)
        self.handles = []
        self.keep = []
        self.groups = {}
        self._offsets_h = None
        self.stiff = 12.0

    # -- lifecycle
    def reset(self):
        for h in self.handles:
            self.ticker.remove(h)
        self.handles, self.keep, self.groups = [], [], {}
        self._offsets_h = None

    def on(self, fn, every=1):
        h = self.ticker.add(fn, self.cv, every)
        self.handles.append(h)
        return h

    def tween(self, duration, update, done=None, ease=ease_out_cubic, delay=0.0):
        h = tween(self.ticker, self.cv, duration, update, done, ease, delay)
        self.handles.append(h)
        return h

    # -- spring-eased groups of canvas items
    def mark(self):
        ids = self.cv.find_all()
        return max(ids) if ids else 0

    def group(self, tag, mark, enter=None, delay=0.0):
        """Tag every item created after `mark`; optionally slide them in from `enter` (dx, dy)."""
        ids = [i for i in self.cv.find_all() if i > mark]
        for i in ids:
            self.cv.addtag_withtag(tag, i)
        g = {"cx": 0.0, "cy": 0.0, "hx": 0.0, "hy": 0.0, "wait": 0.0, "bob": None, "bobc": 0.0}
        if enter and ids:
            self.cv.move(tag, enter[0], enter[1])
            g["cx"], g["cy"], g["wait"] = float(enter[0]), float(enter[1]), float(delay)
        self.groups[tag] = g
        if self._offsets_h is None:
            self._offsets_h = self.on(self._offsets_tick)
        return ids

    def hover_group(self, tag, dx=0.0, dy=0.0):
        g = self.groups.get(tag)
        if g:
            g["hx"], g["hy"] = dx, dy

    def bob(self, tag, amp=4.0, period=3.0, phase=0.0):
        g = self.groups.get(tag)
        if g:
            g["bob"] = (amp, period, phase)

    def _offsets_tick(self, dt, now):
        k = 1 - math.exp(-dt * self.stiff)
        cv = self.cv
        for tag, g in self.groups.items():
            if g["wait"] > 0:
                g["wait"] -= dt
                continue
            ex, ey = g["hx"] - g["cx"], g["hy"] - g["cy"]
            if abs(ex) > 0.03 or abs(ey) > 0.03:
                mx, my = ex * k, ey * k
                cv.move(tag, mx, my)
                g["cx"] += mx
                g["cy"] += my
            if g["bob"]:
                amp, per, ph = g["bob"]
                v = amp * math.sin(2 * math.pi * now / per + ph)
                cv.move(tag, 0, v - g["bobc"])
                g["bobc"] = v

    # -- numbers / text
    def count_up(self, item, target, duration=1.1, delay=0.0, fmt="{:,}"):
        if not target:
            return
        self.cv.itemconfigure(item, text=fmt.format(0))
        self.tween(duration, lambda p: self.cv.itemconfigure(item, text=fmt.format(int(round(target * p)))),
                   ease=ease_out_expo, delay=delay)

    def typewrite(self, item, text, cps=40.0, delay=0.0):
        self.cv.itemconfigure(item, text="")
        n = max(1, len(text))
        self.tween(n / cps, lambda p: self.cv.itemconfigure(item, text=text[:int(round(p * n))]),
                   ease=lambda t: clamp01(t), delay=delay)

    # -- shapes
    def line_chart(self, pts, color, fill, base_y, width=2.5, delay=0.0, duration=1.2, dot=True, follow=None):
        """Smooth line + soft area that draws itself left to right."""
        cv = self.cv
        dense = catmull(pts, 8)
        ys = [p[1] for p in pts]
        lo_y, hi_y = min(ys), max(ys)
        dense = [(px_, min(hi_y, max(lo_y, py_))) for px_, py_ in dense]   # no spline overshoot below/above the data
        area = cv.create_polygon(*(list(dense[0]) + list(dense[0]) + list(dense[1]) + [dense[1][0], base_y, dense[0][0], base_y]),
                                 fill=fill, outline="")
        line = cv.create_line(*(list(dense[0]) + list(dense[1])), fill=color, width=width,
                              capstyle="round", joinstyle="round")
        end = cv.create_oval(0, 0, 0, 0, fill=color, outline="") if dot else None
        n = len(dense) - 1

        def upd(p):
            ox, oy = self.off(follow)      # follow a spring-moved group (slide-in / hover lift)
            f = p * n
            i = min(n - 1, int(f))
            fr = f - i
            a, b = dense[i], dense[i + 1]
            tip = (a[0] + (b[0] - a[0]) * fr + ox, a[1] + (b[1] - a[1]) * fr + oy)
            seg = [c + (ox if k % 2 == 0 else oy) for k, c in enumerate([c for q in dense[:i + 1] for c in q])] + list(tip)
            if len(seg) < 4:
                seg = [dense[0][0] + ox, dense[0][1] + oy] + list(tip)
            cv.coords(line, *seg)
            cv.coords(area, *(seg + [tip[0], base_y + oy, dense[0][0] + ox, base_y + oy]))
            if end:
                cv.coords(end, tip[0] - 3.5, tip[1] - 3.5, tip[0] + 3.5, tip[1] + 3.5)

        upd(0.0)
        self.tween(duration, upd, ease=ease_in_out, delay=delay)
        return area, line

    def spin_ring(self, cx, cy, r, c1, c2, bg, width=3, segs=16, sweep=260, speed=150.0, every=2, tag=None):
        """Comet-style rotating gradient ring."""
        cv = self.cv
        ext = sweep / float(segs)
        arcs = []
        for i in range(segs):
            t = i / float(max(1, segs - 1))
            col = mix(mix(c1, c2, t), bg, (t ** 1.4) * 0.92)
            arcs.append(cv.create_arc(cx - r, cy - r, cx + r, cy + r, start=0, extent=ext + 2.0, style="arc",
                                      outline=col, width=width, tags=(tag,) if tag else ()))

        def step(dt, now):
            base = -(now * speed)
            for i, a in enumerate(arcs):
                cv.itemconfigure(a, start=(base + i * ext) % 360)

        self.on(step, every=every)
        return arcs

    def off(self, tag):
        """Current (dx, dy) of a group, so absolute-coordinate animations can follow it."""
        g = self.groups.get(tag) if tag else None
        return (g["cx"], g["cy"] + g["bobc"]) if g else (0.0, 0.0)

    def pulse_rings(self, cx, cy, r0, r1, color, bg, period=2.4, count=2, width=2, strength=0.75, follow=None):
        cv = self.cv
        rings = [cv.create_oval(cx - r0, cy - r0, cx + r0, cy + r0, outline=bg, width=width) for _ in range(count)]

        def step(dt, now):
            ox, oy = self.off(follow)
            for i, ring in enumerate(rings):
                p = ((now / period) + i / float(count)) % 1.0
                r = r0 + (r1 - r0) * ease_out_cubic(p)
                cv.coords(ring, cx + ox - r, cy + oy - r, cx + ox + r, cy + oy + r)
                cv.itemconfigure(ring, outline=mix(color, bg, 1 - strength * (1 - p) ** 1.6))

        self.on(step, every=2)
        return rings


# ------------------------------------------------------------------ orbs ----
class Orbs:
    """Soft aurora glows drifting on Lissajous paths."""

    def __init__(self, scene, specs, tag="fx_orb"):
        self.cv = scene.cv
        self.items = []
        for s in specs:
            img = orb_image(s["d"], s["color"], s["alpha"])
            iid = self.cv.create_image(s["cx"], s["cy"], image=img, tags=(tag,))
            self.items.append((iid, s))
            scene.keep.append(img)
        scene.on(self.step, every=2)

    def step(self, dt, now):
        for iid, s in self.items:
            x = s["cx"] + s["ax"] * math.sin(now * s["sx"] + s["ph"])
            y = s["cy"] + s["ay"] * math.cos(now * s["sy"] + s["ph"] * 1.3)
            self.cv.coords(iid, x, y)


class ParticleNet:
    """Floating particles joined by faint links; optionally attracted to the mouse."""

    def __init__(self, scene, box, n, color, bg, link=110.0, speed=14.0, max_links=56,
                 radius=(1.2, 2.8), link_strength=0.55, tag="fx_net", mouse_reach=150.0, seed=None):
        self.cv = scene.cv
        self.x1, self.y1, self.x2, self.y2 = box
        self.color, self.bg, self.link, self.strength = color, bg, link, link_strength
        self.mouse = None
        self.mouse_reach = mouse_reach
        rnd = random.Random(seed)
        self.p = []
        self.dots = []
        for _ in range(n):
            x = rnd.uniform(self.x1, self.x2)
            y = rnd.uniform(self.y1, self.y2)
            a = rnd.uniform(0, 6.283)
            sp = rnd.uniform(0.4, 1.0) * speed
            r = rnd.uniform(*radius)
            tone = rnd.uniform(0.35, 0.95)
            self.p.append([x, y, math.cos(a) * sp, math.sin(a) * sp, r])
            self.dots.append(self.cv.create_oval(x - r, y - r, x + r, y + r,
                                                 fill=mix(bg, color, tone), outline="", tags=(tag,)))
        self.pool = [self.cv.create_line(0, 0, 0, 0, fill=bg, width=1, state="hidden", tags=(tag,))
                     for _ in range(max_links)]
        self.used = 0
        if link > 0:
            scene.on(self.step, every=2)
        else:
            scene.on(self.step_free, every=2)

    def _move(self, dt):
        w, h = self.x2 - self.x1, self.y2 - self.y1
        m = self.mouse
        for p in self.p:
            if m:
                dx, dy = p[0] - m[0], p[1] - m[1]
                d2 = dx * dx + dy * dy
                if 1 < d2 < 90 * 90:
                    d = math.sqrt(d2)
                    f = (1 - d / 90.0) * 38.0 * dt
                    p[0] += dx / d * f * 6
                    p[1] += dy / d * f * 6
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            if p[0] < self.x1:
                p[0] += w
            elif p[0] > self.x2:
                p[0] -= w
            if p[1] < self.y1:
                p[1] += h
            elif p[1] > self.y2:
                p[1] -= h

    def step_free(self, dt, now):
        self._move(dt)
        for p, d in zip(self.p, self.dots):
            self.cv.coords(d, p[0] - p[4], p[1] - p[4], p[0] + p[4], p[1] + p[4])

    def step(self, dt, now):
        self._move(dt)
        cv, p = self.cv, self.p
        for pt, d in zip(p, self.dots):
            cv.coords(d, pt[0] - pt[4], pt[1] - pt[4], pt[0] + pt[4], pt[1] + pt[4])
        L, L2 = self.link, self.link * self.link
        used, cap = 0, len(self.pool)
        n = len(p)
        for i in range(n):
            a = p[i]
            for j in range(i + 1, n):
                if used >= cap:
                    break
                b = p[j]
                dx, dy = a[0] - b[0], a[1] - b[1]
                d2 = dx * dx + dy * dy
                if d2 < L2:
                    t = 1 - math.sqrt(d2) / L
                    ln = self.pool[used]
                    cv.coords(ln, a[0], a[1], b[0], b[1])
                    cv.itemconfigure(ln, fill=mix(self.bg, self.color, self.strength * t), state="normal")
                    used += 1
        m = self.mouse
        if m:
            R = self.mouse_reach
            for a in p:
                if used >= cap:
                    break
                d = math.hypot(a[0] - m[0], a[1] - m[1])
                if d < R:
                    ln = self.pool[used]
                    cv.coords(ln, a[0], a[1], m[0], m[1])
                    cv.itemconfigure(ln, fill=mix(self.bg, "#7DE9FF", 0.85 * (1 - d / R)), state="normal")
                    used += 1
        for k in range(used, self.used):
            cv.itemconfigure(self.pool[k], state="hidden")
        self.used = used


# ---------------------------------------------------------------- hero ------
class AuthHero(tk.Canvas):
    """Animated brand panel for the login screen (aurora, constellation, live chat preview)."""

    BG_TOP, BG_BOT = (16, 11, 52), (36, 24, 104)
    CARD_BG = "#1D1560"

    def __init__(self, parent, page_bg="#F1EEFF"):
        super().__init__(parent, bg="#1A1250", highlightthickness=0, bd=0)
        self.scene = Scene(self)
        self._size = (0, 0)
        self._job = None
        self._entered = False
        self.net = None
        self._bg_img = None
        self.bind("<Configure>", self._on_configure)
        self.bind("<Motion>", self._on_motion)
        self.bind("<Leave>", self._on_leave)

    # -- events
    def _on_configure(self, e):
        size = (e.width, e.height)
        if size == self._size:
            return
        self._size = size
        if self._job:
            try:
                self.after_cancel(self._job)
            except Exception:
                pass
        self._job = self.after(60, self._build)

    def _on_motion(self, e):
        if self.net:
            self.net.mouse = (e.x, e.y)
        self._hover(e.x, e.y)

    def _on_leave(self, e):
        if self.net:
            self.net.mouse = None
        self._hover(-999, -999)

    def _hover(self, x, y):
        for tag, box in getattr(self, "_cards", []):
            inside = box[0] <= x <= box[2] and box[1] <= y <= box[3]
            self.scene.hover_group(tag, 6 if inside else 0, 0)

    # -- background art
    def _make_bg(self, w, h):
        def build():
            top = Image.new("RGB", (w, h), self.BG_TOP)
            bot = Image.new("RGB", (w, h), self.BG_BOT)
            img = Image.composite(bot, top, Image.linear_gradient("L").resize((w, h))).convert("RGBA")
            dots = Image.new("RGBA", (w, h), (0, 0, 0, 0))
            dd = ImageDraw.Draw(dots)
            for gx in range(18, w, 30):
                for gy in range(18, h, 30):
                    dd.ellipse([gx - 1, gy - 1, gx + 1, gy + 1], fill=(255, 255, 255, 16))
            img.alpha_composite(dots)
            return ImageTk.PhotoImage(img)
        return cached(("herobg", w, h, self.BG_TOP, self.BG_BOT), build)

    # -- build the whole scene
    def _build(self):
        try:
            if not self.winfo_exists():
                return
            self._build_scene()
        except tk.TclError:
            pass

    def _build_scene(self):
        w, h = self.winfo_width(), self.winfo_height()
        if w < 300 or h < 300:
            return
        sc, cv = self.scene, self
        sc.reset()
        cv.delete("all")
        self.net = None
        first = not self._entered
        self._entered = True
        FONT = "Segoe UI"

        bg = self._make_bg(w, h)
        sc.keep.append(bg)
        cv.create_image(0, 0, anchor="nw", image=bg, tags=("hero_bg",))

        Orbs(sc, [
            dict(color="#22D3EE", d=560, alpha=84, cx=w * 0.88, cy=h * 0.10, ax=46, ay=34, sx=0.35, sy=0.28, ph=0.0),
            dict(color="#C026D3", d=620, alpha=88, cx=w * 0.10, cy=h * 0.92, ax=54, ay=40, sx=0.27, sy=0.33, ph=1.7),
            dict(color="#6D5DF6", d=700, alpha=110, cx=w * 0.52, cy=h * 0.48, ax=70, ay=56, sx=0.20, sy=0.24, ph=3.1),
            dict(color="#2DD4BF", d=360, alpha=46, cx=w * 0.78, cy=h * 0.80, ax=40, ay=30, sx=0.42, sy=0.36, ph=4.4),
        ])
        n = int(max(22, min(48, w * h / 17000)))
        self.net = ParticleNet(sc, (0, 0, w, h), n, "#A89FFF", "#1D1560", link=122, speed=15, seed=7, link_strength=0.8)

        # ---- layout
        bw = int(min(470, w * 0.82))
        x0 = (w - bw) // 2
        demo_h = 172
        block_h = 92 + 18 + 62 * 3 + 18 + demo_h
        y0 = max(14, (h - block_h) // 2)

        # logo + title
        m = sc.mark()
        lx, ly = x0 + 34, y0 + 34
        cv.create_oval(lx - 31, ly - 31, lx + 31, ly + 31, fill="#6D5DF6", outline="")
        cv.create_oval(lx - 24, ly - 24, lx + 24, ly + 24, fill="#A855F7", outline="")
        cv.create_oval(lx - 16, ly - 16, lx + 16, ly + 16, fill="#22D3EE", outline="")
        cv.create_oval(lx - 9, ly - 9, lx + 9, ly + 9, fill="#FFFFFF", outline="")
        sc.pulse_rings(lx, ly, 32, 52, "#7DE9FF", "#1D1560", period=2.8, count=2)
        sc.spin_ring(lx, ly, 38, "#FFFFFF", "#22D3EE", "#1D1560", width=3, segs=18, sweep=250, speed=130)
        title = cv.create_text(x0 + 90, y0 + 4, anchor="nw", text="NexaChat", font=(FONT, 27, "bold"), fill="#FFFFFF")
        tag_item = cv.create_text(x0 + 92, y0 + 46, anchor="nw", text="", font=(FONT, 9, "bold"), fill="#9FF3FF")
        sc.group("hero_logo", m)
        sc.typewrite(tag_item, "CONNECT  \u2022  CHAT  \u2022  GROW", cps=22, delay=0.55 if first else 0.0)

        # description
        m = sc.mark()
        cv.create_text(x0 + 2, y0 + 92, anchor="nw",
                       text="A smarter space for real-time conversations,\ngroups, statuses and meaningful connections.",
                       font=(FONT, 11), fill="#E4DEFF")
        sc.group("hero_desc", m, enter=(0, 18) if first else None, delay=0.25)

        # feature cards
        feats = [("01", "Real-time conversations", "Chat privately and stay connected.", "#63E6FF"),
                 ("02", "Groups & status", "Share updates and collaborate together.", "#C4A8FF"),
                 ("03", "Smart analytics", "Understand your conversation activity.", "#5EEAD4")]
        self._cards = []
        self._spot = []
        fy = y0 + 92 + 18 + 28
        for i, (num, ttl, desc, acc) in enumerate(feats):
            ch = 54
            top = fy + i * 62
            m = sc.mark()
            gi = glass_image(bw, ch, 14)
            sc.keep.append(gi)
            cv.create_image(x0, top, anchor="nw", image=gi)
            outline = cv.create_polygon(rr_points(x0 + .5, top + .5, x0 + bw - .5, top + ch - .5, 14),
                                        smooth=True, fill="", outline="#3B2E9A", width=1)
            cv.create_oval(x0 + 14, top + 13, x0 + 42, top + 41, fill=mix("#1D1560", acc, 0.18), outline=mix("#1D1560", acc, 0.55))
            cv.create_text(x0 + 28, top + 27, text=num, font=(FONT, 8, "bold"), fill=acc)
            cv.create_text(x0 + 56, top + 18, anchor="w", text=ttl, font=(FONT, 10, "bold"), fill="#FFFFFF")
            cv.create_text(x0 + 56, top + 37, anchor="w", text=desc, font=(FONT, 8), fill="#BDB2F2")
            tag = "hero_feat%d" % i
            sc.group(tag, m, enter=(-46, 0) if first else None, delay=0.40 + 0.12 * i)
            self._cards.append((tag, (x0, top, x0 + bw, top + ch)))
            self._spot.append((outline, acc))

        spot = {"cur": [0.0, 0.0, 0.0]}

        def spotlight(dt, now):
            active = int(now / 2.6) % 3
            k = 1 - math.exp(-dt * 9)
            for i, (oid, acc) in enumerate(self._spot):
                tgt = 1.0 if i == active else 0.0
                spot["cur"][i] += (tgt - spot["cur"][i]) * k
                cv.itemconfigure(oid, outline=mix("#3B2E9A", acc, spot["cur"][i]),
                                 width=2 if spot["cur"][i] > 0.55 else 1)
        sc.on(spotlight, every=2)

        # live chat preview
        dy = fy + 3 * 62 + 4
        m = sc.mark()
        self._build_demo(x0, dy, bw, demo_h)
        sc.group("hero_demo", m, enter=(0, 30) if first else None, delay=0.85)
        self._hover(-999, -999)

    # -- scripted live conversation
    def _build_demo(self, x, y, w, h):
        cv, sc = self, self.scene
        FONT = "Segoe UI"
        CB = self.CARD_BG
        gi = glass_image(w, h, 16, fill=(10, 6, 40, 120), border=(255, 255, 255, 40))
        sc.keep.append(gi)
        cv.create_image(x, y, anchor="nw", image=gi)
        dot = cv.create_oval(x + 16, y + 15, x + 24, y + 23, fill="#34D399", outline="")
        halo = cv.create_oval(x + 16, y + 15, x + 24, y + 23, outline="#34D399", width=1)
        cv.create_text(x + 32, y + 19, anchor="w", text="LIVE PREVIEW", font=(FONT, 8, "bold"), fill="#34D399")
        cv.create_text(x + w - 16, y + 19, anchor="e", text="Team NexaChat", font=(FONT, 8), fill="#BDB2F2")
        cv.create_line(x + 14, y + 34, x + w - 14, y + 34, fill="#3A2E8F")

        def goff():
            g = sc.groups.get("hero_demo")
            return (g["cx"], g["cy"]) if g else (0.0, 0.0)

        def halo_step(dt, now):
            p = (now / 1.6) % 1.0
            r = 4 + 9 * p
            ox, oy = goff()
            cx, cy = x + 20 + ox, y + 19 + oy
            cv.coords(halo, cx - r, cy - r, cx + r, cy + r)
            cv.itemconfigure(halo, outline=mix("#34D399", "#1D1560", 0.2 + 0.8 * p))
        sc.on(halo_step, every=2)

        script = [
            dict(side="L", text="Hey! The new release is live.", t=0.7, typing=1.3, color="#3A2D8F", fg="#EDE9FF"),
            dict(side="R", text="Amazing. Sharing it with the group now.", t=4.0, typing=1.4, color="#7C6BFF", fg="#FFFFFF"),
            dict(side="L", text="Perfect, everyone is online!", t=7.6, typing=1.1, color="#3A2D8F", fg="#EDE9FF"),
        ]
        LOOP, FADE = 14.0, 0.5
        f = tkfont.Font(family=FONT, size=9)
        slot_y = [y + 46 + i * 40 for i in range(3)]
        bubbles = []
        for i, s in enumerate(script):
            bwid = f.measure(s["text"]) + 28
            bx1 = x + 16 if s["side"] == "L" else x + w - 16 - bwid
            sy = slot_y[i]
            poly = cv.create_polygon(rr_points(bx1, sy, bx1 + bwid, sy + 30, 15), smooth=True, fill=CB, outline="",
                                     state="hidden")
            txt = cv.create_text(bx1 + 14, sy + 15, anchor="w", text=s["text"], font=(FONT, 9), fill=CB, state="hidden")
            tick = cv.create_text(bx1 + bwid - 10, sy + 24, anchor="e", text="\u2713\u2713" if s["side"] == "R" else "",
                                  font=(FONT, 7, "bold"), fill=CB, state="hidden")
            bubbles.append(dict(poly=poly, txt=txt, tick=tick, x1=bx1, w=bwid, y=sy, last=None, **s))
        # typing indicator (3 dots)
        tbub = cv.create_polygon(rr_points(0, 0, 10, 10, 5), smooth=True, fill="#3A2D8F", outline="", state="hidden")
        dots = [cv.create_oval(0, 0, 0, 0, fill="#E4DEFF", outline="", state="hidden") for _ in range(3)]
        t0 = {"v": None}

        def show_typing(b, now_lt):
            ox, oy = goff()
            bx1 = x + 16 + ox if b["side"] == "L" else x + w - 16 - 58 + ox
            sy = b["y"] + oy
            cv.coords(tbub, *rr_points(bx1, sy + 2, bx1 + 58, sy + 28, 13))
            cv.itemconfigure(tbub, state="normal", fill="#3A2D8F" if b["side"] == "L" else "#6558E8")
            for k, d in enumerate(dots):
                bounce = math.sin(now_lt * 7.5 - k * 0.9)
                cx = bx1 + 19 + k * 10
                cy = sy + 15 - max(0, bounce) * 3.5
                cv.coords(d, cx - 2.6, cy - 2.6, cx + 2.6, cy + 2.6)
                cv.itemconfigure(d, state="normal")

        def hide_typing():
            cv.itemconfigure(tbub, state="hidden")
            for d in dots:
                cv.itemconfigure(d, state="hidden")

        def step(dt, now):
            if t0["v"] is None:
                t0["v"] = now
            lt = (now - t0["v"]) % LOOP
            typing_for = None
            out = 1.0 - clamp01((lt - (LOOP - FADE)) / FADE)
            for i, b in enumerate(bubbles):
                appear = b["t"] + b["typing"]
                if b["t"] <= lt < appear:
                    typing_for = (b, lt)
                p = clamp01((lt - appear) / 0.42)
                p = ease_out_back(p) if p < 1 else 1.0
                vis = lt >= appear
                seen = 1.0 if (b["side"] == "R" and lt > 9.2) else 0.0
                gx, gy = goff()
                key = (round(p * 40), round(out * 20), vis, seen, round(gx), round(gy))
                if key == b["last"]:
                    continue
                b["last"] = key
                if not vis:
                    for k in ("poly", "txt", "tick"):
                        cv.itemconfigure(b[k], state="hidden")
                    continue
                a = clamp01(p) * out
                off = (1 - min(1.0, p)) * 16
                sy = b["y"] + off + gy
                bx = b["x1"] + gx
                cv.coords(b["poly"], *rr_points(bx, sy, bx + b["w"], sy + 30, 15))
                cv.coords(b["txt"], bx + 14, sy + 15)
                cv.coords(b["tick"], bx + b["w"] - 10, sy + 24)
                cv.itemconfigure(b["poly"], state="normal", fill=mix(CB, b["color"], a))
                cv.itemconfigure(b["txt"], state="normal", fill=mix(CB, b["fg"], a))
                tick_col = mix("#BFC6FF", "#7DE9FF", seen)
                cv.itemconfigure(b["tick"], state="normal", fill=mix(CB, tick_col, a))
            if typing_for:
                show_typing(*typing_for)
            else:
                hide_typing()

        sc.on(step, every=1)
