import tkinter as tk
from fxkit import palette_for, Look
from dashboard_fx import DashboardFX
from pages_fx import AnalyticsPage, ThemesPage
from chat_fx import ChatShell
from auth_fx import AuthScreen
from status_fx import StatusShell
from settings_fx import SettingsPage
from tkinter import ttk, messagebox, filedialog
from datetime import datetime, timedelta
from database import ChatDB
from ui_components import (
    AuthFrame, StyledButton, PRIMARY_COLOR, SUCCESS_COLOR, BG_COLOR, TEXT_COLOR,
    DEFAULT_CHAT_BG, PRIMARY_DARK, MUTED_TEXT, BORDER_COLOR, NOTIF_RED, get_palette,
    ChatBubble, UserListItem, DateHeader, SearchBar, EmojiPicker,
    CustomEntry, WhatsAppSendButton, ChatHeader, StarredMessagesPopup,
    GroupListItem, CreateGroupPopup, GroupMembersPopup,
    StatusAvatar, StatusListItem, MyStatusItem, StatusViewerPopup, StatusViewDetailsPopup, AddStatusPopup,
    ReplyPreviewBar,   # NEW: Reply feature
    RoundedCard, StretchyRoundedCard, draw_round_rect, make_glow_rect_image, _blend, PRIMARY_LIGHT,   # NEW: shared design helpers
    DASH_FONT, DASH_PAGE, DASH_TEXT, DASH_MUTED, DASH_BLUE, DASH_INDIGO, DASH_RED,
    get_icon, make_dash_background_pil, make_sidebar_panel_pil, make_glass_card, make_gradient_rounded_image,
    make_sparkline, make_avatar, make_pill_image
)
from PIL import Image, ImageTk
import tkinter.font as tkfont
import os
import json


class MainApp:
    def __init__(self, root):
        self.db = ChatDB()
        self.root = root
        self.root.title("NexaChat — Connect • Chat • Grow")
        self.root.geometry("450x600")
        self.root.configure(bg=BG_COLOR)
        
        self.current_user_id = None
        self.current_username = ""
        self.selected_recipient_id = None
        self.selected_group_id = None
        self.selected_group_name = None
        self.chat_mode = "private"
        self.all_users = [] 
        self.last_data_check = "" 
        self.typing_timer = None
        self.current_theme = self._load_saved_theme()

        self.polling_active = False

        # Product-level shortcuts make the desktop app feel native.
        self.root.bind("<Control-k>", lambda e: self._focus_global_search())
        self.root.bind("<Escape>", lambda e: self.show_dashboard() if self.current_user_id else None)

        # --- Reply feature state ---
        # reply_target_id    : Right-click chesina original message id
        # reply_target_text  : Original message text (preview kosam)
        # reply_target_sender: Original sender name (preview kosam)
        self.reply_target_id = None
        self.reply_target_text = None
        self.reply_target_sender = None
        self._reply_preview_bar = None   # ReplyPreviewBar widget reference

        # --- Edit feature state ---
        # edit_target_id   : Edit chesayyala anukuntunna message id
        # edit_target_text : Original text (cancel chesthe restore kosam)
        self.edit_target_id = None
        self.edit_target_text = None
        self._edit_preview_bar = None    # Edit mode indicator bar widget

        self.container = tk.Frame(self.root, bg=BG_COLOR)
        self.container.pack(expand=True, fill="both")
        
        self.show_login_page()

    # ==================== GENERAL HELPERS ====================

    def _config_path(self):
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), "nexachat_settings.json")

    def _read_settings(self):
        try:
            with open(self._config_path(), "r", encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    def _load_saved_theme(self):
        return self._read_settings().get("theme", "Ocean Blue")

    def _remembered_user(self):
        return self._read_settings().get("last_user", "")

    def _save_settings(self, **extra):
        try:
            data = self._read_settings()
            data["theme"] = self.current_theme
            data.update(extra)
            with open(self._config_path(), "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception:
            pass

    def _focus_global_search(self):
        # Ctrl+K opens the chat list and focuses its search field.
        try:
            if not self.current_user_id:
                return
            if self._private_active():
                self.shell.focus_search()
            else:
                self.show_chat_screen()
                self.root.after(160, lambda: self.shell.focus_search() if self._shell_alive() else None)
        except Exception:
            pass

    def _shell_alive(self):
        sh = getattr(self, "shell", None)
        try:
            return bool(sh is not None and sh.winfo_exists())
        except Exception:
            return False

    def _private_active(self):
        return self.chat_mode == "private" and self._shell_alive()

    def _group_active(self):
        return self.chat_mode == "group" and self._shell_alive()

    def _look(self):
        return Look(palette_for(self.current_theme))

    def _ui_palette(self):
        palettes = {
            "Ocean Blue": {"bg":"#F4F2FF","surface":"#FFFFFF","soft":"#EFEBFF","text":"#10233F","muted":"#72819A","accent":"#6D5DF6","accent2":"#C026D3","line":"#E6ECF5","good":"#10B981"},
            "Midnight Aurora": {"bg":"#08111F","surface":"#0D1728","soft":"#13243C","text":"#F8FAFC","muted":"#A7B4C7","accent":"#60A5FA","accent2":"#C084FC","line":"#22324A","good":"#34D399"},
            "Sunset Coral": {"bg":"#FFF7F2","surface":"#FFFFFF","soft":"#FFF0EA","text":"#3B1D2A","muted":"#80616B","accent":"#F97316","accent2":"#EC4899","line":"#F1DDD5","good":"#10B981"},
            "Forest Mint": {"bg":"#F2FBF7","surface":"#FFFFFF","soft":"#E9F8F2","text":"#12352D","muted":"#648078","accent":"#059669","accent2":"#0F766E","line":"#D8EEE6","good":"#16A34A"},
            "Royal Violet": {"bg":"#F8F5FF","surface":"#FFFFFF","soft":"#F1EBFF","text":"#24134A","muted":"#756A8D","accent":"#7C3AED","accent2":"#4F46E5","line":"#E9DFFF","good":"#10B981"},
            "Cyber Neon": {"bg":"#080B16","surface":"#0C1020","soft":"#121A2D","text":"#F8FAFC","muted":"#9AA6BD","accent":"#22D3EE","accent2":"#A855F7","line":"#25304A","good":"#34D399"},
        }
        return palettes.get(self.current_theme, palettes["Ocean Blue"])

    def clear_container(self):
        self.polling_active = False
        for widget in self.container.winfo_children():
            widget.destroy()
        self._page_fade_in()

    def _page_fade_in(self, start=0.80, steps=7, ms=16):
        """Quick fade-in of the window on every screen change (no-op where -alpha is unsupported)."""
        try:
            self.root.attributes("-alpha", start)
        except Exception:
            return

        def tick(i=1):
            try:
                a = start + (1.0 - start) * min(1.0, i / float(steps))
                self.root.attributes("-alpha", 1.0 if i >= steps else a)
                if i < steps:
                    self.root.after(ms, lambda: tick(i + 1))
            except Exception:
                pass
        self.root.after(ms, tick)

    # ==================== REPLY HELPERS ====================

    def handle_reply_click(self, msg_id):
        """
        User right-click → 'Reply' select chessinappudu call avutundi.
        DB nundi original message fetch chesi reply state set chestundi.
        """
        row = self.db.get_message_by_id(msg_id)
        if not row:
            return
        _, _, msg_text, sender_name = row
        self.reply_target_id = msg_id
        self.reply_target_text = msg_text
        self.reply_target_sender = sender_name
        self._show_reply_preview()

    def _show_reply_preview(self):
        """Shows the 'replying to' banner above the input."""
        if self._private_active():
            who = "yourself" if self.reply_target_sender == self.current_username else (self.reply_target_sender or "message")
            self.shell.composer.set_banner("reply", "Replying to " + who, self.reply_target_text or "")
            self.shell.composer.focus()
            return
        if self._reply_preview_bar and self._reply_preview_bar.winfo_exists():
            self._reply_preview_bar.destroy()
        if not hasattr(self, 'input_frame') or not self.input_frame.winfo_exists():
            return
        self._reply_preview_bar = ReplyPreviewBar(
            self.input_frame, sender_name=self.reply_target_sender,
            message_text=self.reply_target_text, on_cancel=self.cancel_reply)
        self._reply_preview_bar.pack(fill="x", before=self.msg_entry, pady=(0, 4))

    def cancel_reply(self):
        """Clears the reply state and its banner."""
        self.reply_target_id = None
        self.reply_target_text = None
        self.reply_target_sender = None
        if self._private_active() and not self.edit_target_id:
            self.shell.composer.clear_banner()
        if self._reply_preview_bar and self._reply_preview_bar.winfo_exists():
            self._reply_preview_bar.destroy()
        self._reply_preview_bar = None

    def _cancel_banner(self):
        if self.edit_target_id:
            self.cancel_edit()
        else:
            self.cancel_reply()

    def scroll_to_message(self, msg_id):
        """
        Reply preview click chessinappudu original message ki scroll chestundi.
        msg_id tho matching bubble widget ki scroll avutundi.
        """
        if not hasattr(self, 'canvas') or not self.canvas.winfo_exists():
            return
        if not hasattr(self, 'scrollable_frame') or not self.scrollable_frame.winfo_exists():
            return

        # scrollable_frame lo anni bubbles loop chesi msg_id match ainatidi find cheyyadam
        for widget in self.scrollable_frame.winfo_children():
            if hasattr(widget, 'msg_id') and widget.msg_id == msg_id:
                # Widget position calculate chesi canvas scroll cheyyadam
                self.root.update_idletasks()
                widget_y = widget.winfo_y()
                canvas_height = self.canvas.winfo_height()
                scroll_region = self.canvas.bbox("all")
                if scroll_region:
                    total_height = scroll_region[3]
                    if total_height > 0:
                        fraction = max(0.0, (widget_y - canvas_height // 3) / total_height)
                        self.canvas.yview_moveto(fraction)
                        # Highlight effect — briefly change bubble bg
                        self._highlight_bubble(widget)
                break

    def _highlight_bubble(self, bubble_widget):
        """Original message bubble ni briefly highlight chestundi (WhatsApp style)."""
        try:
            bubble_widget.flash_highlight()
        except:
            pass

    # ==================== EDIT HELPERS ====================

    def handle_edit_click(self, msg_id, original_text):
        """Enter edit mode: banner above the input + the original text loaded for editing."""
        self.cancel_reply()
        self.edit_target_id = msg_id
        self.edit_target_text = original_text
        if self._private_active():
            self.shell.composer.set_banner("edit", "Editing message", original_text)
            self.shell.composer.set(original_text)
            self.shell.composer.focus()
            return
        self._show_edit_bar()
        self.msg_entry.delete(0, tk.END)
        self.msg_entry.entry.insert(0, original_text)
        self.msg_entry.entry.focus_set()
        self.msg_entry.entry.icursor(tk.END)

    def _show_edit_bar(self):
        """Input box paina edit mode indicator bar show chestundi."""
        if self._edit_preview_bar and self._edit_preview_bar.winfo_exists():
            self._edit_preview_bar.destroy()

        if not hasattr(self, 'input_frame') or not self.input_frame.winfo_exists():
            return

        # Edit mode bar — yellow tint tho distinguish avutundi
        self._edit_preview_bar = tk.Frame(
            self.input_frame, bg="#FEF3C7",
            highlightbackground="#D97706", highlightthickness=1,
            padx=8, pady=4
        )
        self._edit_preview_bar.pack(fill="x", before=self.msg_entry, pady=(0, 4))

        # Left colored strip
        tk.Frame(self._edit_preview_bar, bg="#D97706", width=3).pack(side="left", fill="y", padx=(0, 8))

        info = tk.Frame(self._edit_preview_bar, bg="#FEF3C7")
        info.pack(side="left", fill="both", expand=True)

        tk.Label(info, text="✏️ Editing message", font=("Segoe UI", 9, "bold"),
                 bg="#FEF3C7", fg="#B45309").pack(anchor="w")

        preview = self.edit_target_text[:60] + "..." if len(self.edit_target_text) > 60 else self.edit_target_text
        tk.Label(info, text=preview, font=("Segoe UI", 9),
                 bg="#FEF3C7", fg="#6B7280").pack(anchor="w")

        # Cancel button
        tk.Button(self._edit_preview_bar, text="✕", font=("Segoe UI", 10, "bold"),
                  bg="#FEF3C7", fg="#6B7280", bd=0, cursor="hand2",
                  command=self.cancel_edit).pack(side="right", padx=5)

    def cancel_edit(self):
        """Leaves edit mode and empties the input."""
        self.edit_target_id = None
        self.edit_target_text = None
        if self._edit_preview_bar and self._edit_preview_bar.winfo_exists():
            self._edit_preview_bar.destroy()
        self._edit_preview_bar = None
        if self._private_active():
            self.shell.composer.clear_banner()
            self.shell.composer.clear()
        elif hasattr(self, 'msg_entry') and self.msg_entry is not None and self.msg_entry.winfo_exists():
            self.msg_entry.delete(0, tk.END)

    def _on_mousewheel(self, event, canvas):
        canvas.yview_scroll(int(-1*(event.delta/120)), "units")

    def upload_profile_pic(self):
        file_path = filedialog.askopenfilename(
            title="Select Profile Picture",
            filetypes=[("Image files", "*.jpg *.png *.jpeg")]
        )
        if file_path:
            try:
                if self.db.update_user_dp(self.current_user_id, file_path):
                    messagebox.showinfo("Success", "Profile Picture Updated!")
                    self.show_dashboard() 
                else:
                    messagebox.showerror("Error", "Failed to update DP.")
            except: pass

    def handle_star_toggle(self, msg_id):
        if self.db.toggle_star_message(msg_id):
            self.refresh_messages(force=True)
        else:
            messagebox.showerror("Error", "Star status update cheyadam kudiraledu.")

    def open_starred_messages(self):
        starred_data = self.db.get_starred_messages(self.current_user_id)
        StarredMessagesPopup(self.root, starred_data, PRIMARY_COLOR)

    # ==================================================================
    #  DASHBOARD — drawn on two canvases (sidebar + content) so glass
    #  cards, vector icons and the pastel wave backdrop can blend
    #  (plain Tk widgets cannot be transparent). Same data, same buttons,
    #  same click actions as before — only the visuals changed.
    # ==================================================================
    def show_dashboard(self):
        """Professional modern dashboard inspired by the selected design (#18)."""
        self.clear_container()
        self.root.geometry("1240x760")
        self.root.minsize(1050, 680)
        self.selected_recipient_id = None
        self.selected_group_id = None
        self.chat_mode = "private"

        self.db.cleanup_expired_statuses()
        data = self._dash_collect()

        # Theme palette - selected from the in-app Themes page.
        C = palette_for(self.current_theme)
        look = Look(C)

        shell = tk.Frame(self.container, bg=C["PAGE"])
        shell.pack(fill="both", expand=True)
        side = tk.Canvas(shell, width=222, bg=look.sb_top, highlightthickness=0, bd=0)
        side.pack(side="left", fill="y")
        content = tk.Canvas(shell, bg=C["PAGE"], highlightthickness=0, bd=0)
        content.pack(side="left", fill="both", expand=True)
        self._dash_canvas = content

        # Animated, theme-aware dashboard (see dashboard_fx.py / fxkit.py / fx.py)
        self._dash_fx = DashboardFX(self, side, content, C, data)

        def _dash_scroll(event):
            try:
                content.yview_scroll(int(-1 * (event.delta / 120)), "units")
            except Exception:
                pass
        content.bind_all("<MouseWheel>", _dash_scroll)
        shell.bind("<Destroy>", lambda e: content.unbind_all("<MouseWheel>") if e.widget is shell else None)

    def _dash_collect(self):
        uid = self.current_user_id
        d = {"username": self.current_username}
        d["status_count"] = self._get_unread_statuses_count()
        try:
            d["has_dp"] = bool(self.db.get_user_dp(uid))
            d["dp_ok"] = True
        except Exception:
            d["has_dp"], d["dp_ok"] = False, False
        try:
            msgs = self.db.get_analytics_messages(uid)
            d["sent"] = sum(1 for m in msgs if m[0] == uid)
            d["msgs"] = msgs
        except Exception:
            d["sent"], d["msgs"] = 0, []
        try:
            d["group_rows"] = self.db.get_user_groups(uid) or []
            d["groups"] = len(d["group_rows"])
        except Exception:
            d["groups"], d["group_rows"] = 0, []
        try:
            dp = self.db.get_user_dp(uid)
            d["dp_path"] = dp if dp else None
        except Exception:
            d["dp_path"] = None
        try:
            d["status_updates"] = self.db.get_status_count(uid)
        except Exception:
            d["status_updates"] = 0
        try:
            contacts = self.db.get_analytics_contacts(uid)[:6]
        except Exception:
            contacts = []
        d["recent"] = [(cid, uname, (sent or 0) + (received or 0), self._dash_last_time(cid))
                       for cid, uname, sent, received in contacts]
        return d

    def _dash_last_time(self, contact_id):
        """'2 hours ago' style hint for the Recent Chats rows (display only)."""
        try:
            hist = self.db.get_chat_history(self.current_user_id, contact_id)
            if not hist:
                return ""
            t = datetime.strptime(str(hist[-1][2]).replace("T", " ")[:19], "%Y-%m-%d %H:%M:%S")
            secs = max(0, int((datetime.now() - t).total_seconds()))
            if secs < 60:
                return "just now"
            if secs < 3600:
                n = secs // 60
                return f"{n} minute{'s' if n != 1 else ''} ago"
            if secs < 86400:
                n = secs // 3600
                return f"{n} hour{'s' if n != 1 else ''} ago"
            if secs < 7 * 86400:
                n = secs // 86400
                return f"{n} day{'s' if n != 1 else ''} ago"
            return t.strftime("%d %b")
        except Exception:
            return ""

    def _open_chat_with(self, recipient_id, recipient_name):
        """Real navigation shortcut: opens the existing chat screen straight into a conversation."""
        self.show_chat_screen()
        self.load_user_chat(recipient_id, recipient_name)

    def _get_unread_statuses_count(self):
        try:
            users_with_statuses = self.db.get_users_with_statuses(self.current_user_id)
            return sum(row[5] for row in users_with_statuses if row[5] > 0)
        except:
            return 0

    # ==================== MOTIVATION MODE ====================

    def open_motivation_mode(self):
        """Dashboard nundi Motivation Mode popup open chestundi."""
        from ui_components import MotivationModePopup
        MotivationModePopup(self.root, self.current_user_id, self.db)

    # ==================== CHAT ANALYTICS ====================

    def open_chat_analytics(self):
        """Open analytics inside the main application window (not a separate popup)."""
        self.show_analytics_screen()

    def show_analytics_screen(self):
        self.clear_container()
        self.root.geometry("1120x740")
        self.root.minsize(950, 700)
        C = palette_for(self.current_theme)
        cv = tk.Canvas(self.container, bg=C["PAGE"], highlightthickness=0, bd=0)
        cv.pack(fill="both", expand=True)
        uid = self.current_user_id
        try:
            msgs = self.db.get_analytics_messages(uid)
        except Exception:
            msgs = []
        try:
            contacts = self.db.get_analytics_contacts(uid)
        except Exception:
            contacts = []
        self._page_fx = AnalyticsPage(cv, Look(C), self, {"msgs": msgs, "contacts": contacts})

    def show_themes_screen(self):
        self.clear_container()
        self.root.geometry("1100x740")
        self.root.minsize(900, 680)
        C = palette_for(self.current_theme)
        cv = tk.Canvas(self.container, bg=C["PAGE"], highlightthickness=0, bd=0)
        cv.pack(fill="both", expand=True)
        self._page_fx = ThemesPage(cv, Look(C), self, self.current_theme)

    def apply_theme(self, theme_name):
        self.current_theme = theme_name
        self._save_settings()
        self.show_dashboard()

    def show_settings_screen(self):
        """Settings (v11): profile, live theme previews, shortcuts, account and about (settings_fx.py)."""
        self.clear_container()
        self.root.geometry("1120x760")
        self.root.minsize(900, 660)
        look = self._look()
        cv = tk.Canvas(self.container, bg=look.page, highlightthickness=0, bd=0)
        cv.pack(fill="both", expand=True)
        cb = dict(back=self.show_dashboard, upload_dp=self._settings_upload_dp, remove_dp=self._settings_remove_dp,
                  theme=self._settings_theme, forget_user=self._settings_forget, logout=self.handle_logout)
        self._page_fx = SettingsPage(cv, look, cb, username=self.current_username,
                                     dp=self.db.get_user_dp(self.current_user_id), theme=self.current_theme,
                                     remembered=self._remembered_user())

    def _settings_upload_dp(self):
        path = filedialog.askopenfilename(title="Select profile picture",
                                          filetypes=[("Image files", "*.jpg *.png *.jpeg")])
        if path and self.db.update_user_dp(self.current_user_id, path):
            self.show_settings_screen()

    def _settings_remove_dp(self):
        if messagebox.askyesno("Remove photo", "Remove your profile picture?"):
            self.db.update_user_dp(self.current_user_id, "")
            self.show_settings_screen()

    def _settings_theme(self, name):
        if name != self.current_theme:
            self.current_theme = name
            self._save_settings()
            self.show_settings_screen()      # stay on Settings so the change is visible straight away

    def _settings_forget(self):
        self._save_settings(last_user="")
        self.show_settings_screen()

    def show_status_screen(self):
        """Status screen (v11): story list with rings + inline story viewer (status_fx.py)."""
        self.clear_container()
        self.root.geometry("1240x760")
        self.root.minsize(1050, 680)
        self.chat_mode = "status"
        self.db.cleanup_expired_statuses()
        cb = dict(back=self.show_dashboard, add=self.open_add_status_popup, mine=self.view_my_statuses,
                  user=self.view_contact_statuses, viewed=self._status_viewed, details=self._status_details,
                  delete=self._status_delete, message=self._status_message, closed=self.load_status_list)
        self.status_shell = StatusShell(self.container, self._look(), cb)
        self.status_shell.pack(fill="both", expand=True)
        self.load_status_list()

    def _status_alive(self):
        sh = getattr(self, "status_shell", None)
        try:
            return bool(sh is not None and sh.winfo_exists())
        except Exception:
            return False

    def load_status_list(self):
        if not self._status_alive():
            return
        mine_rows = self.db.get_my_statuses(self.current_user_id)
        mine = dict(name=self.current_username, dp=self.db.get_user_dp(self.current_user_id), count=len(mine_rows),
                    views=sum((r[9] or 0) for r in mine_rows), latest=mine_rows[0][7] if mine_rows else "")
        others = [dict(id=uid, name=uname, dp=dp or "", count=cnt, latest=latest or "", unviewed=unviewed or 0)
                  for uid, uname, dp, cnt, latest, unviewed in self.db.get_users_with_statuses(self.current_user_id)]
        self.status_shell.set_data(mine, others)

    def _story_dicts(self, rows, own):
        out = []
        for r in rows:
            if own:
                sid, uid, stype, content, fpath, bg, fs, created, expires, views = r
                out.append(dict(id=sid, uid=uid, own=True, type=stype, content=content, path=fpath, bg=bg, size=fs,
                                created=created, name="My status", dp=self.db.get_user_dp(uid), views=views, viewed=True))
            else:
                sid, uid, uname, dp, stype, content, fpath, bg, fs, created, viewed = r
                out.append(dict(id=sid, uid=uid, own=False, type=stype, content=content, path=fpath, bg=bg, size=fs,
                                created=created, name=uname, dp=dp, views=0, viewed=bool(viewed)))
        out.sort(key=lambda d: str(d["created"]))
        return out

    def open_add_status_popup(self):
        AddStatusPopup(self.root, self.handle_post_status)

    def handle_post_status(self, content, status_type, file_path, bg_color, font_size):
        sid = self.db.post_status(self.current_user_id, content=content, status_type=status_type,
                                  file_path=file_path, bg_color=bg_color, font_size=font_size)
        if sid:
            self.load_status_list()
            self.view_my_statuses(start="last")   # show the new status right away
        else:
            messagebox.showerror("Error", "Could not post your status. Please try again.")

    def view_my_statuses(self, my_statuses=None, start="first"):
        if not self._status_alive():
            return
        rows = self.db.get_my_statuses(self.current_user_id)
        if not rows:
            self.open_add_status_popup()
            return
        stories = self._story_dicts(rows, own=True)
        self.status_shell.open_stories(stories, len(stories) - 1 if start == "last" else 0, "mine")

    def view_contact_statuses(self, user_id, username):
        if not self._status_alive():
            return
        rows = [r for r in self.db.get_contacts_statuses(self.current_user_id) if r[1] == user_id]
        if not rows:
            self.load_status_list()
            return
        stories = self._story_dicts(rows, own=False)
        start = next((i for i, st in enumerate(stories) if not st["viewed"]), 0)
        self.status_shell.open_stories(stories, start, user_id)

    def _status_viewed(self, status_id):
        self.db.mark_status_viewed(status_id, self.current_user_id)
        self.root.after(250, self.load_status_list)

    def _status_details(self, status_id):
        pane = self.status_shell.pane
        pane.paused = True
        pop = StatusViewDetailsPopup(self.root, self.db.get_status_view_details(status_id))
        pop.bind("<Destroy>", lambda e: setattr(pane, "paused", False) if e.widget is pop else None)

    def _status_delete(self, status_id):
        pane = self.status_shell.pane
        pane.paused = True
        if messagebox.askyesno("Delete status", "Delete this status update?"):
            if self.db.delete_status(status_id, self.current_user_id):
                keep = pane.idx
                rows = self.db.get_my_statuses(self.current_user_id)
                self.load_status_list()
                if rows:
                    stories = self._story_dicts(rows, own=True)
                    self.status_shell.open_stories(stories, min(keep, len(stories) - 1), "mine")
                else:
                    self.status_shell.pane.show_empty()
                    self.status_shell.rows.sel = None
                    self.load_status_list()
                return
        pane.paused = False

    def _status_message(self, user_id, username):
        self._open_chat_with(user_id, username)

    # ==================== GROUP SCREENS ====================

    def show_groups_screen(self):
        """Groups screen (v11): same chat engine as private chats, with group avatars and member info."""
        self.clear_container()
        self.root.geometry("1240x760")
        self.root.minsize(1050, 680)
        self.chat_mode = "group"
        self.selected_group_id = None
        self.selected_group_name = None
        self.last_data_check = ""
        self._group_searching = False
        self._group_cache = {}
        self._group_tick = 0
        cb = dict(
            back=self.show_dashboard, select=self.load_group_chat, search=self.handle_group_message_search,
            send=self.handle_group_send, attach=self.handle_group_image_upload, emoji=self.show_emoji_picker,
            compose=self.open_create_group_popup, delete=self.handle_group_delete_message)
        empty = dict(
            title="Teams, friends and family in one place",
            sub="Open a group on the left, or tap + to create a new one and invite people.",
            feats=[("＋", "Create groups", "Add people in seconds"), ("▣", "Share photos", "Images inside groups"),
                   ("⌕", "Search history", "Find any message fast")],
            icon="people")
        self.shell = ChatShell(self.container, self._look(), cb, list_title="Groups", empty=empty,
                              search_hint="Search groups…")
        self.shell.pack(fill="both", expand=True)
        self.load_groups_list()
        self.start_polling()

    def _group_preview(self, gid, nmembers):
        """(timestamp, preview, time label) for a group's last message; cached for a few polls."""
        c = self._group_cache.get(gid)
        if c and (self._group_tick % 5):
            return c
        ts, prev, label = "", "", ""
        try:
            hist = self.db.get_group_messages(gid)
            if hist:
                sender_id, sender_name, text, t_, mid, mtype, fpath, starred = hist[-1]
                body = "📷 Photo" if mtype == "image" else str(text or "")
                prev = ("You: " if sender_id == self.current_user_id else f"{sender_name}: ") + body
                ts = str(t_)
                t = datetime.strptime(ts[:19], "%Y-%m-%d %H:%M:%S")
                now = datetime.now()
                if t.date() == now.date():
                    label = t.strftime("%I:%M %p").lstrip("0")
                elif t.date() == (now - timedelta(days=1)).date():
                    label = "Yesterday"
                else:
                    label = t.strftime("%d %b")
        except Exception:
            pass
        self._group_cache[gid] = (ts, prev, label)
        return ts, prev, label

    def load_groups_list(self):
        if not self._group_active():
            return
        self._group_tick += 1
        rows = []
        for gid, gname, created_by, created_at, member_count in self.db.get_user_groups(self.current_user_id):
            ts, prev, label = self._group_preview(gid, member_count)
            rows.append(dict(id=gid, name=gname, icon="people", online=None, unread=0, preview=prev, time=label,
                             ts=ts or "", created=str(created_at or ""),
                             empty="%d member%s" % (member_count, "" if member_count == 1 else "s")))
        rows.sort(key=lambda r: (r["ts"] or r["created"]), reverse=True)
        self.shell.set_contacts(rows, self.selected_group_id)

    def open_create_group_popup(self):
        all_users = self.db.get_users_list(self.current_user_id)
        CreateGroupPopup(self.root, all_users, self.current_user_id, self.handle_create_group)

    def handle_create_group(self, group_name, member_ids):
        gid = self.db.create_group(group_name, self.current_user_id, member_ids)
        if gid:
            if self._group_active():
                self._group_cache.pop(gid, None)
                self.load_groups_list()
                self.load_group_chat(gid, group_name)
        else:
            messagebox.showerror("Error", "Could not create the group. Please try again.")

    def _group_header_status(self):
        if not (self._group_active() and self.selected_group_id):
            return
        members = self.db.get_group_members(self.selected_group_id)
        online = sum(1 for m in members if m[3])
        txt = "%d member%s" % (len(members), "" if len(members) == 1 else "s")
        if online:
            txt += "  ·  %d online" % online
        self.shell.set_status(txt, "muted", None)

    def load_group_chat(self, group_id, group_name):
        if not self._group_active():
            return
        self.selected_group_id = group_id
        self.selected_group_name = group_name
        self.chat_mode = "group"
        self._group_searching = False
        is_admin = self.db.is_group_admin(group_id, self.current_user_id)
        menu = [("ℹ   Group info & members", lambda: self.open_group_info(group_id, group_name))]
        if not is_admin:
            menu += [("-", None), ("🚪   Leave group", lambda: self.handle_leave_group(group_id, group_name))]
        self.shell.open_conversation(group_name, "", "muted", None, None, key=group_id, menu=menu, icon="people")
        self._group_header_status()
        self.last_data_check = ""
        self.refresh_group_messages(force=True)
        self.load_groups_list()
        self.shell.composer.focus()

    def handle_leave_group(self, group_id, group_name):
        if messagebox.askyesno("Leave group", f"Leave '{group_name}'? You will stop receiving its messages."):
            if self.db.remove_group_member(group_id, self.current_user_id):
                self.show_groups_screen()

    def handle_group_send(self):
        if not self._group_active() or not self.selected_group_id:
            return
        comp = self.shell.composer
        text = comp.get().strip()
        if text and self.db.send_group_message(self.selected_group_id, self.current_user_id, text):
            comp.clear()
            self.refresh_group_messages(force=True)

    def handle_group_image_upload(self):
        if not self._group_active() or not self.selected_group_id:
            return
        f = filedialog.askopenfilename(filetypes=[("Images", "*.jpg *.jpeg *.png")])
        if f and self.db.send_group_message(self.selected_group_id, self.current_user_id, "[Image]",
                                            msg_type="image", file_path=f):
            self.refresh_group_messages(force=True)

    def _group_msg_dicts(self, rows):
        out = []
        for sender_id, sender_name, text, ts, mid, mtype, fpath, starred in rows:
            try:
                display_time = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").strftime("%I:%M %p").lstrip("0")
            except Exception:
                display_time = ts
            own = (sender_id == self.current_user_id)
            out.append(dict(id=mid, own=own, text=text, time=display_time, status="sent", type=mtype, path=fpath,
                            starred=bool(starred), edited=False, date=self.get_date_label(ts),
                            sender_key=sender_id, sender_name=None if own else sender_name, can_delete=own))
        return out

    def refresh_group_messages(self, force=True):
        if not self.selected_group_id or not self._group_active():
            return
        if getattr(self, "_group_searching", False) and not force:
            return
        history = self.db.get_group_messages(self.selected_group_id)
        sig = str(history)
        if not force and self.last_data_check == sig:
            return
        first = (self.last_data_check == "")
        self.last_data_check = sig
        self.shell.show_messages(self._group_msg_dicts(history), stick="bottom" if (force or first) else "keep",
                                 info="" if history else "No messages yet. Start the conversation 👋")
        if force:
            self._group_cache.pop(self.selected_group_id, None)
            self.load_groups_list()

    def handle_group_delete_message(self, msg_id):
        if messagebox.askyesno("Delete message", "Delete this message for everyone in the group?"):
            if self.db.delete_group_message(msg_id):
                self.refresh_group_messages(force=True)

    def handle_group_message_search(self, keyword):
        if not self._group_active() or not self.selected_group_id:
            return
        if not keyword.strip():
            self._group_searching = False
            self.last_data_check = ""
            self.refresh_group_messages(force=True)
            return
        self._group_searching = True
        results = self.db.search_group_messages(self.selected_group_id, keyword)
        self.shell.show_messages(self._group_msg_dicts(results), stick="top",
                                 info="" if results else "No messages found matching your search.")

    def open_group_info(self, group_id, group_name):
        members = self.db.get_group_members(group_id)
        is_admin = self.db.is_group_admin(group_id, self.current_user_id)
        all_users = self.db.get_users_list(self.current_user_id)
        GroupMembersPopup(
            self.root, group_id, group_name, members, is_admin, all_users,
            self.current_user_id,
            add_member_callback=self.handle_add_member,
            remove_member_callback=self.handle_remove_member
        )

    def handle_add_member(self, group_id, user_id, popup):
        if self.db.add_group_member(group_id, user_id):
            popup.destroy()
            self._group_cache.pop(group_id, None)
            self._group_header_status()
            self.load_groups_list()
            self.open_group_info(group_id, self.selected_group_name)
        else:
            messagebox.showerror("Error", "Could not add this member.", parent=popup)

    def handle_remove_member(self, group_id, user_id, username, popup):
        if messagebox.askyesno("Remove member", f"Remove {username} from this group?", parent=popup):
            if self.db.remove_group_member(group_id, user_id):
                popup.destroy()
                self._group_cache.pop(group_id, None)
                self._group_header_status()
                self.load_groups_list()
                self.open_group_info(group_id, self.selected_group_name)

    # ==================== PRIVATE CHAT FUNCTIONS ====================

    def show_chat_screen(self):
        """Messages screen (v11): conversation list + chat, drawn by chat_fx.ChatShell."""
        self.clear_container()
        self.root.geometry("1240x760")
        self.root.minsize(1050, 680)
        self.chat_mode = "private"
        self.selected_recipient_id = None
        self.last_data_check = ""
        self._searching = False
        self._preview_cache = {}
        self._preview_tick = 0
        cb = dict(
            back=self.show_dashboard, select=self.load_user_chat, search=self.handle_message_search,
            send=self.handle_send, attach=self.handle_image_upload, emoji=self.show_emoji_picker,
            typing=self.handle_user_typing, cancel_banner=self._cancel_banner,
            reply=self.handle_reply_click, edit=self.handle_edit_click, star=self.handle_star_toggle,
            delete=self.handle_delete_message)
        self.shell = ChatShell(self.container, self._look(), cb)
        self.shell.pack(fill="both", expand=True)
        self.display_contacts(self.db.get_users_list(self.current_user_id))
        self.start_polling()

    def load_user_chat(self, recipient_id, recipient_name):
        if not self._shell_alive():
            return
        self.selected_recipient_id = recipient_id
        self.chat_mode = "private"
        self._searching = False
        self.db.mark_messages_as_seen(recipient_id, self.current_user_id)
        self.cancel_reply()
        self.cancel_edit()

        users = self.db.get_users_list(self.current_user_id)
        row = next((u for u in users if u[0] == recipient_id), None)
        dp = row[2] if row else None
        blocked = self.db.is_blocked(self.current_user_id, recipient_id)
        menu = [
            ("★   Starred messages", self.open_starred_messages),
            ("-", None),
            ("🧹   Clear chat", self.handle_clear_chat),
            (("✔   Unblock " if blocked else "⛔   Block ") + recipient_name,
             lambda: self.handle_block_toggle(recipient_id, blocked, recipient_name)),
        ]
        self.shell.open_conversation(recipient_name, "", "muted", dp, online=None, key=recipient_id, menu=menu)
        self._refresh_header_status()
        self.last_data_check = ""
        self.refresh_messages(force=True)
        self.display_contacts(users)
        self.shell.composer.focus()

    def _friendly_seen(self, ls):
        try:
            t = datetime.strptime(str(ls)[:19], "%Y-%m-%d %H:%M:%S")
        except Exception:
            return "Offline"
        now = datetime.now()
        if t.date() == now.date():
            return "Last seen today at " + t.strftime("%I:%M %p").lstrip("0")
        if t.date() == (now - timedelta(days=1)).date():
            return "Last seen yesterday at " + t.strftime("%I:%M %p").lstrip("0")
        return "Last seen " + t.strftime("%d %b")

    def _refresh_header_status(self):
        if not (self._private_active() and self.selected_recipient_id):
            return
        online, last_seen, typing = self.db.get_user_status(self.selected_recipient_id)
        if typing:
            self.shell.set_status("typing…", "typing", True)
        elif online:
            self.shell.set_status("Online", "online", True)
        else:
            self.shell.set_status(self._friendly_seen(last_seen), "muted", False)

    def _msg_dicts(self, rows):
        out = []
        for row in rows:
            # 10 columns: sender_id, text, ts, msg_id, status, mtype, fpath, is_starred, reply_to, is_edited
            sender_id, text, ts, mid, status, mtype, fpath, is_starred, reply_to, is_edited = row
            try:
                display_time = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").strftime("%I:%M %p").lstrip("0")
            except Exception:
                display_time = ts
            reply_text = reply_sender = None
            if reply_to:
                rr = self.db.get_message_by_id(reply_to)
                if rr:
                    _, _, reply_text, reply_sender = rr
            out.append(dict(
                id=mid, own=(sender_id == self.current_user_id), text=text, time=display_time, status=status,
                type=mtype, path=fpath, starred=bool(is_starred), edited=bool(is_edited), reply_text=reply_text,
                reply_sender=reply_sender, reply_to=reply_to, date=self.get_date_label(ts), sender_key=sender_id))
        return out

    def handle_message_search(self, keyword):
        if not self._private_active() or not self.selected_recipient_id:
            return
        if not keyword.strip():
            self._searching = False
            self.last_data_check = ""
            self.refresh_messages(force=True)
            return
        self._searching = True
        results = self.db.search_messages(self.current_user_id, self.selected_recipient_id, keyword)
        self.shell.show_messages(self._msg_dicts(results), stick="top",
                                 info="" if results else "No messages found matching your search.")

    def refresh_messages(self, force=True):
        if not self.selected_recipient_id or not self._private_active():
            return
        if self._searching and not force:
            return
        if not force:
            self.db.mark_messages_as_seen(self.selected_recipient_id, self.current_user_id)
        history = self.db.get_chat_history(self.current_user_id, self.selected_recipient_id)
        sig = str(history)
        if not force and self.last_data_check == sig:
            return
        first = (self.last_data_check == "")
        self.last_data_check = sig
        self.shell.show_messages(self._msg_dicts(history), stick="bottom" if (force or first) else "keep",
                                 info="" if history else "No messages yet. Say hello 👋")
        if force:
            self._preview_cache.pop(self.selected_recipient_id, None)
            self.display_contacts(self.db.get_users_list(self.current_user_id))

    def handle_delete_message(self, message_id):
        if messagebox.askyesno("Delete message", "Delete this message?"):
            if self.db.delete_single_message(message_id):
                self.refresh_messages(force=True)

    def handle_clear_chat(self):
        if messagebox.askyesno("Clear chat", "Delete the entire chat history with this contact?"):
            if self.db.clear_full_chat(self.current_user_id, self.selected_recipient_id):
                self.refresh_messages(force=True)

    def handle_send(self):
        if not self._private_active():
            return
        comp = self.shell.composer
        text = comp.get().strip()
        if not text or not self.selected_recipient_id:
            return

        # ---- EDIT MODE: updates the existing message instead of creating a new one ----
        if self.edit_target_id:
            if self.db.edit_message(self.edit_target_id, text, self.current_user_id):
                self.cancel_edit()
                self.refresh_messages(force=True)
            else:
                messagebox.showerror("Error", "Could not edit this message.")
            return

        # ---- NORMAL SEND / REPLY MODE ----
        result = self.db.save_message(self.current_user_id, self.selected_recipient_id, text,
                                      reply_to=self.reply_target_id)
        if result == "blocked_by_me":
            messagebox.showwarning("Contact blocked", "You blocked this contact. Unblock them to send messages.")
        else:
            self.db.update_typing_status(self.current_user_id, 0)
            comp.clear()
            self.cancel_reply()
            self.refresh_messages(force=True)

    def show_emoji_picker(self):
        if self._shell_alive():
            EmojiPicker(self.root, lambda e: self.shell.composer.insert(e))
        else:
            EmojiPicker(self.root, lambda e: self.msg_entry.insert_text(e))

    def poll_for_messages(self):
        if self.polling_active and self.current_user_id:
            try: 
                self.db.update_last_seen(self.current_user_id)

                # Secret Delivery Scheduler — every 1 second
                # Due scheduled messages automatic ga normal chat lo deliver avutayi
                try:
                    delivered = self.db.deliver_due_messages(self.current_user_id)
                    if delivered and self.chat_mode == "private" and self.selected_recipient_id:
                        self.refresh_messages(force=True)
                except Exception:
                    pass
                
                if self.chat_mode == "private" and self.selected_recipient_id:
                    self._refresh_header_status()
                    self.refresh_messages(force=False)
                    self.display_contacts(self.db.get_users_list(self.current_user_id))

                elif self.chat_mode == "group" and self._shell_alive():
                    if self.selected_group_id:
                        self.refresh_group_messages(force=False)
                        self._group_header_status()
                    self.load_groups_list()
                
            except Exception as e: 
                print(f"Polling error: {e}")
                
            # 1 second — second-level accuracy for capsule delivery
            self.root.after(1000, self.poll_for_messages)

    def start_polling(self):
        if not self.polling_active:
            self.polling_active = True
            self.poll_for_messages()

    def handle_block_toggle(self, rid, blocked, name):
        action = "Unblock" if blocked else "Block"
        if messagebox.askyesno("Confirm", f"{action} {name}?"):
            if blocked:
                self.db.unblock_user(self.current_user_id, rid)
            else:
                self.db.block_user(self.current_user_id, rid)
            self.last_data_check = ""
            self.load_user_chat(rid, name)

    def handle_image_upload(self):
        if not self.selected_recipient_id:
            return
        f = filedialog.askopenfilename(filetypes=[("Images", "*.jpg *.jpeg *.png")])
        if f:
            result = self.db.save_message(self.current_user_id, self.selected_recipient_id, "[Image]",
                                          msg_type='image', file_path=f)
            if result == "blocked_by_me":
                messagebox.showwarning("Contact blocked", "You blocked this contact. Unblock them to send images.")
            else:
                self.refresh_messages(force=True)

    def filter_contacts(self, q):
        query = q.lower().strip()
        for widget in self.contacts_list_frame.winfo_children():
            if hasattr(widget, 'name'):
                if query in widget.name.lower() or query == "":
                    widget.pack(fill="x", side="top")
                else:
                    widget.pack_forget()

    def _preview_for(self, uid, unread):
        """(timestamp, preview text, time label) of the last message with a contact; cached."""
        c = self._preview_cache.get(uid)
        if c and c[3] == unread and (self._preview_tick % 5):
            return c[:3]
        ts, prev, label = "", "", ""
        try:
            hist = self.db.get_chat_history(self.current_user_id, uid)
            if hist:
                last = hist[-1]
                ts = str(last[2])
                body = "📷 Photo" if last[5] == "image" else str(last[1] or "")
                prev = ("You: " if last[0] == self.current_user_id else "") + body
                t = datetime.strptime(ts[:19], "%Y-%m-%d %H:%M:%S")
                now = datetime.now()
                if t.date() == now.date():
                    label = t.strftime("%I:%M %p").lstrip("0")
                elif t.date() == (now - timedelta(days=1)).date():
                    label = "Yesterday"
                else:
                    label = t.strftime("%d %b")
        except Exception:
            pass
        self._preview_cache[uid] = (ts, prev, label, unread)
        return ts, prev, label

    def display_contacts(self, users):
        if not self._private_active():
            return
        self._preview_tick += 1
        unread_map = self.db.get_all_unread_counts(self.current_user_id)
        rows = []
        for uid, name, dp, is_online, last_seen in users:
            unread = unread_map.get(uid, 0)
            ts, prev, label = self._preview_for(uid, unread)
            rows.append(dict(id=uid, name=name, dp=dp, online=bool(is_online), unread=unread, preview=prev,
                             time=label, ts=ts))
        rows.sort(key=lambda r: (r["ts"] == "", [-ord(c) for c in r["ts"]] if r["ts"] else r["name"].lower()))
        self.shell.set_contacts(rows, self.selected_recipient_id)

    def handle_user_typing(self):
        try:
            self.db.update_typing_status(self.current_user_id, 1)
            if self.typing_timer: self.root.after_cancel(self.typing_timer)
            self.typing_timer = self.root.after(3000, lambda: self.db.update_typing_status(self.current_user_id, 0))
        except: pass

    def get_date_label(self, ds):
        try:
            d = datetime.strptime(ds.split()[0], "%Y-%m-%d").date()
            if d == datetime.now().date(): return "Today"
            if d == (datetime.now() - timedelta(days=1)).date(): return "Yesterday"
            return d.strftime("%B %d, %Y")
        except: return None

    def _auth_login(self, username, password, remember=False):
        """Called by the sign-in card. Returns None on success or an error message."""
        uid = self.db.login_user(username, password)
        if not uid:
            return "Incorrect username or password."
        self._save_settings(last_user=username if remember else "")
        self.current_user_id, self.current_username = uid, username
        self.db.update_user_online_status(uid, 1)
        self.show_dashboard()
        return None

    def _auth_register(self, username, password):
        """Called by the create-account card. Returns None on success or an error message."""
        if self.db.register_user(username, password):
            return None
        return "That username is already taken. Try another one."

    def handle_login(self):
        # Kept for backwards compatibility; the v11 auth card calls _auth_login directly.
        u, p = self.auth_ui.get_data() if hasattr(self.auth_ui, "get_data") else ("", "")
        err = self._auth_login(u, p)
        if err:
            messagebox.showerror("Error", err)

    def handle_register(self):
        u, p = self.auth_ui.get_data() if hasattr(self.auth_ui, "get_data") else ("", "")
        err = self._auth_register(u, p)
        messagebox.showerror("Error", err) if err else messagebox.showinfo("Success", "Account created!")

    def handle_logout(self):
        if self.current_user_id: 
            self.db.update_user_online_status(self.current_user_id, 0)
            self.db.logout_user(self.current_user_id)
        self.current_user_id = None
        self.show_login_page()

    def show_login_page(self):
        self.clear_container()
        self.root.geometry("1120x700")
        self.root.minsize(980, 640)
        self.auth_ui = AuthScreen(self.container, self._look(),
                                  dict(login=self._auth_login, register=self._auth_register),
                                  remembered=self._remembered_user())
        self.auth_ui.pack(expand=True, fill="both")
        self.root.after(250, self.auth_ui.focus_first)

if __name__ == "__main__":
    root = tk.Tk()
    app = MainApp(root)
    root.mainloop()
