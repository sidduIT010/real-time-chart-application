"""
NexaChat authentication screen (v11)
====================================
    AuthScreen   animated brand hero (left) + sign-in / create-account card (right)
    AuthCard     the Canvas page that draws the card (tabs, fields, strength meter, errors)

UI only: the application passes two callbacks that talk to the database.

    login(username, password, remember)  -> None on success, or an error message (str)
    register(username, password)         -> None on success, or an error message (str)
"""
import math
import re
import tkinter as tk

from fx import AuthHero, hex_rgb, mix
from fxkit import FONT, card_image, pill_image
from ui_components import get_icon
from chat_fx import Base, chat_bg, make_entry, font, KNOWN_ICONS

USER_RE = re.compile(r"^[A-Za-z0-9_.]{3,20}$")


def password_score(p):
    """0 (empty) .. 4 (strong)."""
    if not p:
        return 0
    score = 0
    if len(p) >= 6:
        score += 1
    if len(p) >= 10:
        score += 1
    if re.search(r"[a-z]", p) and re.search(r"[A-Z]", p):
        score += 1
    if re.search(r"\d", p) and re.search(r"[^A-Za-z0-9]", p):
        score += 1
    return max(1, min(4, score))


class AuthCard(Base):
    min_w, min_h = 300, 300

    def __init__(self, cv, look, cb, remembered=""):
        super().__init__(cv, look)
        self.cb = cb
        self.mode = "login"
        self.error, self.notice = "", ""
        self.busy = False
        self.show_pw = False
        self.remember = bool(remembered)
        self.caps = False
        self.focus = None
        self.rings = {}
        self._slide_from = None
        self._score = 0
        self._shake_last = 0.0

        fbg = mix(look.card_bot, look.a1, 0.06 if not look.dark else 0.12)
        self.fbg = fbg
        self.ue, self.pe, self.ce = (make_entry(cv, look, 11) for _ in range(3))
        for e in (self.ue, self.pe, self.ce):
            e.config(bg=fbg, disabledbackground=fbg)
        self.pe.config(show="•")
        self.ce.config(show="•")
        self.ue.insert(0, remembered)
        for name, e in (("user", self.ue), ("pass", self.pe), ("conf", self.ce)):
            e.bind("<FocusIn>", lambda ev, n=name: self._focus(n), add="+")
            e.bind("<FocusOut>", lambda ev, n=name: self._focus(None), add="+")
            e.bind("<Return>", lambda ev: self.submit(), add="+")
            e.bind("<KeyRelease>", self._key, add="+")
            e.bind("<KeyPress>", self._press, add="+")
        cv.bind("<MouseWheel>", lambda e: cv.yview_scroll(-1 if e.delta > 0 else 1, "units"), add="+")

    # ------------------------------------------------------------ state
    def set_mode(self, mode):
        if mode == self.mode or self.busy:
            return
        self._slide_from = self.mode
        self.mode = mode
        self.error = ""
        self.notice = ""
        self.pe.delete(0, tk.END)
        self.ce.delete(0, tk.END)
        self._score = 0
        self.refresh()
        self.cv.after(60, lambda: (self.ue if not self.ue.get() else self.pe).focus_set())

    def _focus(self, name):
        self.focus = name
        for n, (base, glow) in list(self.rings.items()):
            try:
                self.cv.itemconfigure(base, state="hidden" if n == name else "normal")
                self.cv.itemconfigure(glow, state="normal" if n == name else "hidden")
            except tk.TclError:
                pass

    def _press(self, e):
        """Caps Lock hint: an upper-case letter without Shift (or lower-case with Shift) means Caps Lock is on."""
        if e.widget is not self.pe or len(e.keysym) != 1 or not e.keysym.isalpha():
            return
        shift = bool(e.state & 0x1)
        upper = e.keysym.isupper()
        on = (upper and not shift) or (not upper and shift)
        if on != self.caps:
            self.caps = on
            self.refresh()

    def _key(self, e):
        if self.error or self.notice:
            self.error = self.notice = ""
            self.refresh()
            return
        if self.mode == "register" and e.widget is self.pe:
            sc = password_score(self.pe.get())
            if sc != self._score:
                self._score = sc
                self.refresh()

    def set_notice(self, text):
        self.notice, self.error = text, ""
        self.refresh()

    def set_error(self, text):
        self.error, self.notice = text, ""
        self.busy = False
        self.refresh()
        self.cv.after(20, self._shake)

    def _shake(self):
        self._shake_last = 0.0

        def upd(p):
            off = math.sin(p * math.pi * 7) * (1 - p) * 11
            try:
                self.cv.move("cardg", off - self._shake_last, 0)
            except tk.TclError:
                return
            self._shake_last = off
        self.sc.tween(0.5, upd, ease=lambda p: p)

    # ------------------------------------------------------------ actions
    def submit(self):
        if self.busy:
            return
        u, p = self.ue.get().strip(), self.pe.get()
        if self.mode == "login":
            if not u or not p:
                return self.set_error("Enter your username and password.")
            self._run(lambda: self.cb["login"](u, p, self.remember), "login")
        else:
            if not USER_RE.match(u):
                return self.set_error("Username: 3–20 letters, numbers, dot or underscore.")
            if len(p) < 6:
                return self.set_error("Password must be at least 6 characters.")
            if p != self.ce.get():
                return self.set_error("The two passwords don't match.")
            self._run(lambda: self.cb["register"](u, p), "register")

    def _run(self, fn, kind):
        self.busy = True
        self.error = self.notice = ""
        self.refresh()

        def go():
            try:
                err = fn()
            except Exception as ex:  # never leave the button stuck
                err = "Something went wrong: %s" % ex
            if not self.cv.winfo_exists():
                return
            if err:
                self.set_error(err)
            elif kind == "register":
                u = self.ue.get().strip()
                self.busy = False
                self.mode, self._slide_from = "login", "register"
                self.pe.delete(0, tk.END)
                self.ce.delete(0, tk.END)
                self.ue.delete(0, tk.END)
                self.ue.insert(0, u)
                self.notice = "Account created! Sign in to continue."
                self.refresh()
                self.cv.after(60, self.pe.focus_set)
        self.cv.after(380, go)

    def toggle_remember(self):
        self.remember = not self.remember
        self.refresh()

    def toggle_pw(self):
        self.show_pw = not self.show_pw
        ch = "" if self.show_pw else "•"
        self.pe.config(show=ch)
        self.ce.config(show=ch)
        self.refresh()

    # ------------------------------------------------------------ drawing
    def _field(self, x, y, w, label, entry, name, icon, toggle=False):
        L, cv = self.look, self.cv
        self.t(x + 4, y, label, size=8, weight="bold", fill=L.muted)
        fy, h = y + 20, 46
        base, m = card_image(w, h, 15, self.fbg, self.fbg, L.line, (0, 0, 0, 0))
        glow, m2 = card_image(w, h, 15, self.fbg, self.fbg, mix(L.line, L.a1, 0.9), (0, 0, 0, 0), glow=L.a1)
        b = self.img(x - m, fy - m, base, "nw", state="hidden" if self.focus == name else "normal")
        g = self.img(x - m2, fy - m2, glow, "nw", state="normal" if self.focus == name else "hidden")
        self.rings[name] = (b, g)
        if icon in KNOWN_ICONS:
            self.img(x + 24, fy + h / 2.0, get_icon(icon, 17, L.muted))
        else:
            self.t(x + 24, fy + h / 2.0, icon, size=11, fill=L.muted, anchor="center")
        right = 78 if toggle else 18
        cv.create_window(x + 46, fy + h / 2.0, window=entry, anchor="w", width=w - 46 - right, height=26)
        if toggle:
            tx = x + w - 40
            lab = "Hide" if self.show_pw else "Show"
            cv.create_rectangle(tx - 26, fy + 11, tx + 26, fy + h - 11, fill=mix(self.fbg, L.a1, 0.14), outline="")
            self.t(tx, fy + h / 2.0, lab, size=8, weight="bold", fill=L.a1b, anchor="center")
            self.hit((tx - 26, fy + 8, tx + 26, fy + h - 8), self.toggle_pw)
        return fy + h

    def build(self, W, H):
        L, cv = self.look, self.cv
        self.rings = {}
        reg = self.mode == "register"
        cw = int(min(450, W - 48))
        iw = cw - 68
        banner = 46 if (self.error or self.notice) else 0
        fields = 3 if reg else 2
        ch = 30 + 46 + 26 + 38 + 28 + 18 + fields * 80 + (36 if reg else 40) + banner + 54 + 24 + 30 + 28
        needed = ch + 90
        self.scroll_h = max(H, needed)
        cv.configure(scrollregion=(0, 0, W, self.scroll_h))
        H2 = self.scroll_h
        cv.create_image(0, 0, image=self._bgimg(W, H2), anchor="nw")
        x = (W - cw) / 2.0
        y = max(30, (H2 - ch - 30) / 2.0)
        mark = self.sc.mark()

        im, m = card_image(cw, ch, 28, L.card_top, L.card_bot, L.line, L.shadow)
        self.img(x - m, y - m, im, "nw")
        ix = x + 34
        cy = y + 30

        # ---- tabs
        th = 46
        track, tm = card_image(iw, th, 23, L.soft, L.soft, L.line, (0, 0, 0, 0))
        self.img(ix - tm, cy - tm, track, "nw")
        half = iw / 2.0
        pill, pm = pill_image(half - 6, th - 8, 19, L.p1, L.a2, glow=L.a1b, glow_a=90)
        tx = ix + 3 + (half if reg else 0)
        pid = self.img(tx - pm, cy + 4 - pm, pill, "nw")
        if self._slide_from and self._slide_from != self.mode:
            fx = ix + 3 + (half if self._slide_from == "register" else 0)
            self.sc.tween(0.32, lambda p, a=fx, b=tx: cv.coords(pid, (a + (b - a) * p) - pm, cy + 4 - pm))
        self._slide_from = None
        for i, (lab, md) in enumerate((("Sign in", "login"), ("Create account", "register"))):
            on = self.mode == md
            self.t(ix + half * i + half / 2.0, cy + th / 2.0, lab, size=10, weight="bold",
                   fill="#FFFFFF" if on else L.muted, anchor="center")
            self.hit((ix + half * i, cy, ix + half * (i + 1), cy + th), lambda md=md: self.set_mode(md))
        cy += th + 26

        # ---- heading
        self.t(ix + 2, cy, "Create your account" if reg else "Welcome back", size=21, weight="bold")
        cy += 38
        self.t(ix + 2, cy, "Join NexaChat in a few seconds." if reg else "Sign in to continue your conversations.",
               size=10, fill=L.muted)
        cy += 28 + 18

        # ---- fields
        self._field(ix, cy, iw, "USERNAME", self.ue, "user", "user")
        cy += 80
        self._field(ix, cy, iw, "PASSWORD", self.pe, "pass", "shield", toggle=True)
        cy += 80
        if reg:
            self._field(ix, cy, iw, "CONFIRM PASSWORD", self.ce, "conf", "check", toggle=False)
            cy += 80

        # ---- extras row
        if reg:
            sc_ = password_score(self.pe.get())
            cols = [L.red, "#F59E0B", L.a3, L.green]
            labels = ["", "Weak", "Fair", "Good", "Strong"]
            sw = (iw - 150) / 4.0
            for i in range(4):
                on = i < sc_
                cv.create_rectangle(ix + 4 + i * (sw + 6), cy + 4, ix + 4 + i * (sw + 6) + sw, cy + 9,
                                    fill=cols[sc_ - 1] if on else L.line, outline="")
            hint = labels[sc_] if sc_ else "Use 6+ characters"
            self.t(ix + iw - 2, cy + 7, hint, size=8, weight="bold", fill=cols[sc_ - 1] if sc_ else L.muted, anchor="e")
            cy += 36
        else:
            box = 18
            cv.create_rectangle(ix + 4, cy + 3, ix + 4 + box, cy + 3 + box, outline=L.a1b if self.remember else L.muted,
                                fill=L.a1b if self.remember else "", width=2)
            if self.remember:
                self.t(ix + 4 + box / 2.0, cy + 3 + box / 2.0, "✓", size=9, weight="bold", fill="#FFFFFF", anchor="center")
            self.t(ix + 32, cy + 12, "Remember me", size=9, fill=L.muted, anchor="w")
            self.hit((ix, cy, ix + 140, cy + 26), self.toggle_remember)
            if self.caps and self.focus == "pass":
                self.t(ix + iw - 2, cy + 12, "⇪ Caps Lock is on", size=9, weight="bold", fill="#F59E0B", anchor="e")
            cy += 40

        # ---- banner (error / notice)
        if banner:
            col = L.red if self.error else L.green
            bg = mix(L.card_bot, col, 0.13)
            cv.create_rectangle(ix, cy, ix + iw, cy + 38, fill=bg, outline="")
            cv.create_rectangle(ix, cy, ix + 4, cy + 38, fill=col, outline="")
            self.t(ix + 16, cy + 19, ("⚠  " if self.error else "✓  ") + (self.error or self.notice), size=9,
                   weight="bold", fill=col, anchor="w")
            cy += banner

        # ---- primary button
        bh = 50
        label = ("Signing in…" if not reg else "Creating account…") if self.busy else ("Sign in" if not reg else "Create account")
        c1, c2 = (mix(L.p1, L.page, 0.3), mix(L.a2, L.page, 0.3)) if self.busy else (L.p1, L.a2)
        bim, bm = pill_image(iw, bh, 25, c1, c2, glow=None if self.busy else L.a1b, glow_a=120)
        btn = self.img(ix - bm, cy - bm, bim, "nw")
        self.t(ix + iw / 2.0, cy + bh / 2.0, label, size=11, weight="bold", fill="#FFFFFF", anchor="center")
        self.hit((ix, cy, ix + iw, cy + bh), self.submit)
        cy += bh + 24

        # ---- switch link
        q = "Already have an account?  " if reg else "New to NexaChat?  "
        a = "Sign in" if reg else "Create an account"
        f1, f2 = self._f(9), self._f(9, "bold")
        total = f1.measure(q) + f2.measure(a)
        sx = x + cw / 2.0 - total / 2.0
        self.t(sx, cy, q, size=9, fill=L.muted)
        self.t(sx + f1.measure(q), cy, a, size=9, weight="bold", fill=L.a1b)
        self.hit((sx, cy - 6, sx + total, cy + 22), lambda: self.set_mode("login" if reg else "register"))

        ids = [i for i in cv.find_all() if i > mark]
        for i in ids:
            cv.addtag_withtag("cardg", i)
        self._shake_last = 0.0
        self.t(W / 2.0, y + ch + 34, "NexaChat  •  Connect · Chat · Grow", size=8, fill=L.muted, anchor="center")
        if self.first:
            self.sc.group("cardin", mark, enter=(0, 26), delay=0.05)
            self.first = False

    def _f(self, size, weight="normal"):
        return font(size, weight)

    def _bgimg(self, W, H):
        im = chat_bg(W, H, self.look)
        self.sc.keep.append(im)
        return im


class AuthScreen(tk.Frame):
    def __init__(self, parent, look, cb, remembered=""):
        super().__init__(parent, bg=look.page)
        self.look = look
        self.columnconfigure(0, weight=11, uniform="a")
        self.columnconfigure(1, weight=10, uniform="a")
        self.rowconfigure(0, weight=1)
        self.hero = AuthHero(self)
        # theme the hero gradient (the class constants are the violet default)
        self.hero.BG_TOP = hex_rgb(look.sb_top)
        self.hero.BG_BOT = hex_rgb(mix(look.sb_bot, look.sb_top, 0.25))
        self.hero.grid(row=0, column=0, sticky="nsew")
        self.cv = tk.Canvas(self, bg=look.page, highlightthickness=0, bd=0)
        self.cv.grid(row=0, column=1, sticky="nsew")
        self.card = AuthCard(self.cv, look, cb, remembered)

    def focus_first(self):
        try:
            if not self.winfo_exists():
                return
            c = self.card
            (c.ue if not c.ue.get() else c.pe).focus_set()
        except tk.TclError:
            pass

    def set_notice(self, text):
        self.card.set_notice(text)
