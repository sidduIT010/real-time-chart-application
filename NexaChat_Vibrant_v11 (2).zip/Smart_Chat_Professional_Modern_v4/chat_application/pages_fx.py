"""
NexaChat animated Analytics + Themes pages (canvas based, theme aware).
"""
import math
from datetime import datetime

from fx import mix, rr_points, clock, clamp01, ease_out_back, ease_out_cubic
from fxkit import Page, Look, FONT, pill_image, palette_for, PALETTES, THEME_DESC
from dashboard_fx import daily_counts, trend_pct, parse_ts, WEEKDAYS
from ui_components import get_icon, make_avatar


class _HeaderMixin:
    """Back button + title block shared by the full-screen pages."""

    def header(self, W, title, subtitle, back_cb):
        L, cv, sc = self.look, self.cv, self.sc
        mk = sc.mark()
        w = 150
        im, mg = pill_image(w, 36, 18, L.p1, L.a2, glow=L.a1, glow_a=90)
        imh, mgh = pill_image(w, 36, 18, L.a2, L.a1b, glow=L.a2, glow_a=170)
        b1 = self.img(26 - mg, 22 - mg, im, "nw")
        b2 = self.img(26 - mgh, 22 - mgh, imh, "nw", state="hidden")
        self.t(26 + 24, 40, "\u2190", 12, "bold", "#FFFFFF", "center")
        self.t(26 + 36, 40, "Dashboard", 9, "bold", "#FFFFFF", "w")
        self.grp("hdr_back", mk, (-30, 0), 0.0)

        def on():
            cv.itemconfigure(b1, state="hidden")
            cv.itemconfigure(b2, state="normal")
            sc.hover_group("hdr_back", -3, 0)

        def off():
            cv.itemconfigure(b1, state="normal")
            cv.itemconfigure(b2, state="hidden")
            sc.hover_group("hdr_back", 0, 0)
        self.hit((26, 22, 26 + w, 58), back_cb, on, off)
        mk = sc.mark()
        t1 = self.t(200, 22, title, 19, "bold", L.text)
        t2 = self.t(201, 52, subtitle, 9, "normal", L.muted)
        self.grp("hdr_title", mk, (0, -16), 0.1)


# ------------------------------------------------------------- analytics ----
class AnalyticsPage(_HeaderMixin, Page):
    min_w, min_h = 700, 480
    scroll_h = 690

    def __init__(self, cv, look, app, data):
        super().__init__(cv, look)
        self.app, self.d = app, data
        self.uid = app.current_user_id

    def build(self, W, H):
        L, cv, sc, d = self.look, self.cv, self.sc, self.d
        self.aurora(W, H, 18)
        self.header(W, "Chat Analytics", "Your conversation activity at a glance", self.app.show_dashboard)
        msgs, contacts, uid = d["msgs"], d["contacts"], self.uid
        sent = sum(1 for m in msgs if m[0] == uid)
        total, received = len(msgs), len(msgs) - sent
        m, gap = 26, 14
        mw = W - 2 * m

        # ---- metric cards
        _, s_all = daily_counts(msgs, uid, 14, "all")
        _, s_sent = daily_counts(msgs, uid, 14, "sent")
        _, s_rec = daily_counts(msgs, uid, 14, "received")
        s_con = [(c[2] or 0) + (c[3] or 0) for c in contacts[:10]] or [0, 0, 0]
        specs = [
            ("chat", "Total Messages", total, L.a1, L.a1b, s_all, "Text messages in your chats"),
            ("send", "Messages Sent", sent, L.green, L.a3, s_sent, "Messages you sent"),
            ("arrow", "Messages Received", received, L.a2, L.pink, s_rec, "Messages from contacts"),
            ("people", "Active Contacts", len(contacts), "#F59E0B", "#EF4444", s_con, "People you've chatted with"),
        ]
        cw = (mw - 3 * gap) / 4.0
        mh = 100
        for i, (icon, title, val, c1, c2, series, sub) in enumerate(specs):
            x, y, tag = m + i * (cw + gap), 80, "an_m%d" % i
            mk = sc.mark()
            ids = self.card(x, y, cw, mh, 16, glow=c1)
            cv.create_polygon(rr_points(x + 16, y + 1, x + 56, y + 5, 2), smooth=True, fill=c1, outline="")
            self.img(x + 34, y + 36, make_avatar(34, c1, c2))
            self.img(x + 34, y + 36, get_icon(icon, 16, "#FFFFFF"))
            self.t(x + 60, y + 18, title, 8, "bold", L.muted)
            n = self.t(x + 60, y + 31, "{:,}".format(val), 20, "bold", L.text)
            self.num(n, val, 0.3 + 0.1 * i)
            self.t(x + 16, y + mh - 14, sub, 8, "normal", L.muted, "w")
            self.spark(x + cw - 86, y + 14, 70, 24, series, c1, tag, delay=0.5 + 0.1 * i)
            self.grp(tag, mk, (0, 28), 0.08 + 0.08 * i)
            on, off = self.hover_card(ids, tag, -4)
            self.hit((x, y, x + cw, y + mh), None, on, off)

        # ---- activity chart + donut
        y2, h2 = 196, 238
        cw1 = int(mw * 0.64)
        self._activity(m, y2, cw1, h2, msgs)
        self._donut(m + cw1 + gap, y2, mw - cw1 - gap, h2, sent, received)

        # ---- top conversations + insights
        y3, h3 = y2 + h2 + gap, 212
        half = int((mw - gap) * 0.52)
        self._top(m, y3, half, h3, contacts)
        self._insights(m + half + gap, y3, mw - half - gap, h3, msgs, sent, received, len(contacts))

    # ---- 14 day dual line chart with hover crosshair
    def _activity(self, x, y, w, h, msgs):
        L, cv, sc = self.look, self.cv, self.sc
        days = 14
        keys, sent = daily_counts(msgs, self.uid, days, "sent")
        _, rec = daily_counts(msgs, self.uid, days, "received")
        mk = sc.mark()
        self.card(x, y, w, h, 16)
        self.t(x + 20, y + 20, "Activity \u00b7 last 14 days", 11, "bold", L.text)
        for k, (lab, col) in enumerate([("Sent", L.a1), ("Received", L.pink)]):
            lx = x + w - 20 - (k * 86)
            cv.create_oval(lx - 66, y + 24, lx - 58, y + 32, fill=col, outline="")
            self.t(lx - 52, y + 28, lab, 8, "normal", L.muted, "w")
        self.grp("an_act", mk, (0, 28), 0.34)
        px0, px1 = x + 46, x + w - 24
        py0, py1 = y + 62, y + h - 40
        vmax = max(sent + rec + [4])
        top = int(math.ceil(vmax / 4.0) * 4)
        mk = sc.mark()
        for g in range(5):
            gy = py1 - (py1 - py0) * g / 4.0
            cv.create_line(px0, gy, px1, gy, fill=L.line, dash=(2, 4))
            self.t(px0 - 10, gy, str(int(top * g / 4.0)), 7, "normal", L.muted, "e")
        step = (px1 - px0) / float(days - 1)
        for i in range(0, days, 2):
            self.t(px0 + step * i, py1 + 16, keys[i].strftime("%d %b"), 7, "normal", L.muted, "center")
        self.grp("an_grid", mk, (0, 28), 0.34)

        def pts(vals):
            return [(px0 + step * i, py1 - (py1 - py0) * (v / float(top))) for i, v in enumerate(vals)]
        for vals, col in ((rec, L.pink), (sent, L.a1)):
            p = pts(vals)
            dense_fill = mix(L.card_bot, col, 0.16 if not L.dark else 0.22)
            sc.line_chart(p, col, dense_fill, py1, width=2.6, delay=self.dur(0.7) if self.first else 0.0,
                          duration=self.dur(1.4), follow="an_grid")
        # hover crosshair + tooltip
        guide = cv.create_line(0, py0, 0, py1, fill=mix(L.line, L.a1, 0.5), width=1, state="hidden")
        dot1 = cv.create_oval(0, 0, 0, 0, fill=L.a1, outline=L.card_top, width=2, state="hidden")
        dot2 = cv.create_oval(0, 0, 0, 0, fill=L.pink, outline=L.card_top, width=2, state="hidden")
        tbg = cv.create_polygon(rr_points(0, 0, 10, 10, 6), smooth=True, fill=L.text, outline="", state="hidden")
        ttx = cv.create_text(0, 0, text="", font=(FONT, 8, "bold"), fill=L.card_top, state="hidden", justify="center")
        sp, rp = pts(sent), pts(rec)

        def move(mx, my):
            i = int(round((mx - px0) / step))
            i = max(0, min(days - 1, i))
            gx = px0 + step * i
            ox, oy = sc.off("an_grid")
            cv.coords(guide, gx + ox, py0 + oy, gx + ox, py1 + oy)
            for dot, pp in ((dot1, sp[i]), (dot2, rp[i])):
                cv.coords(dot, pp[0] - 4 + ox, pp[1] - 4 + oy, pp[0] + 4 + ox, pp[1] + 4 + oy)
                cv.itemconfigure(dot, state="normal")
            s = "%s\nSent %d \u00b7 Received %d" % (keys[i].strftime("%a, %d %b"), sent[i], rec[i])
            wd, ty = 150, py0 + 4 + oy
            tx = min(max(gx + ox, x + wd / 2 + 4), x + w - wd / 2 - 4)
            cv.coords(tbg, *rr_points(tx - wd / 2, ty, tx + wd / 2, ty + 42, 8))
            cv.coords(ttx, tx, ty + 21)
            cv.itemconfigure(ttx, text=s, state="normal")
            cv.itemconfigure(tbg, state="normal")
            cv.itemconfigure(guide, state="normal")
            for it in (tbg, ttx):
                cv.tag_raise(it)

        def leave():
            for it in (guide, dot1, dot2, tbg, ttx):
                cv.itemconfigure(it, state="hidden")
        self.hit((px0 - 8, py0 - 6, px1 + 8, py1 + 6), None, None, leave, move)

    # ---- animated donut
    def _donut(self, x, y, w, h, sent, received):
        L, cv, sc = self.look, self.cv, self.sc
        total = sent + received
        mk = sc.mark()
        self.card(x, y, w, h, 16)
        self.t(x + 20, y + 20, "Sent vs Received", 11, "bold", L.text)
        cx, cy, r = x + w / 2.0, y + 108, min(62, w / 2.0 - 30)
        wd = 16
        bb = (cx - r, cy - r, cx + r, cy + r)
        cv.create_arc(*bb, start=0, extent=359.9, style="arc", outline=L.soft, width=wd)
        a1 = cv.create_arc(*bb, start=90, extent=0.01, style="arc", outline=L.a1, width=wd)
        a2 = cv.create_arc(*bb, start=90, extent=0.01, style="arc", outline=L.pink, width=wd)
        tn = self.t(cx, cy - 8, "{:,}".format(total), 20, "bold", L.text, "center")
        self.t(cx, cy + 14, "messages", 8, "normal", L.muted, "center")
        self.num(tn, total, 0.5)
        pc_s = (sent * 100.0 / total) if total else 0
        for k, (lab, v, col, pc) in enumerate([("Sent", sent, L.a1, pc_s), ("Received", received, L.pink, 100 - pc_s if total else 0)]):
            lx = x + 24 + k * (w - 48) / 2.0
            cv.create_oval(lx, y + h - 38, lx + 9, y + h - 29, fill=col, outline="")
            self.t(lx + 15, y + h - 40, "%s  %d%%" % (lab, round(pc)), 8, "bold", L.text)
            self.t(lx + 15, y + h - 26, "{:,}".format(v), 8, "normal", L.muted)
        self.grp("an_donut", mk, (0, 28), 0.42)
        if not total:
            self.t(cx, cy + 50, "", 8)

        def sweep(p):
            ox, oy = sc.off("an_donut")
            gapd = 6 if (sent and received) else 0
            e1 = 360.0 * (sent / float(total)) if total else 0
            ext1 = max(0.01, (e1 - gapd) * p)
            ext2 = max(0.01, (360.0 - e1 - gapd) * p) if received else 0.01
            cv.coords(a1, bb[0] + ox, bb[1] + oy, bb[2] + ox, bb[3] + oy)
            cv.coords(a2, bb[0] + ox, bb[1] + oy, bb[2] + ox, bb[3] + oy)
            cv.itemconfigure(a1, start=90 - gapd / 2.0, extent=-min(359.9, ext1) if sent else 0.01)
            cv.itemconfigure(a2, start=90 - e1 - gapd / 2.0, extent=-min(359.9, ext2))
        sc.tween(self.dur(1.3), sweep, delay=0.8 if self.first else 0.0, ease=ease_out_cubic)

    # ---- top conversations: animated horizontal bars
    def _top(self, x, y, w, h, contacts):
        L, cv, sc = self.look, self.cv, self.sc
        mk = sc.mark()
        self.card(x, y, w, h, 16)
        self.t(x + 20, y + 20, "Top Conversations", 11, "bold", L.text)
        self.grp("an_top_h", mk, (0, 28), 0.5)
        rows = contacts[:4]
        if not rows:
            mk = sc.mark()
            self.t(x + w / 2, y + h / 2, "Start a conversation to see analytics here.", 9, "normal", L.muted, "center")
            self.grp("an_top_e", mk, (0, 20), 0.6)
            return
        vals = [(c[2] or 0) + (c[3] or 0) for c in rows]
        vmax = max(vals + [1])
        pal = [(L.a1b, L.a1), (L.green, L.a3), (L.a2, L.pink), ("#F59E0B", "#EF4444")]
        for i, (c, v) in enumerate(zip(rows, vals)):
            ry = y + 52 + i * 38
            tag = "an_top%d" % i
            mk = sc.mark()
            c1, c2 = pal[i % 4]
            cv.create_polygon(rr_points(x + 20, ry + 2, x + 44, ry + 26, 8), smooth=True, fill=mix(L.card_bot, c1, 0.18), outline="")
            self.t(x + 32, ry + 14, str(i + 1), 9, "bold", c1, "center")
            self.t(x + 56, ry + 6, c[1], 9, "bold", L.text)
            self.t(x + w - 20, ry + 6, "%d msgs" % v, 8, "normal", L.muted, "ne")
            bx0, bx1, by = x + 56, x + w - 20, ry + 25
            cv.create_line(bx0, by, bx1, by, fill=L.soft, width=6, capstyle="round")
            bar = cv.create_line(bx0, by, bx0 + 1, by, fill=c1, width=6, capstyle="round")
            self.grp(tag, mk, (30, 0), 0.55 + 0.08 * i)

            def grow(p, bar=bar, bx0=bx0, bx1=bx1, by=by, v=v, tag=tag):
                ox, oy = sc.off(tag)
                cv.coords(bar, bx0 + ox, by + oy, bx0 + ox + max(1.0, (bx1 - bx0) * (v / float(vmax)) * p), by + oy)
            sc.tween(self.dur(1.0), grow, delay=(1.0 + 0.1 * i) if self.first else 0.0, ease=ease_out_back)
            hov = cv.create_polygon(rr_points(x + 10, ry - 2, x + w - 10, ry + 34, 10), smooth=True,
                                    fill=mix(L.card_bot, c1, 0.07), outline="", state="hidden")
            cv.tag_lower(hov, tag)
            self.hit((x + 10, ry - 2, x + w - 10, ry + 34), None,
                     (lambda hov=hov, tag=tag: (cv.itemconfigure(hov, state="normal"), sc.hover_group(tag, 4, 0))),
                     (lambda hov=hov, tag=tag: (cv.itemconfigure(hov, state="hidden"), sc.hover_group(tag, 0, 0))))

    # ---- smart insights with typewriter text
    def _insights(self, x, y, w, h, msgs, sent, received, ncontacts):
        L, cv, sc = self.look, self.cv, self.sc
        mk = sc.mark()
        self.card(x, y, w, h, 16)
        self.t(x + 20, y + 20, "Smart Insights", 11, "bold", L.text)
        self.grp("an_in_h", mk, (0, 28), 0.58)
        total = len(msgs)
        hours, wdays = [0] * 24, [0] * 7
        for mm in msgs:
            t = parse_ts(mm[3])
            if t:
                hours[t.hour] += 1
                wdays[t.weekday()] += 1
        lines = [("chat", "You have {:,} text messages recorded.".format(total), L.a1)]
        if total:
            ratio = sent / float(max(1, received))
            lines.append(("arrow", "You sent %d and received %d (%.1f : 1)." % (sent, received, ratio), L.a2))
            ph = hours.index(max(hours))
            part = "morning" if ph < 12 else "afternoon" if ph < 17 else "evening" if ph < 21 else "night"
            lines.append(("bars", "Peak chat time: %02d:00 \u2013 %02d:00 (%s)." % (ph, (ph + 1) % 24, part), L.green))
            lines.append(("star", "Busiest day: %s. You chat with %d contact%s." % (
                ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"][wdays.index(max(wdays))],
                ncontacts, "" if ncontacts == 1 else "s"), "#F59E0B"))
        else:
            lines.append(("people", "You have chatted with %d contact(s)." % ncontacts, L.a2))
            lines.append(("star", "Keep conversations active to build a richer activity history.", "#F59E0B"))
        for i, (icon, s, col) in enumerate(lines[:4]):
            ry = y + 50 + i * 40
            tag = "an_in%d" % i
            mk = sc.mark()
            cv.create_polygon(rr_points(x + 16, ry, x + w - 16, ry + 34, 12), smooth=True,
                              fill=mix(L.card_bot, col, 0.07 if not L.dark else 0.12), outline="")
            cv.create_oval(x + 24, ry + 5, x + 48, ry + 29, fill=mix(L.card_bot, col, 0.2), outline="")
            self.img(x + 36, ry + 17, get_icon(icon, 13, col))
            it = self.t(x + 58, ry + 17, "" if self.first else s, 8, "normal", L.text, "w")
            self.grp(tag, mk, (30, 0), 0.62 + 0.08 * i)
            if self.first:
                sc.typewrite(it, s, cps=48, delay=1.0 + 0.5 * i)


# ---------------------------------------------------------------- themes ----
class ThemesPage(_HeaderMixin, Page):
    min_w, min_h = 700, 480
    scroll_h = 640

    def __init__(self, cv, look, app, current):
        super().__init__(cv, look)
        self.app, self.current = app, current
        self.busy = False

    def build(self, W, H):
        L, cv, sc = self.look, self.cv, self.sc
        self.aurora(W, H, 16)
        self.header(W, "Themes", "Choose a look that matches your style", self.app.show_dashboard)
        names = list(PALETTES.keys())
        cols, gap, m = 3, 18, 26
        top = 82
        cw = (W - 2 * m - (cols - 1) * gap) / float(cols)
        ch = (max(H, 640) - top - 26 - gap) / 2.0
        for i, name in enumerate(names):
            r, c = divmod(i, cols)
            self._theme_card(name, i, m + c * (cw + gap), top + r * (ch + gap), cw, ch)

    def _theme_card(self, name, i, x, y, w, h):
        L, cv, sc = self.look, self.cv, self.sc
        P = palette_for(name)
        T = Look(P)
        tag = "th%d" % i
        active = (name == self.current)
        mk = sc.mark()
        ids = self.card(x, y, w, h, 18, glow=T.a1, border=(T.a1 if active else L.line))
        # --- miniature app preview, drawn in the theme's own colours
        px, py, pw, ph = x + 14, y + 14, w - 28, h - 96
        cv.create_polygon(rr_points(px, py, px + pw, py + ph, 12), smooth=True, fill=T.page, outline=mix(T.page, T.text, 0.12))
        sbw = pw * 0.17
        cv.create_polygon(rr_points(px, py, px + sbw + 8, py + ph, 12), smooth=True, fill=T.sb_top, outline="")
        cv.create_rectangle(px + sbw - 4, py + 1, px + sbw + 8, py + ph - 1, fill=T.sb_top, outline="")
        for k in range(4):
            yy = py + 26 + k * 17
            if k == 0:
                cv.create_polygon(rr_points(px + 7, yy - 6, px + sbw - 2, yy + 6, 5), smooth=True, fill=T.a1, outline="")
            else:
                cv.create_line(px + 9, yy, px + sbw - 6, yy, fill=mix(T.sb_top, "#FFFFFF", 0.28), width=3, capstyle="round")
        cv.create_oval(px + 10, py + 8, px + 18, py + 16, fill=T.a3, outline="")
        gx = px + sbw + 22
        gw = (px + pw - 12 - gx - 2 * 8) / 3.0
        cv.create_line(gx, py + 14, gx + gw * 1.2, py + 14, fill=T.text, width=4, capstyle="round")
        for k in range(3):
            cx0 = gx + k * (gw + 8)
            cv.create_polygon(rr_points(cx0, py + 28, cx0 + gw, py + 52, 7), smooth=True, fill=T.card_top if not T.dark else T.card_bot,
                              outline=mix(T.page, T.text, 0.10))
            cv.create_oval(cx0 + 5, py + 33, cx0 + 15, py + 43, fill=[T.a1, T.green, T.a2][k], outline="")
        # chart panel with a self-drawing line
        cpx0, cpy0, cpx1, cpy1 = gx, py + 60, px + pw - 12, py + ph - 10
        cv.create_polygon(rr_points(cpx0, cpy0, cpx1, cpy1, 8), smooth=True, fill=T.card_top if not T.dark else T.card_bot,
                          outline=mix(T.page, T.text, 0.10))
        vals = [0.3, 0.55, 0.4, 0.75, 0.55, 0.9, 0.7]
        cp = [(cpx0 + 8 + (cpx1 - cpx0 - 16) * k / 6.0, cpy1 - 6 - (cpy1 - cpy0 - 14) * v) for k, v in enumerate(vals)]
        sc.line_chart(cp, T.a1, mix(T.card_top if not T.dark else T.card_bot, T.a1, 0.2), cpy1 - 4, width=2,
                      delay=0.5 + 0.08 * i if self.first else 0.0, duration=self.dur(1.2), dot=False, follow=tag)
        # drifting mini orb (stays inside the preview)
        orb = cv.create_oval(0, 0, 0, 0, fill=mix(T.page, T.a2, 0.35), outline="")
        cv.tag_lower(orb)
        ocx, ocy = px + pw * 0.70, py + ph * 0.38

        def drift(dt, now):
            ox, oy = sc.off(tag)
            qx = ocx + math.sin(now * 0.7 + i) * 22 + ox
            qy = ocy + math.cos(now * 0.9 + i) * 10 + oy
            cv.coords(orb, qx - 10, qy - 10, qx + 10, qy + 10)
        sc.on(drift, every=2)
        # --- text + swatches
        ty = y + h - 74
        self.t(x + 20, ty, name, 12, "bold", L.text)
        self.t(x + 20, ty + 22, THEME_DESC.get(name, ""), 8, "normal", L.muted)
        for k, col in enumerate([T.a1, T.a2, T.a3, T.green, T.pink]):
            sx = x + 22 + k * 20
            cv.create_oval(sx - 7, ty + 48, sx + 7, ty + 62, fill=col, outline=L.card_top, width=2)
        # --- badge
        if active:
            bw = 64
            bx = x + w - 20 - bw
            im, mg = pill_image(bw, 22, 11, T.a1, T.a2, glow=T.a1, glow_a=90)
            self.img(bx - mg, ty + 2 - mg, im, "nw")
            self.t(bx + bw / 2, ty + 13, "ACTIVE", 7, "bold", "#FFFFFF", "center")
        else:
            self.t(x + w - 20, ty + 13, "Click to apply", 8, "normal", L.muted, "e")
        self.grp(tag, mk, (0, 40), 0.1 + 0.08 * i)
        on, off = self.hover_card(ids, tag, -6)

        def pick(n=name, tg=tag):
            if self.busy:
                return
            self.busy = True
            self._flash(n, x, y, w, h)
            self.cv.after(520, lambda: self.app.apply_theme(n))
        self.hit((x, y, x + w, y + h), pick, on, off)

    def _flash(self, name, x, y, w, h):
        """Expanding colour wash from the clicked card before the theme is applied."""
        T = Look(palette_for(name))
        cv, sc = self.cv, self.sc
        cx, cy = x + w / 2.0, y + h / 2.0
        ring = cv.create_oval(cx, cy, cx, cy, outline=T.a1, width=3, fill="")
        wash = cv.create_oval(cx, cy, cx, cy, outline="", fill=mix(T.page, T.a1, 0.1))
        cv.tag_raise(wash)
        cv.tag_raise(ring)
        W, H = self.cv.winfo_width(), self.cv.winfo_height()
        rmax = math.hypot(W, H)

        def grow(p):
            r = rmax * p
            cv.coords(wash, cx - r, cy - r, cx + r, cy + r)
            cv.coords(ring, cx - r, cy - r, cx + r, cy + r)
        sc.tween(0.5, grow, ease=ease_out_cubic)
