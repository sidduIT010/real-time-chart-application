"""
NexaChat chat engine (v11)
==========================
Theme-aware, Canvas-drawn chat screen built on fxkit.Page. It replaces the old
widget-based chat UI for private chats and is reusable for group chats.

    ChatShell        left conversation list + header + message pane + composer
    ListHeader       title row + search pill of the conversation list
    ListRows         scrolling conversation rows (avatar, preview, unread badge)
    ChatHeader       avatar / name / live status / search / menu
    MessagePane      gradient bubbles, date pills, replies, images, ticks, typing dots
    Composer         floating input pill, reply/edit banner, emoji/attach/send

The module is UI only: every action goes back to the application through the
callback dictionary handed to ChatShell, so database logic stays in main.py.
"""
import os
import tkinter as tk
import tkinter.font as tkfont
from PIL import Image, ImageDraw, ImageFilter, ImageTk

from fx import mix, hex_rgb
from fxkit import Page, FONT, card_image, pill_image, dp_avatar
from ui_components import make_avatar, get_icon

AV_COLORS = [("#6366F1", "#A855F7"), ("#06B6D4", "#3B82F6"), ("#F97316", "#EC4899"),
             ("#10B981", "#14B8A6"), ("#F43F5E", "#F59E0B"), ("#8B5CF6", "#EC4899")]

LIST_W = 340


# ------------------------------------------------------------------ helpers
def initials(name):
    parts = str(name or "?").split()
    if not parts:
        return "?"
    return (parts[0][0] + (parts[1][0] if len(parts) > 1 else "")).upper()


def av_colors(key):
    return AV_COLORS[sum(map(ord, str(key))) % len(AV_COLORS)]


_fonts = {}


def font(size=11, weight="normal"):
    k = (size, weight)
    if k not in _fonts:
        _fonts[k] = tkfont.Font(family=FONT, size=size, weight=weight)
    return _fonts[k]


def fit(text, f, maxw):
    """Single-line ellipsis."""
    text = " ".join(str(text).split())
    if f.measure(text) <= maxw:
        return text
    while text and f.measure(text + "…") > maxw:
        text = text[:-1]
    return text + "…"


_bub = {}


def bubble_image(w, h, r, top, bot, border=None, own=True, shadow=0):
    """Rounded bubble (square 'tail' corner on the sender's bottom side). Small, cached."""
    w, h = int(w), int(h)
    r = max(2, min(r, (min(w, h) - 1) // 2))
    key = (w, h, r, top, bot, border, own, shadow)
    if key in _bub:
        return _bub[key]
    m, S = 6, 2
    W, H = w + 2 * m, h + 2 * m
    out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    if shadow:
        sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        ImageDraw.Draw(sh).rounded_rectangle([m, m + 2, m + w - 1, m + h + 1], r, fill=(30, 30, 80, shadow))
        out.alpha_composite(sh.filter(ImageFilter.GaussianBlur(3)))
    ww, hh = w * S, h * S
    g = Image.linear_gradient("L").resize((ww, hh))
    grad = Image.composite(Image.new("RGB", (ww, hh), hex_rgb(bot)), Image.new("RGB", (ww, hh), hex_rgb(top)), g)
    mask = Image.new("L", (ww, hh), 0)
    corners = (True, True, not own, own)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, ww - 1, hh - 1], r * S, fill=255, corners=corners)
    body = Image.new("RGBA", (ww, hh), (0, 0, 0, 0))
    body.paste(grad, (0, 0), mask)
    if border:
        ImageDraw.Draw(body).rounded_rectangle([0, 0, ww - 1, hh - 1], r * S, outline=hex_rgb(border) + (255,),
                                               width=S, corners=corners)
    out.alpha_composite(body.resize((w, h), Image.LANCZOS), (m, m))
    if len(_bub) > 500:
        _bub.clear()
    _bub[key] = (ImageTk.PhotoImage(out), m)
    return _bub[key]


_thumbs = {}


def thumb_image(path, maxside=250, radius=12):
    try:
        mt = os.path.getmtime(path)
    except OSError:
        return None
    key = (path, mt, maxside)
    if key in _thumbs:
        return _thumbs[key]
    try:
        im = Image.open(path).convert("RGB")
        im.thumbnail((maxside, maxside), Image.LANCZOS)
        S = 3
        big = im.resize((im.width * S, im.height * S), Image.LANCZOS)
        mask = Image.new("L", big.size, 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, big.width - 1, big.height - 1], radius * S, fill=255)
        mask = mask.resize(im.size, Image.LANCZOS)
        out = Image.new("RGBA", im.size, (0, 0, 0, 0))
        out.paste(im, (0, 0), mask)
        if len(_thumbs) > 80:
            _thumbs.clear()
        _thumbs[key] = ImageTk.PhotoImage(out)
        return _thumbs[key]
    except Exception:
        return None


_bgs = {}


def chat_bg(w, h, look):
    """Soft vertical gradient with two blurred colour blobs (static, cheap to re-anchor on scroll)."""
    w, h = int(w), int(h)
    key = (w, h, look.page, look.a1, look.a2)
    if key in _bgs:
        return _bgs[key]
    L = look
    base = Image.new("RGB", (w, h), hex_rgb(L.page))
    g = Image.linear_gradient("L").resize((w, h))
    tint = Image.new("RGB", (w, h), hex_rgb(mix(L.page, L.a1, 0.07 if not L.dark else 0.10)))
    base = Image.composite(tint, base, g)
    blobs = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(blobs)
    a = 46 if not L.dark else 60
    d.ellipse([w * 0.62, -h * 0.25, w * 1.2, h * 0.38], fill=hex_rgb(L.a1) + (a,))
    d.ellipse([-w * 0.25, h * 0.62, w * 0.35, h * 1.25], fill=hex_rgb(L.a2) + (a,))
    blobs = blobs.filter(ImageFilter.GaussianBlur(70))
    out = base.convert("RGBA")
    out.alpha_composite(blobs)
    if len(_bgs) > 6:
        _bgs.clear()
    _bgs[key] = ImageTk.PhotoImage(out.convert("RGB"))
    return _bgs[key]


def styled_menu(parent, look):
    return tk.Menu(parent, tearoff=0, bg=look.surface, fg=look.text, activebackground=look.a1b,
                   activeforeground="#FFFFFF", bd=0, relief="flat", font=(FONT, 10))


def wheel_units(e):
    if getattr(e, "num", 0) == 4:
        return -2
    if getattr(e, "num", 0) == 5:
        return 2
    return int(-1 * (e.delta / 120.0)) * 2 or (-2 if e.delta > 0 else 2)


# ---------------------------------------------------------------- shared bits
class Base(Page):
    """Page with small conveniences shared by the chat surfaces."""
    min_w, min_h = 60, 30

    def refresh(self):
        self._rebuild()

    def avatar(self, x, y, size, name, dp, key=None, online=None, ring_bg=None, icon=None):
        L = self.look
        c1, c2 = av_colors(key if key is not None else name)
        im = dp_avatar(dp, size, c1) if dp else None
        if im is not None:
            self.img(x, y, im)
        else:
            self.img(x, y, make_avatar(size, c1, c2, True))
            if icon:
                self.img(x, y, get_icon(icon, int(size * 0.5), "#FFFFFF"))
            else:
                self.t(x, y, initials(name), size=max(8, int(size * 0.30)), weight="bold", fill="#FFFFFF",
                       anchor="center")
        if online is not None:
            r = max(5, size // 9)
            ox, oy = x + size * 0.36, y + size * 0.36
            self.cv.create_oval(ox - r - 2, oy - r - 2, ox + r + 2, oy + r + 2, fill=ring_bg or self.look.surface, outline="")
            self.cv.create_oval(ox - r, oy - r, ox + r, oy + r, fill=self.look.green if online else "#94A3B8", outline="")

    def icon_btn(self, cx, cy, d, icon, cb, tint=None, filled=False, tip=None):
        """Round hover button with an icon (or a text glyph when icon is not a known icon name)."""
        L = self.look
        r = d / 2.0
        bg = self.cv.create_oval(cx - r, cy - r, cx + r, cy + r, fill=(L.a1b if filled else L.soft), outline="", state="normal" if filled else "hidden")
        col = "#FFFFFF" if filled else (tint or L.muted)
        ico = get_icon(icon, int(d * 0.5), col) if icon in KNOWN_ICONS else None
        if ico is not None:
            self.img(cx, cy, ico)
        else:
            self.t(cx, cy, icon, size=int(d * 0.36), weight="bold", fill=col, anchor="center")

        def on():
            self.cv.itemconfigure(bg, state="normal", fill=L.a1b if filled else L.soft)

        def off():
            self.cv.itemconfigure(bg, state="normal" if filled else "hidden")
        self.hit((cx - r, cy - r, cx + r, cy + r), cb, on, off)
        return bg


KNOWN_ICONS = {"home", "chat", "people", "status", "settings", "sun", "bars", "mask", "hourglass", "star", "ban",
               "power", "megaphone", "shield", "user", "image", "send", "chevron", "arrow", "check", "dot",
               "search", "bell"}


def make_entry(parent, look, size=11):
    e = tk.Entry(parent, font=(FONT, size), bd=0, relief="flat", highlightthickness=0,
                 bg=look.card_bot, fg=look.text, insertbackground=look.a1, selectbackground=look.a1b,
                 selectforeground="#FFFFFF", disabledbackground=look.card_bot)
    return e


class Placeholder:
    """Entry placeholder that keeps get() honest (returns '' while the hint is showing)."""

    def __init__(self, entry, hint, look):
        self.e, self.hint, self.look, self.on = entry, hint, look, False
        entry.bind("<FocusIn>", self._in, add="+")
        entry.bind("<FocusOut>", self._out, add="+")
        self._show()

    def _show(self):
        if not self.e.get():
            self.on = True
            self.e.insert(0, self.hint)
            self.e.config(fg=self.look.muted)

    def _in(self, _e=None):
        if self.on:
            self.e.delete(0, tk.END)
            self.e.config(fg=self.look.text)
            self.on = False

    def _out(self, _e=None):
        if not self.e.get():
            self._show()

    def get(self):
        return "" if self.on else self.e.get()

    def clear(self):
        self.on = False
        self.e.delete(0, tk.END)
        self.e.config(fg=self.look.text)
        if self.e.focus_get() is not self.e:
            self._show()

    def set(self, text):
        self._in()
        self.e.delete(0, tk.END)
        self.e.insert(0, text)
        self.e.icursor(tk.END)


# ------------------------------------------------------------ conversation list
class ListHeader(Base):
    """Title, count, back + compose buttons and the search pill."""

    def __init__(self, cv, look, title, cb, hint="Search conversations…"):
        super().__init__(cv, look)
        self.title, self.cb, self.count = title, cb, 0
        self.entry = make_entry(cv, look, 10)
        self.ph = Placeholder(self.entry, hint, look)
        self.entry.bind("<KeyRelease>", lambda e: self.cb["query"](self.ph.get()), add="+")

    def build(self, W, H):
        L, cv = self.look, self.cv
        cv.create_rectangle(0, 0, W, H, fill=L.page, outline="")
        self.icon_btn(34, 40, 38, "←", self.cb["back"], tint=L.text)
        self.t(62, 40, self.title, size=17, weight="bold", anchor="w")
        if self.count:
            tw = font(17, "bold").measure(self.title)
            self.cv.create_text(62 + tw + 10, 42, text=str(self.count), anchor="w", font=(FONT, 10, "bold"), fill=L.muted)
        self.icon_btn(W - 34, 40, 38, "＋", self.cb.get("compose") or (lambda: self.entry.focus_set()), filled=True)
        # search pill
        x, y, w, h = 16, 70, W - 32, 40
        base, m = card_image(w, h, 20, L.card_bot, L.card_bot, L.line, L.shadow)
        self.img(x - m, y - m, base, "nw")
        ico = get_icon("search", 16, L.muted)
        self.img(x + 20, y + h / 2.0, ico)
        cv.create_window(x + 38, y + h / 2.0, window=self.entry, anchor="w", width=w - 56, height=24)


class ListRows(Base):
    ROW_H, GAP = 70, 8

    def __init__(self, cv, look, cb):
        super().__init__(cv, look)
        self.cb, self.rows, self.sel, self.query = cb, [], None, ""
        cv.bind("<MouseWheel>", self._wheel, add="+")
        cv.bind("<Button-4>", self._wheel, add="+")
        cv.bind("<Button-5>", self._wheel, add="+")

    def _wheel(self, e):
        self.cv.yview_scroll(wheel_units(e), "units")

    def set_rows(self, rows, selected=None, query=None):
        self.rows = rows
        self.sel = selected
        if query is not None:
            self.query = query
        self.refresh()

    def visible(self):
        q = self.query.lower().strip()
        return [r for r in self.rows if not q or q in r["name"].lower()]

    def build(self, W, H):
        L, cv = self.look, self.cv
        rows = self.visible()
        total = 10 + len(rows) * (self.ROW_H + self.GAP) + 14
        self.scroll_h = max(H, total)
        cv.configure(scrollregion=(0, 0, W, self.scroll_h))
        cv.create_rectangle(0, 0, W, self.scroll_h, fill=L.page, outline="")
        if not rows:
            self.t(W / 2, 80, "No conversations found" if self.query else "No contacts yet", size=11, weight="bold",
                   fill=L.muted, anchor="center")
            if self.query:
                self.t(W / 2, 104, "Try a different name", size=9, fill=L.muted, anchor="center")
            return
        y = 8
        for i, r in enumerate(rows):
            self._row(i, r, 14, y, W - 28, self.ROW_H)
            y += self.ROW_H + self.GAP

    def _row(self, i, r, x, y, w, h):
        L, cv = self.look, self.cv
        selected = (r["id"] == self.sel)
        tag = "row%d" % i
        mark = self.sc.mark()
        if selected:
            im, m = pill_image(w, h, 18, L.p1, L.a2, glow=L.a1b, horizontal=True, glow_a=95)
            self.img(x - m, y - m, im, "nw")
            ids = None
            tcol, mcol, bcol = "#FFFFFF", mix("#FFFFFF", L.a2, 0.25), "#FFFFFF"
        else:
            ids = self.card(x, y, w, h, r=18)
            tcol, mcol, bcol = L.text, L.muted, None
        self.avatar(x + 38, y + h / 2.0, 44, r["name"], r.get("dp"), key=r["id"],
                    online=(bool(r.get("online")) if r.get("online") is not None else None),
                    ring_bg=(L.p1 if selected else L.card_bot), icon=r.get("icon"))
        nf = font(11, "bold")
        right = w - 16
        tm = r.get("time", "")
        tw = font(8).measure(tm) if tm else 0
        self.t(x + 74, y + 17, fit(r["name"], nf, w - 74 - tw - 30), size=11, weight="bold", fill=tcol)
        if tm:
            self.t(x + right, y + 18, tm, size=8, fill=(mcol if not r.get("unread") or selected else L.a1), anchor="ne")
        prev = r.get("preview") or ("typing…" if r.get("typing") else (r.get("empty") or "Say hi 👋"))
        pcol = mcol
        if r.get("typing"):
            prev, pcol = "typing…", (L.green if not selected else "#FFFFFF")
        self.t(x + 74, y + 42, fit(prev, font(9), w - 74 - 56), size=9, fill=pcol)
        n = r.get("unread") or 0
        if n:
            txt = str(n) if n < 100 else "99+"
            bw = max(22, font(8, "bold").measure(txt) + 14)
            bx, by = x + right - bw, y + 38
            if selected:
                cv.create_oval(bx, by, bx + 22, by + 22, fill="#FFFFFF", outline="")
                cv.create_oval(bx + bw - 22, by, bx + bw, by + 22, fill="#FFFFFF", outline="")
                cv.create_rectangle(bx + 11, by, bx + bw - 11, by + 22, fill="#FFFFFF", outline="")
                self.t(bx + bw / 2.0, by + 11, txt, size=8, weight="bold", fill=L.a1b, anchor="center")
            else:
                im, mm = pill_image(bw, 22, 11, L.p1, L.a2, glow=L.a1b, glow_a=90)
                self.img(bx - mm, by - mm, im, "nw")
                self.t(bx + bw / 2.0, by + 11, txt, size=8, weight="bold", fill="#FFFFFF", anchor="center")
        self.grp(tag, mark)
        enter = leave = None
        if ids:
            enter, leave = self.hover_card(ids, tag, lift=-2)
        self.hit((x, y, x + w, y + h), lambda r=r: self.cb["select"](r["id"], r["name"]), enter, leave)


# ------------------------------------------------------------------ header bar
class ChatHeader(Base):
    def __init__(self, cv, look, cb):
        super().__init__(cv, look)
        self.cb = cb
        self.state = None
        self.search_open = False
        self.entry = make_entry(cv, look, 10)
        self.ph = Placeholder(self.entry, "Search in conversation…", look)
        self.entry.bind("<KeyRelease>", lambda e: self.cb["search"](self.ph.get()), add="+")
        self.entry.bind("<Escape>", lambda e: self.toggle_search(False), add="+")

    def set(self, title, subtitle="", kind="muted", dp=None, online=None, key=None, menu=None, back=True, icon=None):
        self.state = dict(title=title, subtitle=subtitle, kind=kind, dp=dp, online=online, key=key, menu=menu or [],
                          back=back, icon=icon)
        self.search_open = False
        self.ph.clear()
        self.refresh()

    def set_status(self, subtitle, kind="muted", online=None):
        if not self.state:
            return
        if (subtitle, kind, online) == (self.state["subtitle"], self.state["kind"], self.state["online"]):
            return
        self.state.update(subtitle=subtitle, kind=kind, online=online)
        self.refresh()

    def toggle_search(self, on=None):
        self.search_open = (not self.search_open) if on is None else on
        if not self.search_open:
            self.ph.clear()
            self.cb["search"]("")
        self.refresh()
        if self.search_open:
            self.cv.after(30, self.entry.focus_set)

    def _menu(self):
        s = self.state
        if not s or not s["menu"]:
            return
        m = styled_menu(self.cv, self.look)
        for label, fn in s["menu"]:
            if label == "-":
                m.add_separator()
            else:
                m.add_command(label=label, command=fn)
        x = self.cv.winfo_rootx() + self.cv.winfo_width() - 230
        y = self.cv.winfo_rooty() + 66
        m.tk_popup(x, y)

    def build(self, W, H):
        L, cv, s = self.look, self.cv, self.state
        cv.create_rectangle(0, 0, W, H, fill=mix(L.page, L.surface, 0.85 if not L.dark else 0.6), outline="")
        cv.create_line(0, H - 1, W, H - 1, fill=L.line)
        if not s:
            return
        x = 18
        if s["back"]:
            self.icon_btn(x + 17, H / 2.0, 36, "←", self.cb["back"], tint=L.text)
            x += 46
        self.avatar(x + 24, H / 2.0, 44, s["title"], s["dp"], key=s["key"] if s["key"] is not None else s["title"],
                    online=s["online"], ring_bg=L.surface, icon=s.get("icon"))
        x += 58
        self.t(x, H / 2.0 - 9, fit(s["title"], font(13, "bold"), W - x - 230), size=13, weight="bold", anchor="w")
        col = {"typing": L.green, "online": L.green}.get(s["kind"], L.muted)
        self.t(x, H / 2.0 + 12, fit(s["subtitle"], font(9), W - x - 230), size=9, fill=col,
               weight="bold" if s["kind"] in ("typing", "online") else "normal", anchor="w")
        rx = W - 30
        if s["menu"]:
            self.icon_btn(rx, H / 2.0, 38, "⋮", self._menu, tint=L.text)
            rx -= 46
        if self.search_open:
            w = min(280, max(150, W - x - 200))
            x1 = rx - w + 20
            base, m = card_image(w, 38, 19, L.card_bot, L.card_bot, mix(L.line, L.a1, 0.6), L.shadow)
            self.img(x1 - m, H / 2.0 - 19 - m, base, "nw")
            cv.create_window(x1 + 14, H / 2.0, window=self.entry, anchor="w", width=w - 66, height=22)
            self.icon_btn(x1 + w - 20, H / 2.0, 26, "✕", lambda: self.toggle_search(False), tint=L.muted)
        else:
            self.icon_btn(rx, H / 2.0, 38, "search", lambda: self.toggle_search(True), tint=L.text)


# -------------------------------------------------------------- message pane
class MessagePane(Base):
    PADX = 26

    EMPTY = dict(title="Your conversations, beautifully connected",
                 sub="Pick a contact on the left to start chatting, share photos, and keep every thread in one place.",
                 feats=[("⚡", "Fast messaging", "Real-time delivery"), ("↩", "Rich threads", "Reply, edit & star"),
                        ("✓", "Private & secure", "Stored on this device")],
                 icon="chat")

    def __init__(self, cv, look, cb, empty=None):
        super().__init__(cv, look)
        self.cb = cb
        self.empty = empty or self.EMPTY
        self.msgs, self.mode = [], "empty"
        self.typing = False
        self.info = ""
        self.boxes, self.quotes, self.ypos = [], [], {}
        self.stick = "bottom"
        self.bg_id = self.thumb = self.hov = None
        self.hover_msg = None
        self._saved_y = None
        cv.bind("<MouseWheel>", self._wheel, add="+")
        cv.bind("<Button-4>", self._wheel, add="+")
        cv.bind("<Button-5>", self._wheel, add="+")
        cv.bind("<Motion>", self._mmove, add="+")
        cv.bind("<Leave>", lambda e: self._hover(None), add="+")
        cv.bind("<Button-3>", self._rclick, add="+")
        cv.bind("<Double-Button-1>", self._dbl, add="+")
        cv.bind("<Button-1>", self._lclick, add="+")

    # ----- public
    def show_empty(self):
        self.mode, self.msgs = "empty", []
        self.stick = "top"
        self.refresh()

    def show_messages(self, msgs, stick="bottom", info=""):
        self.mode, self.msgs, self.info, self.stick = "chat", msgs, info, stick
        self.refresh()

    def set_typing(self, flag):
        if flag != self.typing:
            self.typing = flag
            if self.mode == "chat":
                self.stick = "keep_bottom"
                self.refresh()

    def scroll_to(self, msg_id):
        y = self.ypos.get(msg_id)
        if y is None:
            return
        H = self.cv.winfo_height()
        total = max(1, self.scroll_h)
        self.cv.yview_moveto(max(0.0, (y - H / 3.0)) / total)
        self._anchor()
        box = next((b for b in self.boxes if b[4]["id"] == msg_id), None)
        if box:
            x1, y1, x2, y2, _ = box
            rid = self.cv.create_rectangle(x1 - 4, y1 - 4, x2 + 4, y2 + 4, outline=self.look.a3, width=3)
            self.cv.after(900, lambda: self.cv.delete(rid))

    # ----- events
    def _wheel(self, e):
        self.cv.yview_scroll(wheel_units(e), "units")
        self._anchor()

    def _msg_at(self, e):
        x, y = self.cv.canvasx(e.x), self.cv.canvasy(e.y)
        for x1, y1, x2, y2, m in self.boxes:
            if x1 <= x <= x2 and y1 <= y <= y2:
                return m, (x1, y1, x2, y2)
        return None, None

    def _mmove(self, e):
        m, box = self._msg_at(e)
        self._hover(m, box)
        x, y = self.cv.canvasx(e.x), self.cv.canvasy(e.y)
        over_q = any(a <= x <= c and b <= y <= d for a, b, c, d, _ in self.quotes)
        self.cv.configure(cursor="hand2" if over_q or self._on_toolbar(x, y) else "")

    def _hover(self, m, box=None):
        key = m["id"] if m else None
        if key == self.hover_msg:
            return
        self.hover_msg = key
        self.cv.delete("hovtb")
        self.tb_boxes = []
        if not m or not m.get("id"):
            return
        L = self.look
        x1, y1, x2, y2 = box
        cy = (y1 + y2) / 2.0 if y2 - y1 < 70 else y1 + 24
        own = m["own"]
        bx = x1 - 22 if own else x2 + 22
        step = -40 if own else 40
        buttons = [b for b in (("↩", "reply"), ("⋯", "more")) if b[1] != "reply" or self.cb.get("reply")]
        for i, (g, kind) in enumerate(buttons):
            cx = bx + i * step
            self.cv.create_oval(cx - 15, cy - 15, cx + 15, cy + 15, fill=L.card_top, outline=L.line, tags="hovtb")
            self.cv.create_text(cx, cy - 1, text=g, font=(FONT, 12, "bold"), fill=L.a1b, tags="hovtb")
            self.tb_boxes.append((cx - 15, cy - 15, cx + 15, cy + 15, kind, m))

    def _on_toolbar(self, x, y):
        return any(a <= x <= c and b <= y <= d for a, b, c, d, _, _ in getattr(self, "tb_boxes", []))

    def _lclick(self, e):
        x, y = self.cv.canvasx(e.x), self.cv.canvasy(e.y)
        for a, b, c, d, kind, m in getattr(self, "tb_boxes", []):
            if a <= x <= c and b <= y <= d:
                if kind == "reply" and self.cb.get("reply"):
                    self.cb["reply"](m["id"])
                else:
                    self._menu(m, e.x_root, e.y_root)
                return
        for a, b, c, d, rid in self.quotes:
            if a <= x <= c and b <= y <= d and rid:
                self.scroll_to(rid)
                return
        m, _ = self._msg_at(e)
        if m and m.get("type") == "image" and m.get("path") and os.path.exists(m["path"]):
            self._viewer(m["path"])

    def _dbl(self, e):
        m, _ = self._msg_at(e)
        if m and m.get("id") and m.get("type") != "image" and self.cb.get("reply"):
            self.cb["reply"](m["id"])

    def _rclick(self, e):
        m, _ = self._msg_at(e)
        if m and m.get("id"):
            self._menu(m, e.x_root, e.y_root)

    def _menu(self, m, rx, ry):
        menu = styled_menu(self.cv, self.look)
        n = 0
        if self.cb.get("reply"):
            menu.add_command(label="↩  Reply", command=lambda: self.cb["reply"](m["id"]))
            n += 1
        if m.get("type") != "image":
            menu.add_command(label="⧉  Copy text", command=lambda: self._copy(m["text"]))
            n += 1
        if m["own"] and m.get("type") != "image" and self.cb.get("edit"):
            menu.add_command(label="✎  Edit", command=lambda: self.cb["edit"](m["id"], m["text"]))
            n += 1
        if self.cb.get("star") or (self.cb.get("delete") and m.get("can_delete", True)):
            if n:
                menu.add_separator()
        if self.cb.get("star"):
            menu.add_command(label=("☆  Unstar" if m.get("starred") else "★  Star"),
                             command=lambda: self.cb["star"](m["id"]))
        if self.cb.get("delete") and m.get("can_delete", True):
            menu.add_command(label="🗑  Delete", command=lambda: self.cb["delete"](m["id"]))
        if menu.index("end") is None:
            return
        menu.tk_popup(rx, ry)

    def _copy(self, text):
        try:
            self.cv.clipboard_clear()
            self.cv.clipboard_append(text)
        except tk.TclError:
            pass

    def _viewer(self, path):
        try:
            im = Image.open(path).convert("RGB")
            top = tk.Toplevel(self.cv)
            top.title("Image")
            top.configure(bg="#000000")
            sw, sh = top.winfo_screenwidth() - 160, top.winfo_screenheight() - 160
            im.thumbnail((sw, sh), Image.LANCZOS)
            ph = ImageTk.PhotoImage(im)
            lb = tk.Label(top, image=ph, bg="#000000", bd=0)
            lb.image = ph
            lb.pack()
            top.bind("<Escape>", lambda e: top.destroy())
            top.focus_set()
        except Exception:
            pass

    # ----- scrolling / background
    def _anchor(self):
        try:
            y = self.cv.canvasy(0)
            if self.bg_id:
                self.cv.coords(self.bg_id, 0, y)
            self._thumb()
        except tk.TclError:
            pass

    def _thumb(self):
        cv = self.cv
        cv.delete("sbar")
        H, W, total = cv.winfo_height(), cv.winfo_width(), self.scroll_h
        if total <= H + 2:
            return
        y0 = cv.canvasy(0)
        th = max(36, H * H / float(total))
        ty = y0 + (H - th) * (y0 / float(total - H))
        cv.create_rectangle(W - 8, ty + 2, W - 3, ty + th - 2, fill=mix(self.look.page, self.look.muted, 0.38),
                            outline="", tags="sbar")

    # ----- drawing
    def build(self, W, H):
        L, cv = self.look, self.cv
        self.boxes, self.quotes, self.ypos, self.hover_msg, self.tb_boxes = [], [], {}, None, []
        if self.mode == "empty":
            self.scroll_h = 0
            self.bg_id = None
            self._empty(W, H)
            return
        # measure + draw messages from y=top; background goes underneath at the end
        prev_y = self._saved_y
        was_bottom = self._at_bottom if hasattr(self, "_at_bottom") else True
        top = 20
        y = top
        if self.info and not self.msgs:
            self.t(W / 2, H / 2 - 10, self.info, size=11, weight="bold", fill=L.muted, anchor="center")
        last_date = None
        last_sender = object()
        for m in self.msgs:
            if m.get("date") and m["date"] != last_date:
                y = self._date_pill(W, y, m["date"])
                last_date = m["date"]
                last_sender = object()
            same = (m.get("sender_key") == last_sender)
            y = self._message(W, y + (3 if same else 10), m)
            last_sender = m.get("sender_key")
        if self.typing:
            y = self._typing(W, y + 10)
        y += 22
        content = y
        self.scroll_h = max(H, content)
        offset = max(0, H - content)  # anchor short chats to the bottom
        if offset:
            cv.move("all", 0, offset)
            self.boxes = [(a, b + offset, c, d + offset, m) for a, b, c, d, m in self.boxes]
            self.quotes = [(a, b + offset, c, d + offset, r) for a, b, c, d, r in self.quotes]
            self.ypos = {k: v + offset for k, v in self.ypos.items()}
            self.scroll_h = H
        cv.configure(scrollregion=(0, 0, W, self.scroll_h))
        self.bg_id = cv.create_image(0, 0, image=self._keep(chat_bg(W, H, L)), anchor="nw")
        cv.tag_lower(self.bg_id)
        if self.stick in ("bottom", "keep_bottom") or (self.stick == "keep" and was_bottom):
            cv.yview_moveto(1.0)
        elif prev_y is not None:
            cv.yview_moveto(prev_y / float(max(1, self.scroll_h)))
        self._anchor()

    def _keep(self, im):
        self.sc.keep.append(im)
        return im

    def _rebuild(self):
        # remember the scroll position so refreshes never jump the view
        try:
            self._saved_y = self.cv.canvasy(0)
            H = self.cv.winfo_height()
            self._at_bottom = (self._saved_y + H) >= (self.scroll_h - 6)
        except tk.TclError:
            pass
        super()._rebuild()

    def _empty(self, W, H):
        L, cv = self.look, self.cv
        self.img(0, 0, chat_bg(W, H, L), "nw")
        cx, cy = W / 2.0, H / 2.0 - 70
        # glow disc + two floating chat bubbles
        halo, m = pill_image(150, 150, 75, L.p1, L.a2, glow=L.a1b, horizontal=False, glow_a=120)
        mark = self.sc.mark()
        self.img(cx - 75 - m, cy - 75 - m, halo, "nw")
        self.img(cx, cy - 2, get_icon(self.empty.get("icon", "chat"), 64, "#FFFFFF"))
        self.grp("hero", mark)
        self.sc.bob("hero", amp=5, period=3.4)
        self.t(cx, cy + 112, self.empty["title"], size=19, weight="bold", anchor="center")
        self.t(cx, cy + 142, self.empty["sub"], size=10, fill=L.muted, anchor="center")
        feats = self.empty["feats"]
        cw, gap = 224, 14
        x = cx - (cw * 3 + gap * 2) / 2.0
        for i, (g, t1, t2) in enumerate(feats):
            y = cy + 180
            tag = "feat%d" % i
            mk = self.sc.mark()
            ids = self.card(x, y, cw, 84, r=16)
            ci, mm = pill_image(34, 34, 17, L.p1, L.a2, glow=L.a1b, glow_a=70)
            self.img(x + 18 - mm, y + 16 - mm, ci, "nw")
            self.t(x + 35, y + 33, g, size=11, anchor="center", fill="#FFFFFF")
            self.t(x + 62, y + 20, t1, size=10, weight="bold")
            self.t(x + 62, y + 42, t2, size=9, fill=L.muted)
            self.t(x + 18, y + 64, "●", size=6, fill=L.green, anchor="w")
            self.grp(tag, mk, enter=(0, 24), delay=0.12 * i)
            on, off = self.hover_card(ids, tag, lift=-4)
            self.hit((x, y, x + cw, y + 84), None, on, off)
            x += cw + gap

    def _date_pill(self, W, y, label):
        L = self.look
        f = font(9, "bold")
        w = f.measure(label) + 28
        x1 = (W - w) / 2.0
        im, m = bubble_image(w, 26, 13, mix(L.page, L.surface, 0.9), mix(L.page, L.surface, 0.9), border=L.line, own=True,
                             shadow=0)
        self.img(x1 - m, y - m, im, "nw")
        self.t(W / 2.0, y + 13, label, size=9, weight="bold", fill=L.muted, anchor="center")
        return y + 26 + 6

    def _typing(self, W, y):
        L = self.look
        x = self.PADX
        im, m = bubble_image(64, 36, 18, L.card_top, L.card_bot, border=L.line, own=False, shadow=26)
        self.img(x - m, y - m, im, "nw")
        dots = [self.cv.create_oval(x + 16 + i * 14, y + 14, x + 24 + i * 14, y + 22, fill=L.muted, outline="")
                for i in range(3)]
        state = {"i": 0}

        def step(dt, now):
            state["i"] = (state["i"] + 1) % 30
            for i, d in enumerate(dots):
                on = (state["i"] // 10) == i
                try:
                    self.cv.itemconfigure(d, fill=L.a1b if on else L.muted)
                except tk.TclError:
                    return
        self.sc.on(step, every=6)
        return y + 36

    def _message(self, W, y, m):
        L, cv = self.look, self.cv
        own = m["own"]
        maxw = int(min(W * 0.62, 560))
        maxw = max(maxw, 180)
        padx, pady = 14, 9
        body_f, meta_f = font(11), font(8)
        time_s = m.get("time", "")
        edited = " · edited" if m.get("edited") else ""
        star = "★ " if m.get("starred") else ""
        meta = star + time_s + edited
        tick = ""
        if own:
            tick = "✓✓" if m.get("status") == "seen" else "✓"
        meta_w = meta_f.measure(meta) + (font(9, "bold").measure(tick) + 6 if tick else 0)

        parts = []  # (kind, height, width, payload)
        if m.get("sender_name") and not own:
            parts.append(("name", 16, font(9, "bold").measure(m["sender_name"]), m["sender_name"]))
        if m.get("reply_text"):
            qw = max(150, min(maxw - 2 * padx, 280))
            parts.append(("quote", 44, qw, m))
        img = None
        if m.get("type") == "image" and m.get("path") and os.path.exists(m["path"]):
            img = thumb_image(m["path"], 260)
        if m.get("type") == "image":
            if img is not None:
                parts.append(("image", img.height(), img.width(), img))
            else:
                parts.append(("text", 20, body_f.measure("⚠ Image not available"), "⚠ Image not available"))
        else:
            txt = m.get("text") or ""
            tid = cv.create_text(-9999, -9999, text=txt, anchor="nw", font=(FONT, 11), width=maxw - 2 * padx)
            bb = cv.bbox(tid)
            cv.delete(tid)
            parts.append(("text", (bb[3] - bb[1]) if bb else 20, (bb[2] - bb[0]) if bb else 20, txt))

        inner_w = max([p[2] for p in parts] + [meta_w + 4])
        is_img_only = (len(parts) == 1 and parts[0][0] == "image")
        px = 6 if is_img_only else padx
        py = 6 if is_img_only else pady
        bw = inner_w + 2 * px
        content_h = sum(p[1] for p in parts) + 6 * (len(parts) - 1) + 17
        bh = content_h + 2 * py

        x1 = (W - self.PADX - bw) if own else self.PADX
        if own:
            im, mm = bubble_image(bw, bh, 18, L.p1, L.a2, own=True, shadow=34 if not L.dark else 60)
            tcol = "#FFFFFF"
            mcol = mix("#FFFFFF", L.a2, 0.30)
        else:
            im, mm = bubble_image(bw, bh, 18, L.card_top, L.card_bot, border=L.line, own=False,
                                  shadow=26 if not L.dark else 70)
            tcol = L.text
            mcol = L.muted
        self.img(x1 - mm, y - mm, im, "nw")

        cy = y + py
        for kind, h, w, payload in parts:
            if kind == "name":
                self.t(x1 + px, cy, payload, size=9, weight="bold", fill=av_colors(m.get("sender_key"))[0])
            elif kind == "quote":
                qx1, qx2 = x1 + px, x1 + px + w
                qbg = mix(L.p1 if own else L.card_bot, "#FFFFFF" if own else L.a1b, 0.20 if own else 0.10)
                cv.create_rectangle(qx1, cy, qx2, cy + h, fill=qbg, outline="")
                cv.create_rectangle(qx1, cy, qx1 + 3, cy + h, fill="#FFFFFF" if own else L.a1b, outline="")
                self.t(qx1 + 10, cy + 5, fit(m.get("reply_sender") or "Message", font(8, "bold"), w - 18), size=8,
                       weight="bold", fill="#FFFFFF" if own else L.a1b)
                self.t(qx1 + 10, cy + 22, fit(m["reply_text"], font(9), w - 18), size=9,
                       fill=mix("#FFFFFF", L.a2, 0.12) if own else L.muted)
                self.quotes.append((qx1, cy, qx2, cy + h, m.get("reply_to")))
            elif kind == "image":
                self.img(x1 + px, cy, payload, "nw")
            else:
                cv.create_text(x1 + px, cy, text=payload, anchor="nw", font=(FONT, 11), fill=tcol, width=maxw - 2 * padx)
            cy += h + 6
        # meta row (right aligned)
        my = y + bh - py - 3
        rx = x1 + bw - px
        if tick:
            seen = m.get("status") == "seen"
            cv.create_text(rx, my, text=tick, anchor="se", font=(FONT, 9, "bold"),
                           fill=(L.a3 if (seen and not L.dark) else ("#7CF2FF" if seen else mcol)))
            rx -= font(9, "bold").measure(tick) + 6
        cv.create_text(rx, my, text=meta, anchor="se", font=(FONT, 8), fill=mcol)

        if m.get("id") is not None:
            self.ypos[m["id"]] = y
        self.boxes.append((x1, y, x1 + bw, y + bh, m))
        return y + bh


# ---------------------------------------------------------------- composer bar
class Composer(Base):
    def __init__(self, cv, look, cb):
        super().__init__(cv, look)
        self.cb = cb
        self.banner = None  # (kind, title, text)
        self.entry = make_entry(cv, look, 11)
        self.ph = Placeholder(self.entry, "Type a message…", look)
        self.entry.bind("<Return>", lambda e: self.cb["send"](), add="+")
        self.entry.bind("<KeyRelease>", self._key, add="+")
        self._had = False
        self.enabled = True

    def _key(self, e):
        if e.keysym not in ("Return", "Escape"):
            self.cb["typing"]()
        has = bool(self.ph.get().strip())
        if has != self._had:
            self._had = has
            self.refresh()

    # public api used by the app
    def get(self):
        return self.ph.get()

    def clear(self):
        self.ph.clear()
        self._had = False
        self.refresh()

    def set(self, text):
        self.ph.set(text)
        self._had = bool(text.strip())
        self.refresh()

    def insert(self, text):
        self.ph._in()
        self.entry.insert(tk.INSERT, text)
        self.entry.focus_set()
        self._had = True
        self.refresh()

    def focus(self):
        self.entry.focus_set()

    def set_banner(self, kind, title, text):
        self.banner = (kind, title, text)
        self.cv.configure(height=self.base_h() + 52)

    def clear_banner(self):
        if self.banner:
            self.banner = None
            self.cv.configure(height=self.base_h())

    def base_h(self):
        return 84

    def build(self, W, H):
        L, cv = self.look, self.cv
        cv.create_rectangle(0, 0, W, H, fill=mix(L.page, L.surface, 0.85 if not L.dark else 0.6), outline="")
        cv.create_line(0, 0, W, 0, fill=L.line)
        top = 0
        if self.banner:
            kind, title, text = self.banner
            edit = kind == "edit"
            col = "#F59E0B" if edit else L.a1b
            x, y, w, h = 20, 10, W - 40, 42
            base, m = card_image(w, h, 14, L.card_top, L.card_bot, L.line, L.shadow)
            self.img(x - m, y - m, base, "nw")
            cv.create_rectangle(x + 1, y + 8, x + 4, y + h - 8, fill=col, outline="")
            self.t(x + 16, y + 7, ("✎  " if edit else "↩  ") + title, size=9, weight="bold", fill=col)
            self.t(x + 16, y + 24, fit(text, font(9), w - 70), size=9, fill=L.muted)
            self.icon_btn(x + w - 22, y + h / 2.0, 26, "✕", self.cb["cancel_banner"], tint=L.muted)
            top = 52
        cy = top + 42
        self.icon_btn(40, cy, 40, "📎", self.cb["attach"], tint=L.muted)
        x1 = 70
        send_d = 46
        w = W - x1 - send_d - 36
        h = 46
        base, m = card_image(w, h, 23, L.card_bot, L.card_bot, L.line, L.shadow)
        self.img(x1 - m, cy - h / 2.0 - m, base, "nw")
        cv.create_window(x1 + 20, cy, window=self.entry, anchor="w", width=w - 76, height=26)
        self.icon_btn(x1 + w - 24, cy, 34, "☺", self.cb["emoji"], tint=L.muted)
        sx = W - 22 - send_d / 2.0
        if self._had or self.banner:
            im, mm = pill_image(send_d, send_d, send_d // 2, L.p1, L.a2, glow=L.a1b, horizontal=False, glow_a=140)
        else:
            im, mm = pill_image(send_d, send_d, send_d // 2, mix(L.p1, L.page, 0.35), mix(L.a2, L.page, 0.35), glow=None,
                                horizontal=False)
        self.img(sx - send_d / 2.0 - mm, cy - send_d / 2.0 - mm, im, "nw")
        ico = get_icon("send", 20, "#FFFFFF")
        self.img(sx, cy, ico)
        self.hit((sx - send_d / 2.0, cy - send_d / 2.0, sx + send_d / 2.0, cy + send_d / 2.0), self.cb["send"])


# ------------------------------------------------------------------ the shell
class ChatShell(tk.Frame):
    """The whole chat screen: list (left) + conversation (right)."""

    def __init__(self, parent, look, cb, list_title="Messages", empty=None, search_hint="Search conversations…"):
        super().__init__(parent, bg=look.page)
        self.look = look
        self.cb = cb
        left = tk.Frame(self, bg=look.page, width=LIST_W)
        left.pack(side="left", fill="y")
        left.pack_propagate(False)
        tk.Frame(self, bg=look.line, width=1).pack(side="left", fill="y")

        lh_cb = dict(back=cb["back"], query=self._query, compose=cb.get("compose"))
        self.lh_cv = tk.Canvas(left, height=124, bg=look.page, highlightthickness=0, bd=0)
        self.lh_cv.pack(fill="x")
        self.list_header = ListHeader(self.lh_cv, look, list_title, lh_cb, search_hint)
        self.lr_cv = tk.Canvas(left, bg=look.page, highlightthickness=0, bd=0)
        self.lr_cv.pack(fill="both", expand=True)
        self.list_rows = ListRows(self.lr_cv, look, dict(select=cb["select"]))

        right = tk.Frame(self, bg=look.page)
        right.pack(side="left", fill="both", expand=True)
        self.hd_cv = tk.Canvas(right, height=76, bg=look.page, highlightthickness=0, bd=0)
        self.header = ChatHeader(self.hd_cv, look, dict(back=cb["back"], search=cb["search"]))
        self.cp_cv = tk.Canvas(right, height=84, bg=look.page, highlightthickness=0, bd=0)
        comp_cb = dict(send=cb["send"], attach=cb["attach"], emoji=cb["emoji"], typing=cb.get("typing") or (lambda: None),
                       cancel_banner=cb.get("cancel_banner") or (lambda: None))
        self.composer = Composer(self.cp_cv, look, comp_cb)
        self.ms_cv = tk.Canvas(right, bg=look.page, highlightthickness=0, bd=0)
        self.pane = MessagePane(self.ms_cv, look, dict(reply=cb.get("reply"), edit=cb.get("edit"), star=cb.get("star"),
                                                       delete=cb.get("delete")), empty=empty)
        self.ms_cv.pack(side="top", fill="both", expand=True)
        self._conv_open = False
        self.show_empty()

    # ----- layout toggles
    def _show_chrome(self, on):
        if on and not self._conv_open:
            self.ms_cv.pack_forget()
            self.hd_cv.pack(side="top", fill="x")
            self.cp_cv.pack(side="bottom", fill="x")
            self.ms_cv.pack(side="top", fill="both", expand=True)
            self._conv_open = True
        elif not on and self._conv_open:
            self.hd_cv.pack_forget()
            self.cp_cv.pack_forget()
            self._conv_open = False

    def show_empty(self):
        self._show_chrome(False)
        self.pane.show_empty()

    def open_conversation(self, title, subtitle="", kind="muted", dp=None, online=None, key=None, menu=None,
                          back=False, icon=None):
        self._show_chrome(True)
        self.header.set(title, subtitle, kind, dp, online, key, menu, back, icon)
        self.composer.clear()
        self.composer.clear_banner()

    # ----- list
    def _query(self, q):
        self.list_rows.set_rows(self.list_rows.rows, self.list_rows.sel, query=q)

    def set_contacts(self, rows, selected=None):
        self.list_header.count = len(rows)
        sig = [(r["id"], r["name"], r.get("online"), r.get("unread"), r.get("preview"), r.get("time"),
                r.get("typing"), r.get("icon")) for r in rows]
        if sig != getattr(self, "_sig", None) or selected != self.list_rows.sel:
            self._sig = sig
            self.list_header.refresh()
            self.list_rows.set_rows(rows, selected)

    def focus_search(self):
        self.list_header.entry.focus_set()

    # ----- messages
    def show_messages(self, msgs, stick="bottom", info=""):
        self.pane.show_messages(msgs, stick, info)

    def set_status(self, subtitle, kind="muted", online=None):
        self.header.set_status(subtitle, kind, online)
        self.pane.set_typing(kind == "typing")
