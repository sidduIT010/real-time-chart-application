NexaChat - Vibrant Violet Edition v9

Run:
1. Install Python 3.11+.
2. Install Pillow: python -m pip install Pillow
3. Open the chat_application folder in VS Code.
4. Run: python main.py

End-to-end product refresh:
- NexaChat branding: Connect • Chat • Grow.
- Redesigned login/authentication experience.
- Professional dashboard inspired by the selected #18 concept.
- Start Chatting screen with back navigation, search and modern empty state.
- Private chat keeps reply, edit, star, delete, block, image and typing features.
- My Groups refreshed with modern navigation and group chat flow.
- Status refreshed with Add Status and status viewing.
- Motivation Mode removed from the main navigation.
- Chat Analytics stays inside the same application window.
- Six curated themes: Ocean Blue, Midnight Aurora, Sunset Coral, Forest Mint, Royal Violet, Cyber Neon.
- New Settings screen for profile, theme, shortcuts, product features and logout.
- Theme selection is saved locally in nexachat_settings.json.
- Keyboard shortcuts: Ctrl+K focuses chat search; Esc returns to dashboard.
- Existing SQLite database and chat functionality retained.

v9 visual refresh:
- New indigo-to-violet brand palette across buttons, bubbles, sidebar and backgrounds.
- Rounder gradient buttons; Create Account uses teal for contrast.
- Login brand panel redesigned with deep violet gradient tones and floating chat-bubble art.
- Ocean Blue / Midnight Aurora theme accents updated to match.


=== v10 - Animated dashboard update ===
New files (chat_application/):
  fxkit.py        theme-aware graphics toolkit (glass cards, glow pills, Page base class)
  dashboard_fx.py animated sidebar + dashboard (all 6 themes, light and dark)
  pages_fx.py     animated Chat Analytics and Themes screens
Changed: fx.py (line_chart follows moving groups), main.py (dashboard/analytics/themes
use the new pages, quick fade between screens), ui_components.py (search + bell icons).
Run as before:  python main.py   (inside chat_application)


=== v11 - Redesigned Messages screen (Phase 1 of the full redesign) ===
New file (chat_application/):
  chat_fx.py      Canvas-drawn chat engine: conversation list with avatars / online dots / unread
                  badges, live chat header (status, in-chat search, menu), gradient message bubbles,
                  date pills, reply quotes, image bubbles with viewer, typing dots, floating composer
                  with reply / edit banner. Works in all 6 themes (light and dark).
Changed: main.py (private chat now uses ChatShell; dialogs in English).
Chat tips: double-click a message or press the hover arrow to reply; right-click for Copy / Edit /
           Star / Delete; click a reply quote to jump to the original message; click an image to enlarge.
Unchanged: database.py, dashboard, groups, status (these are redesigned in the next phases).
Backup of the previous private-chat code: chat_application_backup/


=== v11 - Phase 2: new Login / Create-account screen ===
New file (chat_application/): auth_fx.py
  - Animated brand hero (re-themed per selected theme) + glass card with Sign in / Create account tabs.
  - Inline validation and error banner (no more pop-ups): 3-20 char username, 6+ char password,
    confirm-password, duplicate-username message, password strength meter, Show/Hide, Caps Lock hint.
  - "Remember me" keeps your username in nexachat_settings.json.
Changed: main.py (auth callbacks), fx.py (hero background cache now respects the theme).


=== v11 - Phase 3: Groups redesigned ===
The Groups screen now runs on the same chat engine (chat_fx.py) as private chats:
  - Group list with people avatars, last message ("sasi: text"), time and member count.
  - Header shows "N members - M online"; menu: Group info & members, Leave group (non-admins).
  - Coloured sender names, gradient bubbles, date pills, search inside a group, copy / delete (own messages).
  - NEW: you can now send images in groups (attach button); creating a group opens it immediately.
  - Group popups (create group, members) are restyled in Phase 5.


=== v11 - Phase 4: Status and Settings redesigned ===
New files (chat_application/): status_fx.py, settings_fx.py
Status:
  - Story list with segmented story rings (grey = already viewed), "My status" card with updates / views.
  - Inline story viewer (no more black pop-up): progress bars, auto-advance (5 s text, 6.5 s photo),
    tap left/right, hold to pause, arrow keys, Space = pause, Esc = close.
  - Your own stories show view count + View details + Delete; other people's show a Message button.
  - Posting a status opens it immediately (no pop-up confirmation).
Settings:
  - Profile (change / remove photo), Appearance with live theme preview tiles (stays on Settings after
    switching), Shortcuts key-caps, Account (forget saved username, log out), About.
