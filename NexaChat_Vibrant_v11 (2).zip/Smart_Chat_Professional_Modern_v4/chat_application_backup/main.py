import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime, timedelta
from database import ChatDB
from ui_components import (
    AuthFrame, StyledButton, PRIMARY_COLOR, SUCCESS_COLOR, BG_COLOR, TEXT_COLOR,
    DEFAULT_CHAT_BG, PRIMARY_DARK, MUTED_TEXT, BORDER_COLOR, NOTIF_RED, get_palette,
    ChatBubble, UserListItem, DateHeader, SearchBar, EmojiPicker,
    CustomEntry, WhatsAppSendButton, ChatHeader, StarredMessagesPopup,
    GroupListItem, CreateGroupPopup, GroupMembersPopup,
    StatusAvatar, StatusListItem, MyStatusItem, StatusViewerPopup, AddStatusPopup,
    ReplyPreviewBar,   # NEW: Reply feature
    RoundedCard, StretchyRoundedCard, draw_round_rect, make_glow_rect_image, _blend, PRIMARY_LIGHT,   # NEW: shared design helpers
    DASH_FONT, DASH_PAGE, DASH_TEXT, DASH_MUTED, DASH_BLUE, DASH_INDIGO, DASH_RED,
    get_icon, make_dash_background_pil, make_sidebar_panel_pil, make_glass_card, make_gradient_rounded_image,
    make_sparkline, make_avatar, make_pill_image
)
from PIL import Image, ImageTk
import tkinter.font as tkfont
import os


class MainApp:
    def __init__(self, root):
        self.db = ChatDB()
        self.root = root
        self.root.title("NexaChat — Connect • Chat • Grow")
        self.root.geometry("450x600")
        self.root.configure(bg=BG_COLOR)
        
        self.current_user_id = None
        self.current_username = ""
        self.selected_recipient_id = None
        self.selected_group_id = None
        self.selected_group_name = None
        self.chat_mode = "private"
        self.all_users = [] 
        self.last_data_check = "" 
        self.typing_timer = None
        self.current_theme = "Ocean Blue"

        self.polling_active = False

        # --- Reply feature state ---
        # reply_target_id    : Right-click chesina original message id
        # reply_target_text  : Original message text (preview kosam)
        # reply_target_sender: Original sender name (preview kosam)
        self.reply_target_id = None
        self.reply_target_text = None
        self.reply_target_sender = None
        self._reply_preview_bar = None   # ReplyPreviewBar widget reference

        # --- Edit feature state ---
        # edit_target_id   : Edit chesayyala anukuntunna message id
        # edit_target_text : Original text (cancel chesthe restore kosam)
        self.edit_target_id = None
        self.edit_target_text = None
        self._edit_preview_bar = None    # Edit mode indicator bar widget

        self.container = tk.Frame(self.root, bg=BG_COLOR)
        self.container.pack(expand=True, fill="both")
        
        self.show_login_page()

    # ==================== GENERAL HELPERS ====================

    def clear_container(self):
        self.polling_active = False
        for widget in self.container.winfo_children():
            widget.destroy()

    # ==================== REPLY HELPERS ====================

    def handle_reply_click(self, msg_id):
        """
        User right-click → 'Reply' select chessinappudu call avutundi.
        DB nundi original message fetch chesi reply state set chestundi.
        """
        row = self.db.get_message_by_id(msg_id)
        if not row:
            return
        _, _, msg_text, sender_name = row
        self.reply_target_id = msg_id
        self.reply_target_text = msg_text
        self.reply_target_sender = sender_name
        self._show_reply_preview()

    def _show_reply_preview(self):
        """Input box paina ReplyPreviewBar show chestundi."""
        # Existing preview bar unte destroy cheyyadam
        if self._reply_preview_bar and self._reply_preview_bar.winfo_exists():
            self._reply_preview_bar.destroy()

        if not hasattr(self, 'input_frame') or not self.input_frame.winfo_exists():
            return

        self._reply_preview_bar = ReplyPreviewBar(
            self.input_frame,
            sender_name=self.reply_target_sender,
            message_text=self.reply_target_text,
            on_cancel=self.cancel_reply
        )
        # Input box ki paina pack cheyyadam
        self._reply_preview_bar.pack(fill="x", before=self.msg_entry, pady=(0, 4))

    def cancel_reply(self):
        """Reply cancel chessinappudu state clear chestundi."""
        self.reply_target_id = None
        self.reply_target_text = None
        self.reply_target_sender = None
        if self._reply_preview_bar and self._reply_preview_bar.winfo_exists():
            self._reply_preview_bar.destroy()
        self._reply_preview_bar = None

    def scroll_to_message(self, msg_id):
        """
        Reply preview click chessinappudu original message ki scroll chestundi.
        msg_id tho matching bubble widget ki scroll avutundi.
        """
        if not hasattr(self, 'canvas') or not self.canvas.winfo_exists():
            return
        if not hasattr(self, 'scrollable_frame') or not self.scrollable_frame.winfo_exists():
            return

        # scrollable_frame lo anni bubbles loop chesi msg_id match ainatidi find cheyyadam
        for widget in self.scrollable_frame.winfo_children():
            if hasattr(widget, 'msg_id') and widget.msg_id == msg_id:
                # Widget position calculate chesi canvas scroll cheyyadam
                self.root.update_idletasks()
                widget_y = widget.winfo_y()
                canvas_height = self.canvas.winfo_height()
                scroll_region = self.canvas.bbox("all")
                if scroll_region:
                    total_height = scroll_region[3]
                    if total_height > 0:
                        fraction = max(0.0, (widget_y - canvas_height // 3) / total_height)
                        self.canvas.yview_moveto(fraction)
                        # Highlight effect — briefly change bubble bg
                        self._highlight_bubble(widget)
                break

    def _highlight_bubble(self, bubble_widget):
        """Original message bubble ni briefly highlight chestundi (WhatsApp style)."""
        try:
            bubble_widget.flash_highlight()
        except:
            pass

    # ==================== EDIT HELPERS ====================

    def handle_edit_click(self, msg_id, original_text):
        """
        User right-click → 'Edit' select chessinappudu call avutundi.
        Edit mode enter avutundi: input box lo original text load avutundi.
        """
        # Reply mode unte cancel cheyyadam (edit & reply simultaneously kadu)
        self.cancel_reply()

        self.edit_target_id = msg_id
        self.edit_target_text = original_text
        self._show_edit_bar()

        # Input box lo original text load cheyyadam
        self.msg_entry.delete(0, tk.END)
        self.msg_entry.entry.insert(0, original_text)
        self.msg_entry.entry.focus_set()
        # Cursor end ki move cheyyadam
        self.msg_entry.entry.icursor(tk.END)

    def _show_edit_bar(self):
        """Input box paina edit mode indicator bar show chestundi."""
        if self._edit_preview_bar and self._edit_preview_bar.winfo_exists():
            self._edit_preview_bar.destroy()

        if not hasattr(self, 'input_frame') or not self.input_frame.winfo_exists():
            return

        # Edit mode bar — yellow tint tho distinguish avutundi
        self._edit_preview_bar = tk.Frame(
            self.input_frame, bg="#FEF3C7",
            highlightbackground="#D97706", highlightthickness=1,
            padx=8, pady=4
        )
        self._edit_preview_bar.pack(fill="x", before=self.msg_entry, pady=(0, 4))

        # Left colored strip
        tk.Frame(self._edit_preview_bar, bg="#D97706", width=3).pack(side="left", fill="y", padx=(0, 8))

        info = tk.Frame(self._edit_preview_bar, bg="#FEF3C7")
        info.pack(side="left", fill="both", expand=True)

        tk.Label(info, text="✏️ Editing message", font=("Segoe UI", 9, "bold"),
                 bg="#FEF3C7", fg="#B45309").pack(anchor="w")

        preview = self.edit_target_text[:60] + "..." if len(self.edit_target_text) > 60 else self.edit_target_text
        tk.Label(info, text=preview, font=("Segoe UI", 9),
                 bg="#FEF3C7", fg="#6B7280").pack(anchor="w")

        # Cancel button
        tk.Button(self._edit_preview_bar, text="✕", font=("Segoe UI", 10, "bold"),
                  bg="#FEF3C7", fg="#6B7280", bd=0, cursor="hand2",
                  command=self.cancel_edit).pack(side="right", padx=5)

    def cancel_edit(self):
        """Edit mode cancel chestundi — input box clear avutundi."""
        self.edit_target_id = None
        self.edit_target_text = None
        if self._edit_preview_bar and self._edit_preview_bar.winfo_exists():
            self._edit_preview_bar.destroy()
        self._edit_preview_bar = None
        # Input box clear cheyyadam
        if hasattr(self, 'msg_entry') and self.msg_entry.winfo_exists():
            self.msg_entry.delete(0, tk.END)



    def _on_mousewheel(self, event, canvas):
        canvas.yview_scroll(int(-1*(event.delta/120)), "units")

    def upload_profile_pic(self):
        file_path = filedialog.askopenfilename(
            title="Select Profile Picture",
            filetypes=[("Image files", "*.jpg *.png *.jpeg")]
        )
        if file_path:
            try:
                if self.db.update_user_dp(self.current_user_id, file_path):
                    messagebox.showinfo("Success", "Profile Picture Updated!")
                    self.show_dashboard() 
                else:
                    messagebox.showerror("Error", "Failed to update DP.")
            except: pass

    def handle_star_toggle(self, msg_id):
        if self.db.toggle_star_message(msg_id):
            self.refresh_messages(force=True)
        else:
            messagebox.showerror("Error", "Star status update cheyadam kudiraledu.")

    def open_starred_messages(self):
        starred_data = self.db.get_starred_messages(self.current_user_id)
        StarredMessagesPopup(self.root, starred_data, PRIMARY_COLOR)

    # ==================================================================
    #  DASHBOARD — drawn on two canvases (sidebar + content) so glass
    #  cards, vector icons and the pastel wave backdrop can blend
    #  (plain Tk widgets cannot be transparent). Same data, same buttons,
    #  same click actions as before — only the visuals changed.
    # ==================================================================
    def show_dashboard(self):
        """Professional modern dashboard inspired by the selected design (#18)."""
        self.clear_container()
        self.root.geometry("1240x760")
        self.root.minsize(1050, 680)
        self.selected_recipient_id = None
        self.selected_group_id = None
        self.chat_mode = "private"

        self.db.cleanup_expired_statuses()
        data = self._dash_collect()

        # Theme palette — selected from the in-app Themes page.
        palettes = {
            "Ocean Blue": {"PAGE":"#F5F8FC","NAV":"#FFFFFF","NAV_BORDER":"#E6ECF5","TEXT":"#10233F","MUTED":"#72819A","BLUE":"#2563EB","BLUE2":"#3B82F6","CYAN":"#06B6D4","PURPLE":"#7C3AED","GREEN":"#10B981","PINK":"#EC4899","RED":"#EF4444","LINE":"#E8EEF6","WHITE":"#FFFFFF"},
            "Midnight Aurora": {"PAGE":"#08111F","NAV":"#0D1728","NAV_BORDER":"#22324A","TEXT":"#F8FAFC","MUTED":"#A7B4C7","BLUE":"#38BDF8","BLUE2":"#0EA5E9","CYAN":"#22D3EE","PURPLE":"#8B5CF6","GREEN":"#34D399","PINK":"#F472B6","RED":"#FB7185","LINE":"#263852","WHITE":"#111C2E"},
            "Sunset Coral": {"PAGE":"#FFF7F2","NAV":"#FFFFFF","NAV_BORDER":"#F5DDD2","TEXT":"#3B1D2A","MUTED":"#80616B","BLUE":"#F97316","BLUE2":"#FB7185","CYAN":"#F59E0B","PURPLE":"#EC4899","GREEN":"#10B981","PINK":"#E11D48","RED":"#DC2626","LINE":"#F1DDD5","WHITE":"#FFFFFF"},
            "Forest Mint": {"PAGE":"#F2FBF7","NAV":"#FFFFFF","NAV_BORDER":"#D8EEE6","TEXT":"#12352D","MUTED":"#648078","BLUE":"#059669","BLUE2":"#10B981","CYAN":"#14B8A6","PURPLE":"#0F766E","GREEN":"#16A34A","PINK":"#2DD4BF","RED":"#EF4444","LINE":"#DDEEE8","WHITE":"#FFFFFF"},
            "Royal Violet": {"PAGE":"#F8F5FF","NAV":"#FFFFFF","NAV_BORDER":"#E9DFFF","TEXT":"#24134A","MUTED":"#756A8D","BLUE":"#7C3AED","BLUE2":"#8B5CF6","CYAN":"#6366F1","PURPLE":"#4F46E5","GREEN":"#10B981","PINK":"#D946EF","RED":"#EF4444","LINE":"#E9DFFF","WHITE":"#FFFFFF"},
            "Cyber Neon": {"PAGE":"#080B16","NAV":"#0C1020","NAV_BORDER":"#25304A","TEXT":"#F8FAFC","MUTED":"#9AA6BD","BLUE":"#22D3EE","BLUE2":"#06B6D4","CYAN":"#67E8F9","PURPLE":"#A855F7","GREEN":"#34D399","PINK":"#F43F5E","RED":"#FB7185","LINE":"#25304A","WHITE":"#111827"},
        }
        P = palettes.get(self.current_theme, palettes["Ocean Blue"])
        PAGE,NAV,NAV_BORDER,TEXT,MUTED,BLUE,BLUE2,CYAN,PURPLE,GREEN,PINK,RED,LINE,WHITE = [P[k] for k in ("PAGE","NAV","NAV_BORDER","TEXT","MUTED","BLUE","BLUE2","CYAN","PURPLE","GREEN","PINK","RED","LINE","WHITE")]

        shell = tk.Frame(self.container, bg=PAGE)
        shell.pack(fill="both", expand=True)
        side = tk.Canvas(shell, width=222, bg=NAV, highlightthickness=0, bd=0)
        side.pack(side="left", fill="y")
        content = tk.Canvas(shell, bg=PAGE, highlightthickness=0, bd=0)
        content.pack(side="left", fill="both", expand=True)
        self._dash_canvas = content

        st = {"side": side, "content": content, "data": data, "imgs_side": [], "imgs_content": [],
              "hits": {"side": [], "content": []}, "hover": {"side": None, "content": None},
              "jobs": {}, "blocked_box": None}
        self._dash = st
        self._dash_bind_hits("side")
        self._dash_bind_hits("content")

        def schedule(kind, fn):
            job = st["jobs"].get(kind)
            if job:
                try: self.root.after_cancel(job)
                except Exception: pass
            st["jobs"][kind] = self.root.after(30, fn)

        side.bind("<Configure>", lambda e: schedule("side", self._dash_draw_sidebar))
        content.bind("<Configure>", lambda e: schedule("content", self._dash_draw_content))

        def _dash_scroll(event):
            try:
                content.yview_scroll(int(-1 * (event.delta / 120)), "units")
            except Exception:
                pass
        content.bind_all("<MouseWheel>", _dash_scroll)
        shell.bind("<Destroy>", lambda e: content.unbind_all("<MouseWheel>") if e.widget is shell else None)

        # Drawers below are replaced with professional versions for this screen.
        self._dash_prof_palette = {
            "PAGE": PAGE, "NAV": NAV, "NAV_BORDER": NAV_BORDER, "TEXT": TEXT, "MUTED": MUTED,
            "BLUE": BLUE, "BLUE2": BLUE2, "CYAN": CYAN, "PURPLE": PURPLE, "GREEN": GREEN,
            "PINK": PINK, "RED": RED, "LINE": LINE, "WHITE": WHITE
        }

    def _dash_collect(self):
        uid = self.current_user_id
        d = {"username": self.current_username}
        d["status_count"] = self._get_unread_statuses_count()
        try:
            d["has_dp"] = bool(self.db.get_user_dp(uid))
            d["dp_ok"] = True
        except Exception:
            d["has_dp"], d["dp_ok"] = False, False
        try:
            msgs = self.db.get_analytics_messages(uid)
            d["sent"] = sum(1 for m in msgs if m[0] == uid)
        except Exception:
            d["sent"] = 0
        try:
            d["groups"] = len(self.db.get_user_groups(uid))
        except Exception:
            d["groups"] = 0
        try:
            d["status_updates"] = self.db.get_status_count(uid)
        except Exception:
            d["status_updates"] = 0
        try:
            contacts = self.db.get_analytics_contacts(uid)[:6]
        except Exception:
            contacts = []
        d["recent"] = [(cid, uname, (sent or 0) + (received or 0), self._dash_last_time(cid))
                       for cid, uname, sent, received in contacts]
        return d

    def _dash_last_time(self, contact_id):
        """'2 hours ago' style hint for the Recent Chats rows (display only)."""
        try:
            hist = self.db.get_chat_history(self.current_user_id, contact_id)
            if not hist:
                return ""
            t = datetime.strptime(str(hist[-1][2]).replace("T", " ")[:19], "%Y-%m-%d %H:%M:%S")
            secs = max(0, int((datetime.now() - t).total_seconds()))
            if secs < 60:
                return "just now"
            if secs < 3600:
                n = secs // 60
                return f"{n} minute{'s' if n != 1 else ''} ago"
            if secs < 86400:
                n = secs // 3600
                return f"{n} hour{'s' if n != 1 else ''} ago"
            if secs < 7 * 86400:
                n = secs // 86400
                return f"{n} day{'s' if n != 1 else ''} ago"
            return t.strftime("%d %b")
        except Exception:
            return ""

    # ---- click / hover handling for canvas-drawn controls ----
    def _dash_bind_hits(self, key):
        st = self._dash
        cv = st["side"] if key == "side" else st["content"]

        def find(event):
            x, y = cv.canvasx(event.x), cv.canvasy(event.y)
            for r in st["hits"][key]:
                x1, y1, x2, y2 = r["box"]
                if x1 <= x <= x2 and y1 <= y <= y2:
                    return r
            return None

        def set_hover(r):
            cur = st["hover"][key]
            if r is cur:
                return
            try:
                if cur and cur["hover"] is not None:
                    cv.itemconfigure(cur["hover"], state="hidden")
                if r and r["hover"] is not None:
                    cv.itemconfigure(r["hover"], state="normal")
                cv.configure(cursor="hand2" if r else "")
            except tk.TclError:
                pass
            st["hover"][key] = r

        def click(event):
            r = find(event)
            if r and r["cb"]:
                r["cb"]()

        cv.bind("<Motion>", lambda e: set_hover(find(e)))
        cv.bind("<Leave>", lambda e: set_hover(None))
        cv.bind("<Button-1>", click)


    def _dash_draw_sidebar(self):
        st = getattr(self, "_dash", None)
        if not st: return
        cv = st["side"]
        if not cv.winfo_exists(): return
        W, H = cv.winfo_width(), cv.winfo_height()
        if W < 100 or H < 200: return
        C = self._dash_prof_palette
        d = st["data"]
        cv.delete("all"); st["hits"]["side"] = []; st["hover"]["side"] = None
        imgs=[]
        def keep(x): imgs.append(x); return x

        cv.create_rectangle(0,0,W,H,fill=C["NAV"],outline="")
        cv.create_line(W-1,0,W-1,H,fill=C["NAV_BORDER"])

        # Brand
        cv.create_image(24,28,image=keep(make_avatar(38,C["BLUE2"],C["PURPLE"])))
        cv.create_image(43,47,image=keep(get_icon("chat",19,"#FFFFFF")))
        cv.create_text(72,30,anchor="nw",text="NexaChat",font=(DASH_FONT,12,"bold"),fill=C["TEXT"])
        cv.create_text(72,49,anchor="nw",text="Connect • Chat • Grow",font=(DASH_FONT,8),fill=C["MUTED"])

        cv.create_text(24,98,anchor="w",text="MAIN MENU",font=(DASH_FONT,8,"bold"),fill="#9AA8BB")
        x1,x2=12,W-12; row_h=42; y=126
        def row(icon,label,cb,active=False,badge=None):
            if active:
                bg=make_gradient_rounded_image(x2-x1,row_h,12,C["BLUE2"],C["BLUE"],255)
                cv.create_image(x1,y-row_h/2,anchor="nw",image=keep(bg))
            else:
                hov=draw_round_rect(cv,x1,y-row_h/2,x2,y+row_h/2,12,fill="#EFF6FF",outline="",state="hidden")
            ico=get_icon(icon,19,"#FFFFFF" if active else C["MUTED"])
            cv.create_image(x1+22,y,image=keep(ico))
            cv.create_text(x1+44,y,anchor="w",text=label,font=(DASH_FONT,10,"bold" if active else "normal"),fill=C["WHITE"] if active else C["TEXT"])
            if badge:
                cv.create_oval(x2-25,y-8,x2-9,y+8,fill=C["RED"],outline="")
                cv.create_text(x2-17,y,text=str(badge),font=(DASH_FONT,7,"bold"),fill=C["WHITE"])
            st["hits"]["side"].append({"box":(x1,y-row_h/2,x2,y+row_h/2),"cb":cb,"hover":None if active else hov})
        nav=[
            ("home","Dashboard",None,True,None),
            ("chat","Start Chatting",self.show_chat_screen,False,None),
            ("people","My Groups",self.show_groups_screen,False,None),
            ("status","Status",self.show_status_screen,False,d["status_count"] or None),
            ("bars","Chat Analytics",self.open_chat_analytics,False,None),
            ("star","Starred Messages",self.open_starred_messages,False,None),
            ("sun","Themes",self.show_themes_screen,False,None),
        ]
        for item in nav:
            row(*item); y+=48
        cv.create_line(20,y-15,W-20,y-15,fill=C["LINE"])
        cv.create_text(24,y+8,anchor="w",text="ACCOUNT",font=(DASH_FONT,8,"bold"),fill="#9AA8BB")
        row("user","Profile",lambda: self.upload_profile_pic(),False,None); y+=48
        row("power","Logout",self.handle_logout,False,None)
        st["imgs_side"]=imgs

    def _dash_draw_content(self):
        st=getattr(self,"_dash",None)
        if not st: return
        cv=st["content"]
        if not cv.winfo_exists(): return
        W,H=cv.winfo_width(),cv.winfo_height()
        if W<500 or H<250: return
        C=self._dash_prof_palette; d=st["data"]; F=DASH_FONT
        imgs=[]
        def keep(x): imgs.append(x); return x
        cv.delete("all"); st["hits"]["content"]=[]; st["hover"]["content"]=None
        m=24; right_w=245; gap=18; main_w=W-2*m-right_w-gap; right_x=m+main_w+gap
        # A clean, very light background with subtle blue glow bands.
        cv.create_rectangle(0,0,W,max(H,760),fill=C["PAGE"],outline="")
        cv.create_oval(W-260,-110,W+120,260,fill="#EAF2FF",outline="")
        cv.create_oval(-130,H-190,260,H+80,fill="#EEF7FF",outline="")
        cv.configure(scrollregion=(0,0,W,max(H,760)))

        def card(x,y,w,h,fill=C["WHITE"],outline=C["LINE"],r=16):
            draw_round_rect(cv,x,y,x+w,y+h,r,fill=fill,outline=outline,width=1)
        def text(x,y,s,size=10,weight="normal",fill=None,anchor="nw"):
            cv.create_text(x,y,anchor=anchor,text=s,font=(F,size,weight),fill=fill or C["TEXT"])

        # Header / search
        text(m,22,"Welcome back,",12,"bold",C["MUTED"])
        tw=text
        name_x=m+tkfont.Font(family=F,size=12,weight="bold").measure("Welcome back, ")+5
        text(name_x,22,f"{d['username']}!",12,"bold",C["TEXT"])
        text(m,47,"Stay connected. Build stronger relationships.",9,"normal",C["MUTED"])
        search_w=min(300,max(220,main_w//3))
        sx=m+main_w-search_w
        card(sx,18,search_w,38,C["WHITE"],C["LINE"],19)
        cv.create_image(sx+19,37,image=keep(get_icon("search",16,C["MUTED"])))
        text(sx+38,37,"Search conversations...",9,"normal",C["MUTED"],"w")
        cv.create_oval(sx+search_w+10,27,sx+search_w+40,57,fill=C["WHITE"],outline=C["LINE"])
        cv.create_image(sx+search_w+25,42,image=keep(get_icon("bell",15,C["BLUE"])))

        # Stats
        y=92; stat_gap=12; stat_w=(main_w-2*stat_gap)/3; stat_h=94
        stats=[("chat","Messages",d["sent"],C["BLUE"],"#EFF6FF"),("people","Groups",d["groups"],C["GREEN"],"#ECFDF5"),("megaphone","Status",d["status_updates"],C["PURPLE"],"#F5F3FF")]
        for i,(icon,label,val,accent,bg) in enumerate(stats):
            x=m+i*(stat_w+stat_gap); card(x,y,stat_w,stat_h,C["WHITE"],C["LINE"],15)
            cv.create_oval(x+16,y+17,x+50,y+51,fill=bg,outline="")
            cv.create_image(x+33,y+34,image=keep(get_icon(icon,17,accent)))
            text(x+16,y+63,str(val),18,"bold",C["TEXT"])
            text(x+53,y+64,label,9,"normal",C["MUTED"])
            text(x+stat_w-16,y+20,"+0%",8,"bold",accent,"ne")

        # Recent conversations
        body_y=y+112
        recent_h=300
        card(m,body_y,main_w,recent_h,C["WHITE"],C["LINE"],16)
        text(m+18,body_y+20,"Recent Conversations",11,"bold",C["TEXT"])
        text(m+main_w-18,body_y+20,"View all  →",9,"bold",C["BLUE"],"ne")
        st["hits"]["content"].append({"box":(m+main_w-100,body_y+4,m+main_w-8,body_y+38),"cb":self.show_chat_screen,"hover":None})
        cv.create_line(m+18,body_y+48,m+main_w-18,body_y+48,fill=C["LINE"])
        rows=d["recent"][:5]
        av=[(C["BLUE2"],C["BLUE"]),(C["GREEN"],C["CYAN"]),(C["PURPLE"],C["PINK"]),("#F59E0B","#EF4444"),("#06B6D4",C["BLUE"])]
        if rows:
            for i,(cid,uname,cnt,ago) in enumerate(rows):
                ry=body_y+66+i*47
                if i>0: cv.create_line(m+72,ry-9,m+main_w-18,ry-9,fill=C["LINE"])
                c1,c2=av[i%len(av)]
                cv.create_image(m+39,ry+20,image=keep(make_avatar(38,c1,c2)))
                text(m+39,ry+20,(uname or "?")[0].upper(),12,"bold",C["WHITE"],"center")
                text(m+68,ry+8,uname,10,"bold",C["TEXT"])
                text(m+68,ry+27,f"{cnt} messages",8,"normal",C["MUTED"])
                if ago: text(m+main_w-42,ry+15,ago,8,"normal",C["MUTED"],"e")
                cv.create_image(m+main_w-18,ry+20,image=keep(get_icon("chevron",11,C["MUTED"])))
                st["hits"]["content"].append({"box":(m+8,ry,m+main_w-8,ry+40),"cb":(lambda c=cid,n=uname:self._open_chat_with(c,n)),"hover":None})
        else:
            cv.create_image(m+main_w/2,body_y+155,image=keep(make_avatar(64,"#DBEAFE","#93C5FD")))
            cv.create_image(m+main_w/2,body_y+155,image=keep(get_icon("chat",28,C["BLUE"])))
            text(m+main_w/2,body_y+205,"No conversations yet",12,"bold",C["TEXT"],"center")
            text(m+main_w/2,body_y+226,"Start chatting to connect with friends.",9,"normal",C["MUTED"],"center")

        # Right profile / quick actions panel — key part of selected #18 design.
        card(right_x,18,right_w,178,C["WHITE"],C["LINE"],18)
        text(right_x+18,40,"Profile",10,"bold",C["TEXT"])
        text(right_x+right_w-18,40,"›",16,"normal",C["BLUE"],"ne")
        cv.create_image(right_x+right_w/2,91,image=keep(make_avatar(70,C["BLUE2"],C["PURPLE"])))
        text(right_x+right_w/2,91,(d["username"] or "?")[0].upper(),22,"bold",C["WHITE"],"center")
        text(right_x+right_w/2,137,d["username"],11,"bold",C["TEXT"],"center")
        cv.create_oval(right_x+right_w/2-5,155,right_x+right_w/2+5,165,fill=C["GREEN"],outline="")
        text(right_x+right_w/2+10,160,"Online",8,"bold",C["GREEN"],"w")
        bx=right_x+18; by=174
        # profile update button below profile card
        card(right_x,208,right_w,48,C["WHITE"],C["LINE"],13)
        cv.create_image(right_x+28,232,image=keep(get_icon("image",16,C["BLUE"])))
        text(right_x+48,232,"Update Profile Picture",9,"bold",C["BLUE"],"w")
        st["hits"]["content"].append({"box":(right_x,208,right_x+right_w,256),"cb":self.upload_profile_pic,"hover":None})

        card(right_x,270,right_w,48,"#FFFBEB","#FDE68A",13)
        cv.create_image(right_x+27,294,image=keep(get_icon("star",17,"#F59E0B")))
        text(right_x+48,294,"Starred Messages",9,"bold","#B45309","w")
        text(right_x+right_w-18,294,"›",16,"normal","#B45309","e")
        st["hits"]["content"].append({"box":(right_x,270,right_x+right_w,318),"cb":self.open_starred_messages,"hover":None})

        # Quick actions
        text(right_x,350,"Quick Actions",10,"bold",C["TEXT"])
        actions=[("chat","New Chat",self.show_chat_screen,C["BLUE"]),("people","Create Group",self.show_groups_screen,C["PURPLE"]),("user","View Profile",self.upload_profile_pic,C["CYAN"])]
        ay=372
        for icon,label,cb,accent in actions:
            card(right_x,ay,right_w,44,C["WHITE"],C["LINE"],12)
            cv.create_image(right_x+24,ay+22,image=keep(get_icon(icon,16,accent)))
            text(right_x+44,ay+22,label,9,"bold",C["TEXT"],"w")
            text(right_x+right_w-16,ay+22,"›",14,"normal",C["MUTED"],"e")
            st["hits"]["content"].append({"box":(right_x,ay,right_x+right_w,ay+44),"cb":cb,"hover":None})
            ay+=52

        # Friendly footer tagline
        fy=max(body_y+recent_h+40,H-70)
        text(m,fy,"Better conversations.  Real connections.",9,"normal",C["MUTED"])
        text(m+main_w,fy,"Smart Chat • Secure • Modern",8,"bold",C["BLUE"],"e")
        st["imgs_content"]=imgs

    def _open_chat_with(self, recipient_id, recipient_name):
        """Real navigation shortcut: opens the existing chat screen straight into a conversation."""
        self.show_chat_screen()
        self.load_user_chat(recipient_id, recipient_name)

    def _get_unread_statuses_count(self):
        try:
            users_with_statuses = self.db.get_users_with_statuses(self.current_user_id)
            return sum(row[5] for row in users_with_statuses if row[5] > 0)
        except:
            return 0

    # ==================== MOTIVATION MODE ====================

    def open_motivation_mode(self):
        """Dashboard nundi Motivation Mode popup open chestundi."""
        from ui_components import MotivationModePopup
        MotivationModePopup(self.root, self.current_user_id, self.db)

    # ==================== CHAT ANALYTICS ====================

    def open_chat_analytics(self):
        """Open analytics inside the main application window (not a separate popup)."""
        self.show_analytics_screen()

    def show_analytics_screen(self):
        self.clear_container()
        self.root.geometry("1120x720")
        self.root.minsize(950, 650)
        bg = "#F5F8FC"
        blue = "#2563EB"
        text = "#10233F"
        muted = "#72819A"
        card = "#FFFFFF"
        line = "#E6ECF5"

        top = tk.Frame(self.container, bg=card, height=76, highlightbackground=line, highlightthickness=1)
        top.pack(fill="x")
        tk.Button(top, text="←  Back to Dashboard", command=self.show_dashboard, bd=0, bg=card, fg=blue,
                  font=("Segoe UI", 10, "bold"), cursor="hand2").pack(side="left", padx=22)
        tk.Label(top, text="Chat Analytics", bg=card, fg=text, font=("Segoe UI", 18, "bold")).pack(side="left", padx=20)
        tk.Label(top, text="Your conversation activity at a glance", bg=card, fg=muted,
                 font=("Segoe UI", 9)).pack(side="left")

        body = tk.Frame(self.container, bg=bg)
        body.pack(fill="both", expand=True, padx=24, pady=24)
        msgs = self.db.get_analytics_messages(self.current_user_id)
        contacts = self.db.get_analytics_contacts(self.current_user_id)
        sent = sum(1 for m in msgs if m[0] == self.current_user_id)
        received = len(msgs) - sent
        active = len(contacts)
        total = len(msgs)

        def metric(parent, title, value, subtitle, accent):
            f = tk.Frame(parent, bg=card, highlightbackground=line, highlightthickness=1)
            f.pack(side="left", fill="both", expand=True, padx=7)
            tk.Frame(f, bg=accent, width=5).pack(side="left", fill="y")
            inner = tk.Frame(f, bg=card, padx=16, pady=14); inner.pack(fill="both", expand=True)
            tk.Label(inner, text=title, bg=card, fg=muted, font=("Segoe UI", 9, "bold")).pack(anchor="w")
            tk.Label(inner, text=str(value), bg=card, fg=text, font=("Segoe UI", 22, "bold")).pack(anchor="w", pady=(4,0))
            tk.Label(inner, text=subtitle, bg=card, fg=muted, font=("Segoe UI", 8)).pack(anchor="w")

        metrics = tk.Frame(body, bg=bg); metrics.pack(fill="x", pady=(0,18))
        metric(metrics, "Total Messages", total, "Text messages in your chats", blue)
        metric(metrics, "Messages Sent", sent, "Messages you sent", "#10B981")
        metric(metrics, "Messages Received", received, "Messages from contacts", "#7C3AED")
        metric(metrics, "Active Contacts", active, "People you've chatted with", "#F59E0B")

        lower = tk.Frame(body, bg=bg); lower.pack(fill="both", expand=True)
        left = tk.Frame(lower, bg=card, highlightbackground=line, highlightthickness=1); left.pack(side="left", fill="both", expand=True, padx=(0,9))
        right = tk.Frame(lower, bg=card, highlightbackground=line, highlightthickness=1, width=340); right.pack(side="right", fill="both", padx=(9,0))
        tk.Label(left, text="Top Conversations", bg=card, fg=text, font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=18, pady=(18,10))
        if contacts:
            for i,(cid,name,sc,rc) in enumerate(contacts[:8],1):
                row=tk.Frame(left,bg=card); row.pack(fill="x", padx=18, pady=6)
                tk.Label(row,text=f"{i}",width=3,bg="#EFF6FF",fg=blue,font=("Segoe UI",9,"bold")).pack(side="left")
                tk.Label(row,text=name,bg=card,fg=text,font=("Segoe UI",10,"bold")).pack(side="left",padx=10)
                tk.Label(row,text=f"{(sc or 0)+(rc or 0)} messages",bg=card,fg=muted,font=("Segoe UI",9)).pack(side="right")
        else:
            tk.Label(left,text="Start a conversation to see analytics here.",bg=card,fg=muted,font=("Segoe UI",10)).pack(expand=True)
        tk.Label(right, text="Smart Insights", bg=card, fg=text, font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=18, pady=(18,10))
        insights=[
            ("💬", f"You have {total} text messages recorded."),
            ("↗", f"You sent {sent} and received {received} messages."),
            ("👥", f"You have chatted with {active} contact(s)."),
            ("✨", "Keep conversations active to build a richer activity history."),
        ]
        for icon,msg in insights:
            r=tk.Frame(right,bg="#F8FAFC",padx=10,pady=10); r.pack(fill="x",padx=16,pady=5)
            tk.Label(r,text=icon,bg="#F8FAFC",font=("Segoe UI",13)).pack(side="left")
            tk.Label(r,text=msg,bg="#F8FAFC",fg=text,wraplength=250,justify="left",font=("Segoe UI",9)).pack(side="left",padx=8)

    def show_themes_screen(self):
        self.clear_container()
        self.root.geometry("1050x720")
        self.root.minsize(900, 650)
        bg="#F5F8FC"; text="#10233F"; muted="#72819A"; blue="#2563EB"; card="#FFFFFF"; line="#E6ECF5"
        header=tk.Frame(self.container,bg=card,height=78,highlightbackground=line,highlightthickness=1); header.pack(fill="x")
        tk.Button(header,text="←  Back to Dashboard",command=self.show_dashboard,bd=0,bg=card,fg=blue,font=("Segoe UI",10,"bold"),cursor="hand2").pack(side="left",padx=22)
        tk.Label(header,text="Themes",bg=card,fg=text,font=("Segoe UI",18,"bold")).pack(side="left",padx=20)
        tk.Label(header,text="Choose a look that matches your style",bg=card,fg=muted,font=("Segoe UI",9)).pack(side="left")
        body=tk.Frame(self.container,bg=bg); body.pack(fill="both",expand=True,padx=26,pady=24)
        themes=[
            ("Ocean Blue","#F5F8FC","#2563EB","#7C3AED","#10233F","#72819A","Clean professional"),
            ("Midnight Aurora","#08111F","#38BDF8","#8B5CF6","#F8FAFC","#A7B4C7","Dark glass & neon"),
            ("Sunset Coral","#FFF7F2","#F97316","#EC4899","#3B1D2A","#80616B","Warm and energetic"),
            ("Forest Mint","#F2FBF7","#059669","#14B8A6","#12352D","#648078","Fresh and calm"),
            ("Royal Violet","#F8F5FF","#7C3AED","#4F46E5","#24134A","#756A8D","Elegant and creative"),
            ("Cyber Neon","#080B16","#22D3EE","#F43F5E","#F8FAFC","#9AA6BD","Futuristic and bold"),
        ]
        for idx,t in enumerate(themes):
            name,page,accent1,accent2,fg,muted2,desc=t
            r,c=divmod(idx,2)
            box=tk.Frame(body,bg=card,highlightbackground=line,highlightthickness=1,cursor="hand2")
            box.grid(row=r,column=c,sticky="nsew",padx=9,pady=9,ipadx=12,ipady=12)
            preview=tk.Canvas(box,width=270,height=110,bg=page,highlightthickness=0); preview.pack(fill="x")
            preview.create_rectangle(0,0,58,110,fill=accent2,outline="")
            preview.create_rectangle(74,18,250,43,fill=accent1,outline="")
            preview.create_rectangle(74,54,170,92,fill="#FFFFFF" if page.startswith("#F") else "#142033",outline="")
            preview.create_oval(188,57,235,104,fill=accent2,outline="")
            tk.Label(box,text=name,bg=card,fg=fg,font=("Segoe UI",11,"bold")).pack(anchor="w",pady=(10,2))
            tk.Label(box,text=desc,bg=card,fg=muted2,font=("Segoe UI",8)).pack(anchor="w")
            cmd=lambda n=name:self.apply_theme(n)
            for w in (box,preview): w.bind("<Button-1>",lambda e,cb=cmd:cb())
            for child in box.winfo_children(): child.bind("<Button-1>",lambda e,cb=cmd:cb())
        body.grid_columnconfigure(0,weight=1); body.grid_columnconfigure(1,weight=1)
        for r in range(3): body.grid_rowconfigure(r,weight=1)

    def apply_theme(self, theme_name):
        self.current_theme = theme_name
        self.show_dashboard()

    def show_status_screen(self):
        self.clear_container()
        self.root.geometry("850x650")

        self.db.cleanup_expired_statuses()

        paned = tk.PanedWindow(self.container, orient="horizontal", bg="#F3F4FA", bd=0)
        paned.pack(fill="both", expand=True)

        self.status_left = tk.Frame(paned, bg="white", width=300)
        paned.add(self.status_left)

        header = tk.Frame(self.status_left, bg="#2563EB", pady=12)
        header.pack(fill="x")
        tk.Label(header, text="📢 Status", font=("Segoe UI", 13, "bold"),
                 bg="#2563EB", fg="white").pack(side="left", padx=15)
        tk.Button(header, text="← Back", font=("Segoe UI", 9), bg="white",
                  fg="#2563EB", bd=0, cursor="hand2", padx=8, pady=3,
                  command=self.show_dashboard).pack(side="right", padx=10)

        left_canvas = tk.Canvas(self.status_left, bg="white", highlightthickness=0)
        left_scroll = tk.Scrollbar(self.status_left, orient="vertical", command=left_canvas.yview)
        self.status_list_frame = tk.Frame(left_canvas, bg="white")
        self.status_list_frame.bind("<Configure>",
            lambda e: left_canvas.configure(scrollregion=left_canvas.bbox("all")))
        left_canvas.create_window((0, 0), window=self.status_list_frame, anchor="nw", width=280)
        left_canvas.configure(yscrollcommand=left_scroll.set)
        left_canvas.pack(side="left", fill="both", expand=True)
        left_scroll.pack(side="right", fill="y")

        self.status_right = tk.Frame(paned, bg="#F3F4FA")
        paned.add(self.status_right)

        self._status_right_welcome()
        self.load_status_list()

    def _status_right_welcome(self):
        for w in self.status_right.winfo_children():
            w.destroy()
        tk.Label(self.status_right, text="◉", font=("Segoe UI", 42), fg="#2563EB", bg="#F3F6FB").pack(pady=(100,4))
        tk.Label(self.status_right, text="Share a moment", font=("Segoe UI", 18, "bold"), fg="#10233F", bg="#F3F6FB").pack()
        tk.Label(self.status_right, text="Post an update or select a contact's status to view it.", font=("Segoe UI", 10), fg="#72819A", bg="#F3F6FB").pack(pady=8)
        tk.Button(self.status_right, text="＋  Add Status", command=self.open_add_status_popup, bg="#2563EB", fg="white", bd=0, padx=18, pady=9, font=("Segoe UI", 9, "bold"), cursor="hand2").pack(pady=10)

    def load_status_list(self):
        for w in self.status_list_frame.winfo_children():
            w.destroy()

        tk.Label(self.status_list_frame, text="My Status", font=("Segoe UI", 9, "bold"),
                 bg="white", fg="#6B7280", padx=12, pady=6).pack(anchor="w", fill="x")

        my_statuses = self.db.get_my_statuses(self.current_user_id)
        my_dp = self.db.get_user_dp(self.current_user_id)

        my_item = MyStatusItem(
            self.status_list_frame,
            username=self.current_username,
            profile_pic=my_dp,
            status_count=len(my_statuses),
            add_command=self.open_add_status_popup,
            view_command=lambda: self.view_my_statuses(my_statuses)
        )
        my_item.pack(fill="x")

        users_with_statuses = self.db.get_users_with_statuses(self.current_user_id)

        if users_with_statuses:
            tk.Label(self.status_list_frame, text="Recent Updates", font=("Segoe UI", 9, "bold"),
                     bg="white", fg="#6B7280", padx=12, pady=6).pack(anchor="w", fill="x")

            for uid, uname, dp, st_count, latest_time, unviewed_count in users_with_statuses:
                item = StatusListItem(
                    self.status_list_frame,
                    username=uname,
                    latest_time=latest_time or "",
                    profile_pic=dp or "",
                    has_unviewed=unviewed_count > 0,
                    status_count=st_count,
                    command=lambda u=uid, n=uname: self.view_contact_statuses(u, n)
                )
                item.pack(fill="x")
        else:
            tk.Label(self.status_list_frame, text="No recent updates",
                     font=("Segoe UI", 10, "italic"), bg="white", fg="#6B7280",
                     pady=20).pack()

    def open_add_status_popup(self):
        AddStatusPopup(self.root, self.handle_post_status)

    def handle_post_status(self, content, status_type, file_path, bg_color, font_size):
        sid = self.db.post_status(
            self.current_user_id,
            content=content,
            status_type=status_type,
            file_path=file_path,
            bg_color=bg_color,
            font_size=font_size
        )
        if sid:
            messagebox.showinfo("Success", "Status post ayyindi! 24 gantallo expire avutundi.")
            self.load_status_list()
        else:
            messagebox.showerror("Error", "Status post cheyadam kudiraledu.")

    def view_my_statuses(self, my_statuses):
        if not my_statuses:
            if messagebox.askyesno("No Status", "Mee status ledu. Ippudu add cheyalaa?"):
                self.open_add_status_popup()
            return
        StatusViewerPopup(
            self.root,
            statuses=my_statuses,
            current_index=0,
            current_user_id=self.current_user_id,
            db=self.db,
            on_view_callback=self.load_status_list,
            is_own=True
        )

    def view_contact_statuses(self, user_id, username):
        all_contacts_statuses = self.db.get_contacts_statuses(self.current_user_id)
        user_statuses = [s for s in all_contacts_statuses if s[1] == user_id]

        if not user_statuses:
            messagebox.showinfo("Info", f"{username} ki active status ledu.")
            return

        StatusViewerPopup(
            self.root,
            statuses=user_statuses,
            current_index=0,
            current_user_id=self.current_user_id,
            db=self.db,
            on_view_callback=self.load_status_list,
            is_own=False
        )

    # ==================== GROUP SCREENS ====================

    def show_groups_screen(self):
        self.clear_container()
        self.root.geometry("850x600")

        paned = tk.PanedWindow(self.container, orient="horizontal", bg="#F3F4FA", bd=0)
        paned.pack(fill="both", expand=True)

        left_frame = tk.Frame(paned, bg="white", width=280)
        paned.add(left_frame)

        header = tk.Frame(left_frame, bg="#2563EB", pady=12)
        header.pack(fill="x")
        tk.Label(header, text="👥 Groups", font=("Segoe UI", 13, "bold"), bg="#2563EB", fg="white").pack(side="left", padx=15)
        tk.Button(header, text="+ New", font=("Segoe UI", 9, "bold"), bg="white", fg="#2563EB", bd=0,
                  cursor="hand2", padx=8, pady=3,
                  command=self.open_create_group_popup).pack(side="right", padx=10)

        tk.Button(left_frame, text="← Back to Dashboard", font=("Segoe UI", 9), bg="white", bd=0,
                  fg=PRIMARY_COLOR, cursor="hand2", command=self.show_dashboard).pack(anchor="w", padx=10, pady=5)

        groups_canvas = tk.Canvas(left_frame, bg="white", highlightthickness=0)
        groups_scroll = tk.Scrollbar(left_frame, orient="vertical", command=groups_canvas.yview)
        self.groups_list_frame = tk.Frame(groups_canvas, bg="white")
        self.groups_list_frame.bind("<Configure>", lambda e: groups_canvas.configure(scrollregion=groups_canvas.bbox("all")))
        groups_canvas.create_window((0, 0), window=self.groups_list_frame, anchor="nw", width=260)
        groups_canvas.configure(yscrollcommand=groups_scroll.set)
        groups_canvas.pack(side="left", fill="both", expand=True)
        groups_scroll.pack(side="right", fill="y")

        self.chat_area = tk.Frame(paned, bg="#F3F4FA")
        paned.add(self.chat_area)

        self.group_welcome_lbl = tk.Label(self.chat_area, text="Select a group to start chatting",
                                          fg="#6B7280", bg="#F3F4FA", font=("Segoe UI", 12))
        self.group_welcome_lbl.pack(expand=True)

        self.load_groups_list()
        self.start_polling()

    def load_groups_list(self):
        for w in self.groups_list_frame.winfo_children():
            w.destroy()

        groups = self.db.get_user_groups(self.current_user_id)
        if not groups:
            tk.Label(self.groups_list_frame, text="No groups yet.\nCreate one!", 
                     font=("Segoe UI", 10), bg="white", fg="#6B7280").pack(pady=30)
        else:
            for gid, gname, created_by, created_at, member_count in groups:
                item = GroupListItem(self.groups_list_frame, gname, member_count=member_count,
                                     command=lambda g=gid, n=gname: self.load_group_chat(g, n))
                item.pack(fill="x")

    def open_create_group_popup(self):
        all_users = self.db.get_users_list(self.current_user_id)
        CreateGroupPopup(self.root, all_users, self.current_user_id, self.handle_create_group)

    def handle_create_group(self, group_name, member_ids):
        gid = self.db.create_group(group_name, self.current_user_id, member_ids)
        if gid:
            messagebox.showinfo("Success", f"'{group_name}' group create ayyindi!")
            self.load_groups_list()
        else:
            messagebox.showerror("Error", "Group create cheyadam kudiraledu.")

    def load_group_chat(self, group_id, group_name):
        self.selected_group_id = group_id
        self.selected_group_name = group_name
        self.chat_mode = "group"

        for widget in self.chat_area.winfo_children():
            widget.destroy()

        members = self.db.get_group_members(group_id)
        is_admin = self.db.is_group_admin(group_id, self.current_user_id)

        self.header = ChatHeader(
            self.chat_area,
            name=f"👥 {group_name}",
            search_callback=self.handle_group_message_search,
            clear_callback=None
        )
        self.header.update_header_status(member_count=len(members))

        tk.Button(self.header, text="ℹ️ Info", font=("Segoe UI", 9), bg="white", bd=0,
                  cursor="hand2", fg=PRIMARY_COLOR,
                  command=lambda: self.open_group_info(group_id, group_name)).pack(side="right", padx=5)

        canvas_container = tk.Frame(self.chat_area, bg=DEFAULT_CHAT_BG)
        canvas_container.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(canvas_container, bg=DEFAULT_CHAT_BG, highlightthickness=0)
        scrollbar = tk.Scrollbar(canvas_container, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas, bg=DEFAULT_CHAT_BG)

        self.canvas_window = self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.bind('<Configure>', lambda e: self.canvas.itemconfig(self.canvas_window, width=e.width))
        self.scrollable_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        input_frame = tk.Frame(self.chat_area, bg="white", padx=10, pady=10)
        input_frame.pack(fill="x", side="bottom")

        self.msg_entry = CustomEntry(input_frame, "Type a message...",
                                     emoji_callback=self.show_emoji_picker)
        self.msg_entry.pack(side="left", fill="x", expand=True, padx=5)
        self.msg_entry.entry.bind("<Return>", lambda e: self.handle_group_send())

        self.send_btn = WhatsAppSendButton(input_frame, command=self.handle_group_send)
        self.send_btn.pack(side="right", padx=5)

        self.refresh_group_messages(force=True)

    def handle_group_send(self):
        text = self.msg_entry.get().strip()
        if text and text != "Type a message..." and self.selected_group_id:
            result = self.db.send_group_message(self.selected_group_id, self.current_user_id, text)
            if result:
                self.msg_entry.delete(0, tk.END)
                self.refresh_group_messages(force=True)

    def refresh_group_messages(self, force=True):
        if not self.selected_group_id:
            return

        history = self.db.get_group_messages(self.selected_group_id)
        current_data_str = str(history)
        if not force and hasattr(self, 'last_data_check') and self.last_data_check == current_data_str:
            return
        self.last_data_check = current_data_str

        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()

        last_date = None
        for row in history:
            sender_id, sender_name, text, ts, mid, mtype, fpath, is_starred = row
            curr_date = self.get_date_label(ts)
            if curr_date != last_date:
                DateHeader(self.scrollable_frame, curr_date)
                last_date = curr_date

            try:
                display_time = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").strftime("%I:%M %p")
            except:
                display_time = ts

            is_sender = (sender_id == self.current_user_id)
            ChatBubble(
                self.scrollable_frame, text, timestamp=display_time,
                is_sender=is_sender, msg_id=mid, status="sent",
                message_type=mtype, file_path=fpath, is_starred=is_starred,
                sender_name=None if is_sender else sender_name,
                delete_callback=self.handle_group_delete_message if is_sender else None
            ).pack(fill="x", pady=2)

        if force:
            self.root.update_idletasks()
            self.canvas.yview_moveto(1.0)

    def handle_group_delete_message(self, msg_id):
        if messagebox.askyesno("Delete", "ఈ మెసేజ్ ని డిలీట్ చేయాలా?"):
            if self.db.delete_group_message(msg_id):
                self.refresh_group_messages(force=True)

    def handle_group_message_search(self, keyword):
        if not keyword.strip():
            self.refresh_group_messages(force=True)
            return

        results = self.db.search_group_messages(self.selected_group_id, keyword)
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()

        if not results:
            tk.Label(self.scrollable_frame, text="No messages found.", bg=DEFAULT_CHAT_BG,
                     fg="#6B7280", font=("Segoe UI", 10, "italic")).pack(pady=20)
            return

        for row in results:
            sender_id, sender_name, text, ts, mid, mtype, fpath, is_starred = row
            try:
                display_time = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").strftime("%I:%M %p")
            except:
                display_time = ts
            is_sender = (sender_id == self.current_user_id)
            ChatBubble(self.scrollable_frame, text, timestamp=display_time,
                       is_sender=is_sender, msg_id=mid, status="sent",
                       sender_name=None if is_sender else sender_name).pack(fill="x", pady=2)

    def open_group_info(self, group_id, group_name):
        members = self.db.get_group_members(group_id)
        is_admin = self.db.is_group_admin(group_id, self.current_user_id)
        all_users = self.db.get_users_list(self.current_user_id)
        GroupMembersPopup(
            self.root, group_id, group_name, members, is_admin, all_users,
            self.current_user_id,
            add_member_callback=self.handle_add_member,
            remove_member_callback=self.handle_remove_member
        )

    def handle_add_member(self, group_id, user_id, popup):
        if self.db.add_group_member(group_id, user_id):
            messagebox.showinfo("Success", "Member add ayyindi!", parent=popup)
            popup.destroy()
            self.open_group_info(group_id, self.selected_group_name)
        else:
            messagebox.showerror("Error", "Member add cheyadam kudiraledu.", parent=popup)

    def handle_remove_member(self, group_id, user_id, username, popup):
        if messagebox.askyesno("Confirm", f"{username} ni group nundi remove cheyalaa?", parent=popup):
            if self.db.remove_group_member(group_id, user_id):
                messagebox.showinfo("Success", f"{username} remove ayyindi!", parent=popup)
                popup.destroy()
                self.open_group_info(group_id, self.selected_group_name)

    # ==================== PRIVATE CHAT FUNCTIONS ====================

    def show_chat_screen(self):
        self.clear_container()
        self.root.geometry("850x600")
        self.chat_mode = "private"
        
        paned = tk.PanedWindow(self.container, orient="horizontal", bg="#F3F4FA", bd=0)
        paned.pack(fill="both", expand=True)

        left_frame = tk.Frame(paned, bg="white", width=300)
        paned.add(left_frame)

        top = tk.Frame(left_frame, bg="white", pady=12)
        top.pack(fill="x")
        tk.Button(top, text="←", command=self.show_dashboard, bd=0, bg="white", fg="#2563EB", font=("Segoe UI", 15, "bold"), cursor="hand2").pack(side="left", padx=(12,6))
        tk.Label(top, text="Messages", font=("Segoe UI", 16, "bold"), bg="white", fg="#10233F").pack(side="left")
        tk.Button(top, text="＋", command=self.show_chat_screen, bd=0, bg="#EFF6FF", fg="#2563EB", font=("Segoe UI", 13, "bold"), cursor="hand2", width=3).pack(side="right", padx=12)
        tk.Label(left_frame, text="Recent conversations", font=("Segoe UI", 9), bg="white", fg="#72819A").pack(anchor="w", padx=18, pady=(0,6))
        
        self.search_bar = SearchBar(left_frame, self.filter_contacts)
        self.search_bar.pack(fill="x", padx=10, pady=5)

        contacts_canvas = tk.Canvas(left_frame, bg="white", highlightthickness=0)
        contacts_scroll = tk.Scrollbar(left_frame, orient="vertical", command=contacts_canvas.yview)
        self.contacts_list_frame = tk.Frame(contacts_canvas, bg="white")

        self.contacts_list_frame.bind("<Configure>", lambda e: contacts_canvas.configure(scrollregion=contacts_canvas.bbox("all")))
        contacts_canvas.create_window((0, 0), window=self.contacts_list_frame, anchor="nw", width=260)
        contacts_canvas.configure(yscrollcommand=contacts_scroll.set)
        contacts_canvas.pack(side="left", fill="both", expand=True)
        contacts_scroll.pack(side="right", fill="y")

        self.chat_area = tk.Frame(paned, bg="#F3F4FA")
        paned.add(self.chat_area)
        
        welcome = tk.Frame(self.chat_area, bg="#F3F6FB")
        welcome.pack(expand=True, fill="both")
        tk.Label(welcome, text="💬", font=("Segoe UI", 42), bg="#F3F6FB", fg="#2563EB").pack(pady=(80,8))
        tk.Label(welcome, text="Your conversations, beautifully connected", fg="#10233F", bg="#F3F6FB", font=("Segoe UI", 18, "bold")).pack()
        tk.Label(welcome, text="Select a contact to start chatting, sharing images and building a conversation.", fg="#72819A", bg="#F3F6FB", font=("Segoe UI", 10)).pack(pady=(6,22))
        features=tk.Frame(welcome,bg="#F3F6FB"); features.pack()
        for title,desc in [("Fast messaging","Real-time chat"),("Rich conversations","Reply, edit & star"),("Private & secure","Your local database")]:
            f=tk.Frame(features,bg="white",highlightbackground="#E6ECF5",highlightthickness=1,width=190,height=80); f.pack(side="left",padx=7); f.pack_propagate(False)
            tk.Label(f,text=title,bg="white",fg="#10233F",font=("Segoe UI",9,"bold")).pack(anchor="w",padx=12,pady=(13,2))
            tk.Label(f,text=desc,bg="white",fg="#72819A",font=("Segoe UI",8)).pack(anchor="w",padx=12)
        self.chat_welcome_lbl = welcome

        self.display_contacts(self.db.get_users_list(self.current_user_id))
        self.start_polling()

    def load_user_chat(self, recipient_id, recipient_name):
        self.selected_recipient_id = recipient_id
        self.chat_mode = "private"
        self.db.mark_messages_as_seen(recipient_id, self.current_user_id)

        # Reply state reset — new chat open chessinappudu
        self.cancel_reply()
        self.cancel_edit()

        for widget in self.chat_area.winfo_children():
            widget.destroy()

        self.header = ChatHeader(
            self.chat_area,
            name=recipient_name,
            clear_callback=self.handle_clear_chat,
            search_callback=self.handle_message_search
        )

        is_already_blocked = self.db.is_blocked(self.current_user_id, recipient_id)
        btn_text = "Unblock" if is_already_blocked else "Block"
        btn_color = SUCCESS_COLOR if is_already_blocked else "red"

        tk.Button(self.header, text=btn_text, fg=btn_color, bg="white", bd=0, font=("Segoe UI", 9, "bold"),
                  command=lambda: self.handle_block_toggle(recipient_id, is_already_blocked, recipient_name)).pack(side="right", padx=10)

        tk.Button(self.header, text="Back", command=self.show_dashboard, bd=0, bg="white", fg=PRIMARY_COLOR).pack(side="right")

        canvas_container = tk.Frame(self.chat_area, bg=DEFAULT_CHAT_BG)
        canvas_container.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(canvas_container, bg=DEFAULT_CHAT_BG, highlightthickness=0)
        scrollbar = tk.Scrollbar(canvas_container, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tk.Frame(self.canvas, bg=DEFAULT_CHAT_BG)

        self.canvas_window = self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.bind('<Configure>', lambda e: self.canvas.itemconfig(self.canvas_window, width=e.width))
        self.scrollable_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # input_frame ni self ki assign cheyyadam — ReplyPreviewBar ikkade pack avutundi
        self.input_frame = tk.Frame(self.chat_area, bg="white", padx=10, pady=10)
        self.input_frame.pack(fill="x", side="bottom")

        tk.Button(self.input_frame, text="📎", font=("Segoe UI", 14), bd=0, bg="white",
                  command=self.handle_image_upload).pack(side="left", padx=5)

        self.msg_entry = CustomEntry(self.input_frame, "Type a message...",
                                     typing_callback=self.handle_user_typing,
                                     emoji_callback=self.show_emoji_picker)
        self.msg_entry.pack(side="left", fill="x", expand=True, padx=5)
        self.msg_entry.entry.bind("<Return>", lambda e: self.handle_send())

        self.send_btn = WhatsAppSendButton(self.input_frame, command=self.handle_send)
        self.send_btn.pack(side="right", padx=5)

        self.refresh_messages(force=True)

    def handle_message_search(self, keyword):
        if not keyword.strip():
            self.refresh_messages(force=True)
            return

        results = self.db.search_messages(self.current_user_id, self.selected_recipient_id, keyword)
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()

        if not results:
            tk.Label(self.scrollable_frame, text="No messages found matching your search.",
                     bg=DEFAULT_CHAT_BG, fg="#6B7280", font=("Segoe UI", 10, "italic")).pack(pady=20)
            return

        for row in results:
            # 10 columns: sender_id, text, ts, msg_id, status, mtype, fpath, is_starred, reply_to, is_edited
            sender_id, text, ts, mid, status, mtype, fpath, is_starred, reply_to, is_edited = row
            try:
                display_time = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").strftime("%I:%M %p")
            except:
                display_time = ts

            reply_text = None
            reply_sender = None
            if reply_to:
                reply_row = self.db.get_message_by_id(reply_to)
                if reply_row:
                    _, _, reply_text, reply_sender = reply_row

            is_own = (sender_id == self.current_user_id)
            ChatBubble(
                self.scrollable_frame, text, timestamp=display_time,
                is_sender=is_own,
                msg_id=mid, status=status, message_type=mtype, file_path=fpath,
                is_starred=is_starred,
                star_callback=self.handle_star_toggle,
                delete_callback=self.handle_delete_message,
                reply_callback=self.handle_reply_click,
                reply_to_text=reply_text,
                reply_to_sender=reply_sender,
                scroll_to_callback=self.scroll_to_message,
                reply_to_id=reply_to,
                edit_callback=self.handle_edit_click if is_own else None,
                is_edited=is_edited
            ).pack(fill="x", pady=2)

        self.canvas.yview_moveto(0.0)

    def refresh_messages(self, force=True):
        if not self.selected_recipient_id:
            return

        if not force:
            self.db.mark_messages_as_seen(self.selected_recipient_id, self.current_user_id)

        history = self.db.get_chat_history(self.current_user_id, self.selected_recipient_id)

        current_data_str = str(history)
        if not force and hasattr(self, 'last_data_check') and self.last_data_check == current_data_str:
            return
        self.last_data_check = current_data_str

        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()

        last_date = None
        for row in history:
            # 10 columns: sender_id, text, ts, msg_id, status, mtype, fpath, is_starred, reply_to, is_edited
            sender_id, text, ts, mid, status, mtype, fpath, is_starred, reply_to, is_edited = row
            curr_date = self.get_date_label(ts)
            if curr_date != last_date:
                DateHeader(self.scrollable_frame, curr_date)
                last_date = curr_date

            try:
                display_time = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S").strftime("%I:%M %p")
            except:
                display_time = ts

            # Reply preview data fetch
            reply_text = None
            reply_sender = None
            if reply_to:
                reply_row = self.db.get_message_by_id(reply_to)
                if reply_row:
                    _, _, reply_text, reply_sender = reply_row

            is_own = (sender_id == self.current_user_id)
            ChatBubble(
                self.scrollable_frame, text, timestamp=display_time,
                is_sender=is_own,
                msg_id=mid, status=status, message_type=mtype, file_path=fpath,
                is_starred=is_starred,
                star_callback=self.handle_star_toggle,
                delete_callback=self.handle_delete_message,
                reply_callback=self.handle_reply_click,
                reply_to_text=reply_text,
                reply_to_sender=reply_sender,
                scroll_to_callback=self.scroll_to_message,
                reply_to_id=reply_to,
                edit_callback=self.handle_edit_click if is_own else None,  # Edit: only own messages
                is_edited=is_edited
            ).pack(fill="x", pady=2)

        if force:
            self.root.update_idletasks()
            self.canvas.yview_moveto(1.0)

    def handle_delete_message(self, message_id):
        if messagebox.askyesno("Delete", "ఈ మెసేజ్ ని డిలీట్ చేయాలా?"):
            if self.db.delete_single_message(message_id):
                self.refresh_messages(force=True)

    def handle_clear_chat(self):
        if messagebox.askyesno("Clear Chat", "మొత్తం చాట్ హిస్టరీని డిలీట్ చేయాలా?"):
            if self.db.clear_full_chat(self.current_user_id, self.selected_recipient_id):
                self.refresh_messages(force=True)

    def handle_send(self):
        text = self.msg_entry.get().strip()
        if not text or text == "Type a message..." or not self.selected_recipient_id:
            return

        # ---- EDIT MODE: new message create cheyyadu, existing update chestundi ----
        if self.edit_target_id:
            success = self.db.edit_message(self.edit_target_id, text, self.current_user_id)
            if success:
                self.msg_entry.delete(0, tk.END)
                self.cancel_edit()
                self.refresh_messages(force=True)
            else:
                messagebox.showerror("Error", "Message edit cheyadam kudiraledu.")
            return

        # ---- NORMAL SEND / REPLY MODE ----
        result = self.db.save_message(
            self.current_user_id,
            self.selected_recipient_id,
            text,
            reply_to=self.reply_target_id   # Reply feature — None if no reply
        )

        if result == "blocked_by_me":
            messagebox.showwarning("Blocked", "Nuvvu ee contact ni block chesav. Message pampali ante mundhu unblock cheyi.")
        else:
            self.db.update_typing_status(self.current_user_id, 0)
            self.msg_entry.delete(0, tk.END)
            self.cancel_reply()   # Send chesina taruvata reply state clear
            self.refresh_messages(force=True)

    def show_emoji_picker(self):
        EmojiPicker(self.root, lambda e: self.msg_entry.insert_text(e))

    def poll_for_messages(self):
        if self.polling_active and self.current_user_id:
            try: 
                self.db.update_last_seen(self.current_user_id)

                # Secret Delivery Scheduler — every 1 second
                # Due scheduled messages automatic ga normal chat lo deliver avutayi
                try:
                    delivered = self.db.deliver_due_messages(self.current_user_id)
                    if delivered and self.chat_mode == "private" and self.selected_recipient_id:
                        self.refresh_messages(force=True)
                except Exception:
                    pass
                
                if self.chat_mode == "private" and self.selected_recipient_id:
                    status_data = self.db.get_user_status(self.selected_recipient_id)
                    if hasattr(self, 'header') and self.header:
                        self.header.update_header_status(
                            is_online=status_data[0],
                            is_typing=status_data[2],
                            last_seen=status_data[1]
                        )
                    self.refresh_messages(force=False)
                    self.display_contacts(self.db.get_users_list(self.current_user_id))

                elif self.chat_mode == "group" and self.selected_group_id:
                    self.refresh_group_messages(force=False)
                
            except Exception as e: 
                print(f"Polling error: {e}")
                
            # 1 second — second-level accuracy for capsule delivery
            self.root.after(1000, self.poll_for_messages)

    def start_polling(self):
        if not self.polling_active:
            self.polling_active = True
            self.poll_for_messages()

    def handle_block_toggle(self, rid, blocked, name):
        action = "Unblock" if blocked else "Block"
        if messagebox.askyesno("Confirm", f"{name} ni {action} cheyala?"):
            if blocked: 
                if self.db.unblock_user(self.current_user_id, rid):
                    self.refresh_messages(force=True)
            else: 
                self.db.block_user(self.current_user_id, rid)
            self.load_user_chat(rid, name)

    def handle_image_upload(self):
        if not self.selected_recipient_id: return
        f = filedialog.askopenfilename(filetypes=[("Images", "*.jpg *.png *.jpeg")])
        if f:
            result = self.db.save_message(self.current_user_id, self.selected_recipient_id, "[Image]", msg_type='image', file_path=f)
            if result == "blocked_by_me":
                messagebox.showwarning("Blocked", "Nuvvu ee contact ni block chesav. Image pampali ante mundhu unblock cheyi.")
            else:
                self.refresh_messages(force=True)

    def filter_contacts(self, q):
        query = q.lower().strip()
        for widget in self.contacts_list_frame.winfo_children():
            if hasattr(widget, 'name'):
                if query in widget.name.lower() or query == "":
                    widget.pack(fill="x", side="top")
                else:
                    widget.pack_forget()

    def display_contacts(self, users):
        search_query = ""
        if hasattr(self, 'search_bar'):
            raw = self.search_bar.entry.get()
            search_query = raw.lower() if raw != "search contacts..." else ""

        unread_map = self.db.get_all_unread_counts(self.current_user_id)

        filtered_users = [u for u in users if search_query in u[1].lower()]

        current_widgets = self.contacts_list_frame.winfo_children()
        current_count = len(current_widgets)

        if current_count != len(filtered_users):
            for w in self.contacts_list_frame.winfo_children():
                w.destroy()

            for uid, name, dp, is_online, last_seen in filtered_users:
                unread = unread_map.get(uid, 0)
                item = UserListItem(
                    self.contacts_list_frame, name,
                    profile_pic=dp,
                    is_online=is_online,
                    last_seen=last_seen,
                    unread_count=unread,
                    command=lambda u=uid, n=name: self.load_user_chat(u, n)
                )
                item.pack(fill="x")
        else:
            for i, widget in enumerate(current_widgets):
                if i < len(filtered_users):
                    uid, name, dp, is_online, last_seen = filtered_users[i]
                    unread = unread_map.get(uid, 0)
                    if hasattr(widget, 'update_status'):
                        widget.update_status(is_online, last_seen, unread_count=unread)

    def handle_user_typing(self):
        try:
            self.db.update_typing_status(self.current_user_id, 1)
            if self.typing_timer: self.root.after_cancel(self.typing_timer)
            self.typing_timer = self.root.after(3000, lambda: self.db.update_typing_status(self.current_user_id, 0))
        except: pass

    def get_date_label(self, ds):
        try:
            d = datetime.strptime(ds.split()[0], "%Y-%m-%d").date()
            if d == datetime.now().date(): return "Today"
            if d == (datetime.now() - timedelta(days=1)).date(): return "Yesterday"
            return d.strftime("%B %d, %Y")
        except: return None

    def handle_login(self):
        u, p = self.auth_ui.get_data()
        uid = self.db.login_user(u, p)
        if uid:
            self.current_user_id, self.current_username = uid, u
            self.db.update_user_online_status(self.current_user_id, 1)
            self.show_dashboard()
        else: messagebox.showerror("Error", "Invalid login details")

    def handle_register(self):
        u, p = self.auth_ui.get_data()
        if self.db.register_user(u, p): messagebox.showinfo("Success", "Account Created!")
        else: messagebox.showerror("Error", "Username exists!")

    def handle_logout(self):
        if self.current_user_id: 
            self.db.update_user_online_status(self.current_user_id, 0)
            self.db.logout_user(self.current_user_id)
        self.current_user_id = None
        self.show_login_page()

    def show_login_page(self):
        self.clear_container()
        self.root.geometry("1120x700")
        self.root.minsize(980, 640)
        self.auth_ui = AuthFrame(self.container)
        self.auth_ui.pack(expand=True, fill="both")
        btn_area = self.auth_ui.button_area
        StyledButton(btn_area, "Log In", PRIMARY_COLOR, self.handle_login, center=True).pack(fill="x", pady=(0, 8))
        StyledButton(btn_area, "Create Account", SUCCESS_COLOR, self.handle_register, center=True).pack(fill="x")

if __name__ == "__main__":
    root = tk.Tk()
    app = MainApp(root)
    root.mainloop()
