import tkinter as tk
from tkinter import ttk, messagebox, Menu, filedialog
from PIL import Image, ImageTk, ImageOps, ImageDraw, ImageFilter, ImageChops
import math
import os
from datetime import datetime

# --- CUSTOM COLORS & STYLES (Professional / Premium theme) ---
BG_COLOR = "#F3F4FA"          # soft lavender-grey app background
CARD_COLOR = "#FFFFFF"        # white card surfaces
BORDER_COLOR = "#E7E8F6"      # subtle card / divider border
PRIMARY_COLOR = "#5B5FEF"     # premium indigo (brand accent)
PRIMARY_DARK = "#4547C7"      # hover / pressed state
PRIMARY_LIGHT = "#EEF0FF"     # soft accent tint (chips, active states)
SUCCESS_COLOR = "#16A34A"
TEXT_COLOR = "#1E2233"
MUTED_TEXT = "#6B7280"
SENDER_COLOR = "#5B5FEF"      # my message bubbles — solid brand indigo
SENDER_TEXT = "#FFFFFF"       # text color on my bubbles
RECEIVER_COLOR = "#ffffff"
TIME_COLOR = "#8B90A0"
HIGHLIGHT_COLOR = "#EEF0FF"
TICK_BLUE = "#93C5FD"
TICK_GREY = "#C7CBE8"
GROUP_COLOR = "#EDE4FF"
GROUP_ACCENT = "#8B5CF6"
STATUS_GREEN = "#22C55E"
STATUS_GREY = "#9CA3AF"
NOTIF_RED = "#EF4444"
CARD_SHADOW = "#D8DAF0"       # soft shadow tone used behind elevated cards

# --- Dashboard (design-reference) tokens ---
DASH_FONT = "Segoe UI"
DASH_PAGE = "#EEF3FD"
DASH_TEXT = "#0B1F5C"
DASH_MUTED = "#6E7BB0"
DASH_BLUE = "#2B6EF0"
DASH_INDIGO = "#3F3FD9"
DASH_RED = "#FF4D6D"

# Default chat bg
DEFAULT_CHAT_BG = "#EEF0FA"



# ============================================================================
#  SHARED DESIGN HELPERS — rounded corners, soft shadows, blended colors.
#  Purely additive: nothing below changes any existing public name or the
#  external behaviour of any widget that already used plain tk.Frame corners.
# ============================================================================

def _clamp(v, lo=0, hi=255):
    return max(lo, min(hi, int(v)))


def _blend(hex_a, hex_b, t):
    """Linear-interpolate two hex colors. t=0 -> hex_a, t=1 -> hex_b."""
    try:
        a = hex_a.lstrip("#"); b = hex_b.lstrip("#")
        ar, ag, ab = (int(a[i:i+2], 16) for i in (0, 2, 4))
        br, bg, bb = (int(b[i:i+2], 16) for i in (0, 2, 4))
        r = _clamp(ar + (br - ar) * t)
        g = _clamp(ag + (bg - ag) * t)
        bl = _clamp(ab + (bb - ab) * t)
        return f"#{r:02x}{g:02x}{bl:02x}"
    except Exception:
        return hex_a


def _round_points(x1, y1, x2, y2, r):
    r = max(0, min(r, (x2 - x1) / 2, (y2 - y1) / 2))
    return [
        x1 + r, y1,  x2 - r, y1,  x2, y1,  x2, y1 + r,
        x2, y2 - r,  x2, y2,  x2 - r, y2,  x1 + r, y2,
        x1, y2,  x1, y2 - r,  x1, y1 + r,  x1, y1,
    ]


def draw_round_rect(canvas, x1, y1, x2, y2, radius=14, **kwargs):
    """Draws a smooth rounded-rectangle polygon on a Canvas and returns its item id."""
    return canvas.create_polygon(_round_points(x1, y1, x2, y2, radius), smooth=True, **kwargs)


def _hex_rgb(hex_color):
    h = hex_color.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def make_gradient_rounded_image(width, height, radius, top_color, bottom_color,
                                 alpha=255, border_color=None, border_width=0, horizontal=False):
    """
    Renders a smooth vertical-gradient, rounded-corner, optionally semi-transparent
    PNG (as ImageTk.PhotoImage) — used for gradient buttons and frosted 'glass' cards.
    Rendered at 2x and downsampled for clean anti-aliased edges.
    """
    width, height = max(1, int(width)), max(1, int(height))
    scale = 2
    w, h = width * scale, height * scale
    r = radius * scale

    top_rgb = _hex_rgb(top_color)
    bot_rgb = _hex_rgb(bottom_color)
    if horizontal:
        grad = Image.new("RGB", (w, 1))
        for x in range(w):
            t = x / max(1, w - 1)
            grad.putpixel((x, 0), tuple(int(top_rgb[i] + (bot_rgb[i] - top_rgb[i]) * t) for i in range(3)))
    else:
        grad = Image.new("RGB", (1, h))
        for y in range(h):
            t = y / max(1, h - 1)
            grad.putpixel((0, y), tuple(int(top_rgb[i] + (bot_rgb[i] - top_rgb[i]) * t) for i in range(3)))
    grad = grad.resize((w, h))

    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, w - 1, h - 1], radius=r, fill=alpha)

    out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    out.paste(grad, (0, 0), mask)

    if border_color and border_width > 0:
        draw = ImageDraw.Draw(out)
        draw.rounded_rectangle([0, 0, w - 1, h - 1], radius=r,
                                outline=border_color, width=border_width * scale)

    out = out.resize((width, height), Image.LANCZOS)
    return ImageTk.PhotoImage(out)


def make_glow_image(diameter, color, alpha=140, blur=None):
    """A soft blurred radial glow blob (RGBA PNG) — used behind active sidebar
    items and as subtle decorative background bloom on the login screen."""
    diameter = max(8, int(diameter))
    blur = blur if blur is not None else diameter // 4
    pad = blur * 2
    size = diameter + pad * 2
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    rgb = _hex_rgb(color)
    ImageDraw.Draw(img).ellipse([pad, pad, pad + diameter, pad + diameter],
                                fill=rgb + (alpha,))
    img = img.filter(ImageFilter.GaussianBlur(blur))
    return ImageTk.PhotoImage(img)


def make_glow_rect_image(width, height, radius, color, alpha=120, blur=6):
    """Soft blurred rounded-rectangle glow (RGBA) — active sidebar item / card shadow."""
    width, height = int(width), int(height)
    pad = blur * 3
    img = Image.new("RGBA", (width + pad * 2, height + pad * 2), (0, 0, 0, 0))
    ImageDraw.Draw(img).rounded_rectangle([pad, pad, pad + width, pad + height],
                                          radius=radius, fill=_hex_rgb(color) + (alpha,))
    return ImageTk.PhotoImage(img.filter(ImageFilter.GaussianBlur(blur)))


# ============================================================================
#  DASHBOARD ART TOOLKIT — vector-style icons, pastel wave backdrop, glass cards,
#  mini area charts and gradient avatars, all rendered with Pillow so the
#  dashboard looks identical on every machine (no dependency on emoji fonts).
# ============================================================================

_ART_CACHE = {}
_ART_CACHE_ROOT = [None]


def _cache_get(key, builder):
    # Cached PhotoImages belong to whichever Tk interpreter was active when they
    # were built. Guard against a stale cache if the default root ever changes
    # (e.g. a fresh tk.Tk() after the previous one was destroyed).
    cur_root = tk._default_root
    if _ART_CACHE_ROOT[0] is not cur_root:
        _ART_CACHE.clear()
        _ART_CACHE_ROOT[0] = cur_root
    val = _ART_CACHE.get(key)
    if val is None:
        if len(_ART_CACHE) > 300:
            _ART_CACHE.clear()
        val = builder()
        _ART_CACHE[key] = val
    return val


def _v_gradient(w, h, c_top, c_bot):
    top = Image.new("RGB", (w, h), c_top)
    bot = Image.new("RGB", (w, h), c_bot)
    mask = Image.linear_gradient("L").resize((w, h))
    return Image.composite(bot, top, mask)


def _wave_poly(w, h, y0, amp, freq, phase, to_bottom=True, step=8):
    pts = [(x, y0 + amp * math.sin(freq * (x / float(w)) * 2 * math.pi + phase))
           for x in range(0, w + step, step)]
    return pts + ([(w, h), (0, h)] if to_bottom else [(w, 0), (0, 0)])


def _ribbon_poly(w, x0, ya, yb, amp, freq, phase, step=8):
    xs = list(range(int(x0), w + step, step))
    upper = [(x, ya + amp * math.sin(freq * (x / float(w)) * 2 * math.pi + phase)) for x in xs]
    lower = [(x, yb + amp * math.sin(freq * (x / float(w)) * 2 * math.pi + phase + 0.9)) for x in xs]
    return upper + lower[::-1]


# ---------------------------------------------------------------- icons -----
def _icon_pil(name, size, color, color2=None):
    SS = 4
    S = int(size * SS)
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    c = _hex_rgb(color) + (255,)
    c2 = (_hex_rgb(color2) if color2 else _hex_rgb(color)) + (255,)
    T = (0, 0, 0, 0)
    k = S / 100.0

    def P(*pts):
        return [(x * k, y * k) for (x, y) in pts]

    def R(x1, y1, x2, y2):
        return [x1 * k, y1 * k, x2 * k, y2 * k]

    def line(p1, p2, w, fill=c):
        d.line([p1[0] * k, p1[1] * k, p2[0] * k, p2[1] * k], fill=fill, width=max(1, int(w * k)))
        r = w * k / 2.0
        for (x, y) in (p1, p2):
            d.ellipse([x * k - r, y * k - r, x * k + r, y * k + r], fill=fill)

    def poly(points, w, fill=c):
        for a, b in zip(points, points[1:]):
            line(a, b, w, fill)

    if name == "home":
        d.polygon(P((50, 8), (95, 50), (83, 50), (83, 90), (60, 90), (60, 63),
                    (40, 63), (40, 90), (17, 90), (17, 50), (5, 50)), fill=c)
    elif name == "chat":
        d.ellipse(R(9, 8, 91, 82), outline=c, width=int(10 * k))
        d.polygon(P((24, 72), (14, 95), (46, 80)), fill=c)
    elif name == "people":
        d.ellipse(R(16, 12, 50, 46), fill=c)
        d.pieslice(R(4, 52, 62, 112), 180, 360, fill=c)
        d.ellipse(R(56, 24, 86, 54), fill=c2)
        d.pieslice(R(46, 58, 96, 108), 180, 360, fill=c2)
    elif name == "status":
        d.rounded_rectangle(R(5, 12, 95, 76), radius=int(22 * k), fill=c)
        d.polygon(P((26, 72), (18, 95), (52, 76)), fill=c)
        d.ellipse(R(26, 34, 42, 50), fill=T)
        d.ellipse(R(58, 34, 74, 50), fill=T)
    elif name == "sun":
        d.ellipse(R(27, 27, 73, 73), fill=c)
        d.ellipse(R(38, 38, 62, 62), fill=c2)
        for i in range(8):
            a = i * math.pi / 4
            line((50 + 36 * math.cos(a), 50 + 36 * math.sin(a)),
                 (50 + 47 * math.cos(a), 50 + 47 * math.sin(a)), 8)
    elif name == "bars":
        d.rounded_rectangle(R(7, 7, 93, 93), radius=int(14 * k), outline=c, width=int(9 * k))
        d.rectangle(R(24, 54, 35, 78), fill=c)
        d.rectangle(R(44, 36, 55, 78), fill=c)
        d.rectangle(R(65, 22, 76, 78), fill=c)
    elif name == "mask":
        d.polygon(P((6, 26), (26, 16), (50, 24), (74, 16), (94, 26), (94, 50),
                    (78, 82), (50, 94), (22, 82), (6, 50)), fill=c)
        d.ellipse(R(18, 36, 44, 58), fill=T)
        d.ellipse(R(56, 36, 82, 58), fill=T)
    elif name == "hourglass":
        d.polygon(P((24, 12), (76, 12), (76, 30), (57, 50), (76, 70), (76, 88),
                    (24, 88), (24, 70), (43, 50), (24, 30)), fill=c)
        d.polygon(P((33, 20), (67, 20), (67, 27), (50, 44), (50, 56), (67, 73),
                    (67, 80), (33, 80), (33, 73), (50, 56), (50, 44), (33, 27)), fill=T)
        d.polygon(P((38, 80), (62, 80), (50, 65)), fill=c)
        d.polygon(P((40, 24), (60, 24), (50, 38)), fill=c)
        d.rounded_rectangle(R(15, 4, 85, 13), radius=int(4 * k), fill=c)
        d.rounded_rectangle(R(15, 87, 85, 96), radius=int(4 * k), fill=c)
    elif name == "star":
        pts = []
        for i in range(10):
            r = 47 if i % 2 == 0 else 20
            a = -math.pi / 2 + i * math.pi / 5
            pts.append((50 + r * math.cos(a), 54 + r * math.sin(a)))
        d.polygon(P(*pts), fill=c)
    elif name == "ban":
        d.ellipse(R(9, 9, 91, 91), outline=c, width=int(11 * k))
        line((27, 27), (73, 73), 11)
    elif name == "power":
        d.arc(R(13, 19, 87, 93), 300, 360, fill=c, width=int(11 * k))
        d.arc(R(13, 19, 87, 93), 0, 240, fill=c, width=int(11 * k))
        line((50, 9), (50, 48), 11)
    elif name == "megaphone":
        d.polygon(P((8, 38), (36, 38), (82, 10), (82, 90), (36, 62), (8, 62)), fill=c)
        d.rounded_rectangle(R(22, 58, 40, 92), radius=int(6 * k), fill=c)
    elif name == "shield":
        d.polygon(P((50, 5), (91, 20), (91, 52), (50, 95), (9, 52), (9, 20)), fill=c)
        d.polygon(P((50, 5), (91, 20), (91, 52), (50, 95)), fill=c2)
    elif name == "user":
        d.ellipse(R(30, 8, 70, 48), outline=c, width=int(10 * k))
        d.arc(R(11, 56, 89, 140), 180, 360, fill=c, width=int(10 * k))
    elif name == "image":
        d.rounded_rectangle(R(6, 14, 94, 86), radius=int(13 * k), outline=c, width=int(9 * k))
        d.ellipse(R(27, 30, 45, 48), fill=c)
        d.polygon(P((16, 76), (38, 54), (54, 70), (66, 58), (84, 76)), fill=c)
    elif name == "send":
        d.polygon(P((5, 46), (95, 7), (60, 95), (46, 62)), fill=c)
        line((46, 62), (95, 7), 5, fill=T)
    elif name == "chevron":
        poly([(33, 14), (68, 50), (33, 86)], 13)
    elif name == "arrow":
        line((8, 50), (84, 50), 11)
        poly([(56, 20), (86, 50), (56, 80)], 11)
    elif name == "check":
        d.ellipse(R(3, 3, 97, 97), fill=c)
        poly([(27, 52), (44, 69), (75, 33)], 12, fill=(255, 255, 255, 255))
    elif name == "dot":
        d.ellipse(R(8, 8, 92, 92), fill=c)
    return img.resize((int(size), int(size)), Image.LANCZOS)


def get_icon(name, size=20, color="#FFFFFF", color2=None):
    """Cached PhotoImage of a vector-style dashboard icon."""
    return _cache_get(("icon", name, int(size), color, color2),
                      lambda: ImageTk.PhotoImage(_icon_pil(name, size, color, color2)))


# ------------------------------------------------------------ backdrops -----
def make_dash_background_pil(w, h):
    """Vibrant blue-purple gradient dashboard backdrop with soft neon blobs."""
    w, h = max(16, int(w)), max(16, int(h))
    s = 2
    W, H = max(8, w // s), max(8, h // s)
    base = _v_gradient(W, H, (20, 35, 105), (91, 42, 174)).convert("RGBA")
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)

    # Large atmospheric gradient-like blobs.
    for cx, cy, r, color, alpha in [
        (W * 0.86, H * 0.12, H * 0.30, (0, 212, 255), 90),
        (W * 0.72, H * 0.78, H * 0.38, (181, 64, 255), 80),
        (W * 0.16, H * 0.88, H * 0.32, (39, 110, 255), 80),
        (W * 0.48, H * 0.18, H * 0.22, (111, 76, 255), 55),
    ]:
        d.ellipse([cx-r, cy-r, cx+r, cy+r], fill=color + (alpha,))

    # Flowing ribbons along the lower area.
    d.polygon(_wave_poly(W, H, H * 0.78, H * 0.065, 1.0, 0.5), fill=(21, 224, 255, 42))
    d.polygon(_wave_poly(W, H, H * 0.86, H * 0.055, 1.5, 2.0), fill=(154, 73, 255, 52))
    d.polygon(_wave_poly(W, H, H * 0.94, H * 0.040, 1.2, 4.0), fill=(255, 73, 190, 38))
    layer = layer.filter(ImageFilter.GaussianBlur(max(2, W // 95)))
    base.alpha_composite(layer)

    # Fine diagonal light streaks for a premium modern feel.
    streak = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sd = ImageDraw.Draw(streak)
    for i in range(-H, W, max(70, W // 9)):
        sd.line([(i, H), (i + H * 0.55, 0)], fill=(255, 255, 255, 13), width=max(1, W // 500))
    streak = streak.filter(ImageFilter.GaussianBlur(2))
    base.alpha_composite(streak)
    return base.resize((w, h), Image.BICUBIC).convert("RGB")


def make_sidebar_panel_pil(w, h, radius=18):
    """Modern indigo-to-purple sidebar with subtle neon waves."""
    w, h = max(16, int(w)), max(16, int(h))
    S = 2
    W, H, r = w * S, h * S, radius * S
    base = _v_gradient(W, H, (7, 20, 68), (42, 22, 104)).convert("RGBA")
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.ellipse([W*0.15, H*0.68, W*1.05, H*1.15], fill=(51, 104, 255, 105))
    d.ellipse([W*0.45, H*0.78, W*1.15, H*1.22], fill=(176, 55, 255, 90))
    d.line([(0, H*0.82), (W*0.35, H*0.73), (W*0.70, H*0.80), (W, H*0.70)],
           fill=(95, 205, 255, 100), width=2*S)
    layer = layer.filter(ImageFilter.GaussianBlur(max(2, W // 85)))
    base.alpha_composite(layer)
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, W - 1, H - 1], r, fill=255)
    out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    out.paste(base, (0, 0), mask)
    return out.resize((w, h), Image.LANCZOS)


# ----------------------------------------------------------------- cards ----
def make_glass_card(w, h, radius=16, fill_top="#FFFFFF", fill_bottom="#F7F9FF", alpha=240,
                    border="#FFFFFF", border_alpha=210, shadow=True):
    """Frosted-glass card with a hairline border and a very subtle blurred shadow.
    Returns (PhotoImage, margin) — draw the image at (x - margin, y - margin)."""
    key = ("card", int(w), int(h), radius, fill_top, fill_bottom, alpha, border, border_alpha, shadow)

    def build():
        wi, hi = int(w), int(h)
        blur, dy = 7, 4
        m = (blur * 2 + dy + 2) if shadow else 2
        W, H = wi + 2 * m, hi + 2 * m
        out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        if shadow:
            sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
            ImageDraw.Draw(sh).rounded_rectangle([m, m + dy, m + wi - 1, m + hi - 1 + dy], radius,
                                                  fill=(88, 104, 190, 34))
            out.alpha_composite(sh.filter(ImageFilter.GaussianBlur(blur)))
        S = 2
        grad = _v_gradient(wi * S, hi * S, _hex_rgb(fill_top), _hex_rgb(fill_bottom))
        mask = Image.new("L", (wi * S, hi * S), 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, wi * S - 1, hi * S - 1], radius * S, fill=alpha)
        card = Image.new("RGBA", (wi * S, hi * S), (0, 0, 0, 0))
        card.paste(grad, (0, 0), mask)
        ImageDraw.Draw(card).rounded_rectangle([0, 0, wi * S - 1, hi * S - 1], radius * S,
                                               outline=_hex_rgb(border) + (border_alpha,), width=S)
        out.alpha_composite(card.resize((wi, hi), Image.LANCZOS), (m, m))
        return ImageTk.PhotoImage(out), m

    return _cache_get(key, build)


def make_sparkline(w, h, color, seed=0):
    """Soft area-chart decoration (pure ornament, like the design reference)."""
    key = ("spark", int(w), int(h), color, seed)

    def build():
        S = 2
        W, H = int(w) * S, int(h) * S
        shapes = [
            [0.10, 0.22, 0.42, 0.34, 0.60, 0.48, 0.74, 0.66],
            [0.08, 0.16, 0.30, 0.52, 0.40, 0.66, 0.58, 0.82],
            [0.12, 0.10, 0.24, 0.20, 0.34, 0.30, 0.52, 0.78],
            [0.06, 0.20, 0.30, 0.44, 0.58, 0.36, 0.70, 0.84],
        ]
        ctrl = shapes[seed % len(shapes)]
        n = len(ctrl)
        pts = []
        for x in range(0, W + 1, 3):
            t = x / float(W) * (n - 1)
            i = min(int(t), n - 2)
            f = t - i
            f = (1 - math.cos(f * math.pi)) / 2
            v = ctrl[i] * (1 - f) + ctrl[i + 1] * f
            pts.append((x, H - v * (H - 4 * S)))
        poly_pts = [(0, H)] + pts + [(W, H)]
        pmask = Image.new("L", (W, H), 0)
        ImageDraw.Draw(pmask).polygon(poly_pts, fill=255)
        grad = ImageOps.invert(Image.linear_gradient("L").resize((W, H))).point(lambda v: 22 + v * 118 // 255)
        alpha = ImageChops.multiply(pmask, grad)
        img = Image.new("RGBA", (W, H), _hex_rgb(color) + (0,))
        img.putalpha(alpha)
        return ImageTk.PhotoImage(img.resize((int(w), int(h)), Image.LANCZOS))

    return _cache_get(key, build)


def make_avatar(size, c_top, c_bottom, ring=True):
    """Gradient circle avatar with a soft translucent ring (letter is drawn by the caller)."""
    key = ("avatar", int(size), c_top, c_bottom, ring)

    def build():
        pad = 4 if ring else 0
        total = int(size) + pad * 2
        S = 3
        out = Image.new("RGBA", (total * S, total * S), (0, 0, 0, 0))
        if ring:
            ImageDraw.Draw(out).ellipse([0, 0, total * S - 1, total * S - 1],
                                        fill=_hex_rgb(c_top) + (70,))
        g = _v_gradient(int(size) * S, int(size) * S, _hex_rgb(c_top), _hex_rgb(c_bottom))
        m = Image.new("L", (int(size) * S, int(size) * S), 0)
        ImageDraw.Draw(m).ellipse([0, 0, int(size) * S - 1, int(size) * S - 1], fill=255)
        out.paste(g, (pad * S, pad * S), m)
        return ImageTk.PhotoImage(out.resize((total, total), Image.LANCZOS))

    return _cache_get(key, build)


def make_pill_image(w, h, c_left, c_right, radius=None, horizontal=True):
    """Gradient rounded button/pill (horizontal by default) as a PhotoImage."""
    radius = radius if radius is not None else h // 2
    key = ("pill", int(w), int(h), c_left, c_right, radius, horizontal)
    return _cache_get(key, lambda: make_gradient_rounded_image(w, h, radius, c_left, c_right,
                                                               horizontal=horizontal))



class RoundedCard(tk.Frame):
    """
    A drop-in, self-sizing rounded-corner + soft-shadow card.
    Usage: card = RoundedCard(parent, fill=CARD_COLOR, page_bg=pal["bg"])
           card.pack(...)                 # place the card itself like any Frame
           tk.Label(card.body, ...).pack  # put content INSIDE card.body
    The card measures card.body automatically and redraws whenever its
    content changes size, so normal pack/grid layouts inside `.body` just work.
    """
    def __init__(self, parent, fill, page_bg, radius=14, border=None, border_width=0,
                 shadow=True, width=None, height=None, glass=False, **body_kwargs):
        super().__init__(parent, bg=page_bg, highlightthickness=0, bd=0)
        self._fill = fill
        self._page_bg = page_bg
        self._radius = radius
        self._border = border
        self._border_width = border_width
        self._shadow = shadow
        self._fixed_w = width
        self._fixed_h = height
        self._glass = glass
        self._shadow_tone = _blend(page_bg, "#000000", 0.10)
        self._glass_img = None
        self._shadow_img = None

        self.canvas = tk.Canvas(self, bg=page_bg, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)

        # NOTE: width/height (when given) are enforced purely via the canvas
        # create_window(width=, height=) override below — we deliberately avoid
        # body.configure(width=..)+pack_propagate(False), since that would freeze
        # the body's height at whatever it happened to be before children were
        # laid out. This way a fixed width still lets height auto-fit content.
        self.body = tk.Frame(self.canvas, bg=fill, **body_kwargs)
        self._win = self.canvas.create_window(0, 0, anchor="nw", window=self.body)
        self.body.bind("<Configure>", self._redraw)

    def _redraw(self, event=None):
        w = self._fixed_w or self.body.winfo_reqwidth()
        h = self._fixed_h or self.body.winfo_reqheight()
        pad = self._radius + (6 if self._shadow else 0)
        cw, ch = max(1, w + 2 * pad), max(1, h + 2 * pad)
        self.canvas.config(width=cw, height=ch)
        self.canvas.delete("bg")

        if self._glass:
            # Frosted-glass look: a soft blurred shadow blob, then a semi-transparent
            # near-white gradient panel with rounded corners and a subtle light border.
            if self._shadow:
                self._shadow_img = make_glow_rect_image(w, h, self._radius, "#312E81", alpha=55, blur=8)
                self.canvas.create_image(cw / 2, pad + h / 2 + 6, image=self._shadow_img, tags="bg")
            top = _blend(self._fill, "#FFFFFF", 0.65)
            bottom = _blend(self._fill, "#FFFFFF", 0.15)
            self._glass_img = make_gradient_rounded_image(
                w + 4, h + 4, self._radius, top, bottom, alpha=225,
                border_color=self._border or "#FFFFFF", border_width=1)
            self.canvas.create_image(pad - 2, pad - 2, anchor="nw", image=self._glass_img, tags="bg")
        else:
            if self._shadow:
                draw_round_rect(self.canvas, pad - 2, pad, pad + w + 2, pad + h + 4,
                                 self._radius, fill=self._shadow_tone, outline="", tags="bg")
            outline = self._border if self._border else self._fill
            draw_round_rect(self.canvas, pad - 2, pad - 2, pad + w + 2, pad + h + 2,
                             self._radius, fill=self._fill, outline=outline,
                             width=self._border_width, tags="bg")
        self.canvas.tag_lower("bg")
        self.canvas.coords(self._win, pad, pad)
        # Only force a dimension the caller fixed; otherwise let the body keep its
        # natural size so widgets added later (e.g. the login buttons) are never
        # clipped and still trigger a <Configure> -> redraw.
        self.canvas.itemconfig(self._win, width=self._fixed_w or 0, height=self._fixed_h or 0)


class StretchyRoundedCard(tk.Frame):
    """A rounded-corner card that STRETCHES to fill whatever space its geometry
    manager gives it (pack fill='both'/'x', expand=True) — unlike RoundedCard,
    which sizes itself to its content. Put content inside `.body`."""
    def __init__(self, parent, fill, page_bg, radius=14, border=None, border_width=1,
                 width=120, height=90, **body_kwargs):
        super().__init__(parent, bg=page_bg, highlightthickness=0, bd=0)
        self._fill = fill
        self._border = border or fill
        self._border_width = border_width
        self._radius = radius
        self.canvas = tk.Canvas(self, bg=page_bg, highlightthickness=0, bd=0, width=width, height=height)
        self.canvas.pack(fill="both", expand=True)
        self.body = tk.Frame(self.canvas, bg=fill, **body_kwargs)
        self._win = self.canvas.create_window(0, 0, anchor="nw", window=self.body)
        self.canvas.bind("<Configure>", self._request_redraw)
        # Content added to `.body` *after* construction (e.g. a list built by the
        # caller) must not get silently clipped by a size computed too early —
        # also redraw whenever the body's own required size changes.
        self.body.bind("<Configure>", self._request_redraw)
        self._redraw_pending = False

    def _request_redraw(self, event=None):
        # Multiple Configure events can fire in a burst while content is still
        # being built (each nested widget added triggers its own event). Redrawing
        # synchronously on every one of them risks using a transient, not-yet-final
        # width/height. Coalescing into a single after_idle call ensures we only
        # ever draw once Tk's geometry pass has actually settled.
        if self._redraw_pending:
            return
        self._redraw_pending = True
        self.after_idle(self._redraw)

    def _redraw(self, event=None):
        self._redraw_pending = False
        if not self.winfo_exists():
            return
        w = self.canvas.winfo_width()
        if w < 4:
            return
        self.body.update_idletasks()
        # Never size the body smaller than its own content needs — only stretch
        # it larger when the canvas (i.e. the parent's pack slot) offers more room.
        req_h = self.body.winfo_reqheight()
        cur_h = self.canvas.winfo_height()
        h = max(cur_h, req_h)
        if h > cur_h:
            self.canvas.config(height=h)
        self.canvas.delete("bg")
        draw_round_rect(self.canvas, 1, 1, w - 1, h - 1, self._radius,
                         fill=self._fill, outline=self._border, width=self._border_width, tags="bg")
        self.canvas.tag_lower("bg")
        self.canvas.coords(self._win, 0, 0)
        # Force the height only when the parent stretched us taller than the content.
        self.canvas.itemconfig(self._win, width=w, height=(h if cur_h > req_h else 0))


class RoundedButton(tk.Canvas):
    """Soft vertical-gradient rounded pill button (glassy 'sheen' by default).
    Drop-in usage: RoundedButton(parent, text, bg_color, command).pack(...)"""
    def __init__(self, parent, text, color, command=None, fg="white",
                 font=("Segoe UI", 12, "bold"), radius=10, padx=18, pady=13,
                 page_bg=None, gradient=None, **kwargs):
        page_bg = page_bg or (parent.cget("bg") if hasattr(parent, "cget") else BG_COLOR)
        super().__init__(parent, bg=page_bg, highlightthickness=0, bd=0, cursor="hand2", **kwargs)
        self.command = command
        self._base_color = color
        self._text = text
        self._fg = fg
        self._font = font
        self._radius = radius
        self._padx = padx
        self._pady = pady
        self._gradient = gradient  # explicit (top, bottom) tuple, or None for an auto sheen
        self._hovering = False
        self._img = None
        self.bind("<Configure>", self._redraw)
        self.bind("<Button-1>", lambda e: self.command() if self.command else None)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self._measure()

    def _colors(self):
        if self._gradient:
            top, bottom = self._gradient
        else:
            top = _blend(self._base_color, "#FFFFFF", 0.18)
            bottom = _blend(self._base_color, "#000000", 0.10)
        if self._hovering:
            top = _blend(top, "#000000", 0.10)
            bottom = _blend(bottom, "#000000", 0.10)
        return top, bottom

    def _measure(self):
        tmp = tk.Label(self, text=self._text, font=self._font)
        tmp.update_idletasks()
        self._req_w = tmp.winfo_reqwidth() + self._padx * 2
        self._req_h = tmp.winfo_reqheight() + self._pady * 2
        tmp.destroy()
        self.config(width=self._req_w, height=self._req_h)
        self._redraw()

    def _redraw(self, event=None):
        w = self.winfo_width() or self._req_w
        h = self.winfo_height() or self._req_h
        if w < 2 or h < 2:
            return
        top, bottom = self._colors()
        self._img = make_gradient_rounded_image(w, h, self._radius, top, bottom)
        self.delete("all")
        self.create_image(0, 0, anchor="nw", image=self._img)
        self.create_text(w / 2, h / 2, text=self._text, fill=self._fg, font=self._font)

    def _on_enter(self, e):
        self._hovering = True
        self._redraw()

    def _on_leave(self, e):
        self._hovering = False
        self._redraw()

    def config_text(self, text):
        self._text = text
        self._redraw()


def get_palette() -> dict:
    """Central colour set used by the redesigned screens (single light theme)."""
    return {
        "bg": BG_COLOR, "card": CARD_COLOR, "border": BORDER_COLOR,
        "text": TEXT_COLOR, "muted": MUTED_TEXT,
        "sidebar": "#161A30", "sidebar_line": "#272C4C",
        "chat_bg": DEFAULT_CHAT_BG, "receiver_bubble": RECEIVER_COLOR,
        "sender_bubble": SENDER_COLOR,
        "primary": PRIMARY_COLOR, "primary_dark": PRIMARY_DARK,
    }


def _shade(hex_color, factor=0.85):
    """UI-only helper: darken a hex color for hover/pressed feedback."""
    try:
        hex_color = hex_color.lstrip("#")
        r, g, b = (int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
        r, g, b = (max(0, min(255, int(c * factor))) for c in (r, g, b))
        return f"#{r:02x}{g:02x}{b:02x}"
    except Exception:
        return hex_color

# --- 1. ROUND SEND BUTTON ---
class WhatsAppSendButton(tk.Canvas):
    def __init__(self, parent, command=None, **kwargs):
        page_bg = parent.cget("bg") if hasattr(parent, "cget") else "white"
        super().__init__(parent, width=48, height=48, bg=page_bg, highlightthickness=0, cursor="hand2", **kwargs)
        self.command = command
        self._top = _blend(PRIMARY_COLOR, "#FFFFFF", 0.20)
        self._bottom = _blend(PRIMARY_COLOR, "#8B5CF6", 0.35)
        self._top_hover = _blend(self._top, "#000000", 0.12)
        self._bottom_hover = _blend(self._bottom, "#000000", 0.12)
        self._img = None
        self.shadow = self.create_oval(6, 8, 43, 45, fill=_blend(page_bg, "#000000", 0.12), outline="")
        self._draw(hover=False)
        self.text_id = self.create_text(23, 22, text="➤", fill="white", font=("Segoe UI", 15, "bold"))
        self.bind("<Button-1>", lambda e: self.on_click())
        self.bind("<Enter>", lambda e: self._draw(hover=True))
        self.bind("<Leave>", lambda e: self._draw(hover=False))

    def _draw(self, hover):
        top = self._top_hover if hover else self._top
        bottom = self._bottom_hover if hover else self._bottom
        self._img = make_gradient_rounded_image(38, 38, 19, top, bottom)
        if hasattr(self, "circle_img"):
            self.itemconfig(self.circle_img, image=self._img)
        else:
            self.circle_img = self.create_image(4, 4, anchor="nw", image=self._img)

    def on_click(self):
        if self.command:
            self.command()

# --- 2. CUSTOM ENTRY ---
class CustomEntry(tk.Frame):
    """Rounded-pill text field. Same public API as before: .get()/.delete()/
    .insert_text()/.entry — only the visual chrome changed."""
    def __init__(self, parent, placeholder, show="", typing_callback=None, emoji_callback=None):
        pal = get_palette()
        entry_bg = "white"
        page_bg = parent.cget("bg") if hasattr(parent, "cget") else pal["bg"]
        super().__init__(parent, bg=page_bg, highlightthickness=0, bd=0)

        self._entry_bg = entry_bg
        self._border = "#D9DCF0"
        self._border_now = self._border
        self._radius = 18
        self._height = 42

        self.canvas = tk.Canvas(self, bg=page_bg, height=self._height, width=10, highlightthickness=0, bd=0)
        self.canvas.pack(fill="x", expand=True)

        self.inner = tk.Frame(self.canvas, bg=entry_bg)
        self._win = self.canvas.create_window(0, self._height // 2, anchor="w", window=self.inner)

        if emoji_callback:
            self.emoji_btn = tk.Button(self.inner, text="😀", font=("Segoe UI", 12), bg=entry_bg, bd=0,
                                     cursor="hand2", command=emoji_callback, activebackground=entry_bg)
            self.emoji_btn.pack(side="left", padx=(14, 2))

        self.entry = tk.Entry(self.inner, font=("Segoe UI", 12), bd=0, show=show,
                               fg=pal["text"], bg=entry_bg, insertbackground=PRIMARY_COLOR,
                               highlightthickness=0)
        self.entry.insert(0, placeholder)
        self.typing_callback = typing_callback
        self.entry.bind("<FocusIn>", lambda e: self.on_focus_in(placeholder))
        self.entry.bind("<FocusOut>", lambda e: self.on_focus_out(placeholder))

        if typing_callback:
            self.entry.bind("<KeyRelease>", lambda e: self.typing_callback())

        pad_left = 4 if emoji_callback else 16
        self.entry.pack(side="left", fill="x", expand=True, padx=(pad_left, 14), pady=10)

        self.canvas.bind("<Configure>", self._redraw)

    def _redraw(self, event=None):
        w = self.canvas.winfo_width()
        h = self._height
        if w < 4:
            return
        self.canvas.delete("bg")
        draw_round_rect(self.canvas, 1, 1, w - 1, h - 1, self._radius,
                         fill=self._entry_bg, outline=self._border_now, width=1, tags="bg")
        self.canvas.tag_lower("bg")
        self.canvas.coords(self._win, 2, h // 2)
        self.canvas.itemconfig(self._win, width=w - 4)

    def on_focus_in(self, placeholder):
        if self.entry.get() == placeholder:
            self.entry.delete(0, tk.END)
        self._border_now = PRIMARY_COLOR      # rounded focus ring
        self._redraw()

    def on_focus_out(self, placeholder):
        if not self.entry.get():
            self.entry.insert(0, placeholder)
        self._border_now = self._border
        self._redraw()

    def get(self):
        return self.entry.get()
    
    def delete(self, start, end):
        self.entry.delete(start, end)
    
    def insert_text(self, text):
        if self.entry.get() == "Type a message...":
            self.entry.delete(0, tk.END)
        self.entry.insert(tk.END, text)

# --- 3. STYLED BUTTON ---
class StyledButton(RoundedButton):
    """Rounded pill call-to-action button. Same constructor signature as before."""
    def __init__(self, parent, text, color, command, center=False):
        super().__init__(parent, text, color, command, radius=10, padx=18, pady=13)

# --- 4. AUTH FRAME ---
class AuthFrame(tk.Frame):
    """Premium NexaChat authentication screen.

    Keeps the original public API (.get_data() and .button_area) so the
    existing MainApp login/register logic continues to work unchanged.
    """
    def __init__(self, parent):
        pal = get_palette()
        super().__init__(parent, bg="#EEF3FD", highlightthickness=0)

        # --- full-page background ---
        self.bg_canvas = tk.Canvas(self, bg="#EEF3FD", highlightthickness=0, bd=0)
        self.bg_canvas.pack(fill="both", expand=True)
        self.bg_canvas.bind("<Configure>", self._draw_background)

        # Main split layout. The left panel is the product story; the right
        # panel is deliberately compact so the login action remains obvious.
        shell = tk.Frame(self.bg_canvas, bg="#EEF3FD")
        self._shell_window = self.bg_canvas.create_window(0, 0, anchor="nw", window=shell)
        self.shell = shell

        shell.grid_columnconfigure(0, weight=6, minsize=470)
        shell.grid_columnconfigure(1, weight=5, minsize=430)
        shell.grid_rowconfigure(0, weight=1)

        # ==================== LEFT BRAND PANEL ====================
        left = tk.Frame(shell, bg="#102C66")
        left.grid(row=0, column=0, sticky="nsew", padx=(24, 12), pady=24)

        # Decorative glow circles / lines.
        deco = tk.Canvas(left, bg="#102C66", highlightthickness=0, bd=0)
        deco.place(relx=0, rely=0, relwidth=1, relheight=1)
        deco.bind("<Configure>", lambda e: self._draw_auth_art(deco))

        content = tk.Frame(left, bg="#102C66")
        content.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.78)

        # Logo mark
        mark = tk.Canvas(content, width=68, height=68, bg="#102C66", highlightthickness=0)
        mark.pack(anchor="w", pady=(0, 22))
        mark.create_oval(3, 3, 65, 65, fill="#1D4ED8", outline="")
        mark.create_oval(10, 10, 58, 58, fill="#4F46E5", outline="")
        mark.create_oval(18, 18, 50, 50, fill="#22D3EE", outline="")
        mark.create_oval(25, 25, 43, 43, fill="#FFFFFF", outline="")

        tk.Label(content, text="NexaChat", font=("Segoe UI", 31, "bold"),
                 bg="#102C66", fg="white").pack(anchor="w")
        tk.Label(content, text="CONNECT  •  CHAT  •  GROW", font=("Segoe UI", 9, "bold"),
                 bg="#102C66", fg="#8BE9FF").pack(anchor="w", pady=(4, 16))

        tk.Label(content,
                 text="A smarter space for real-time conversations,\ngroups, statuses and meaningful connections.",
                 font=("Segoe UI", 13), bg="#102C66", fg="#DCE8FF",
                 justify="left", wraplength=380).pack(anchor="w")

        # Feature cards — directly tied to this project's functionality.
        features = [
            ("01", "Real-time conversations", "Chat privately and stay connected."),
            ("02", "Groups & status", "Share updates and collaborate together."),
            ("03", "Smart analytics", "Understand your conversation activity."),
        ]
        feat_box = tk.Frame(content, bg="#102C66")
        feat_box.pack(fill="x", pady=(28, 0))
        for num, title, desc in features:
            row = tk.Frame(feat_box, bg="#173875", highlightthickness=1,
                           highlightbackground="#2C4E88")
            row.pack(fill="x", pady=5, ipady=8)
            tk.Label(row, text=num, font=("Segoe UI", 9, "bold"),
                     bg="#173875", fg="#63E6FF", width=4).pack(side="left", padx=(10, 2))
            txt = tk.Frame(row, bg="#173875")
            txt.pack(side="left", fill="x", expand=True, padx=(4, 10))
            tk.Label(txt, text=title, font=("Segoe UI", 10, "bold"),
                     bg="#173875", fg="white", anchor="w").pack(fill="x")
            tk.Label(txt, text=desc, font=("Segoe UI", 8),
                     bg="#173875", fg="#AFC5EA", anchor="w").pack(fill="x", pady=(2, 0))

        # Small conversation preview at the bottom.
        preview = tk.Frame(content, bg="#0C2555", highlightthickness=1,
                           highlightbackground="#2B4E8B")
        preview.pack(fill="x", pady=(22, 0))
        tk.Label(preview, text="●  ONLINE NOW", font=("Segoe UI", 8, "bold"),
                 bg="#0C2555", fg="#34D399").pack(anchor="w", padx=14, pady=(10, 4))
        tk.Label(preview, text="“Better conversations start here.”",
                 font=("Segoe UI", 10, "italic"), bg="#0C2555", fg="#E8F1FF").pack(anchor="w", padx=14, pady=(0, 10))

        # ==================== RIGHT LOGIN PANEL ====================
        right = tk.Frame(shell, bg="#EEF3FD")
        right.grid(row=0, column=1, sticky="nsew", padx=(12, 24), pady=24)

        # Center card using place so it stays visually balanced on large screens.
        card_host = tk.Frame(right, bg="#EEF3FD")
        card_host.place(relx=0.5, rely=0.5, anchor="center", relwidth=0.88)

        # Top mini brand row.
        top = tk.Frame(card_host, bg="#EEF3FD")
        top.pack(fill="x", pady=(0, 14))
        tk.Label(top, text="NEXACHAT", font=("Segoe UI", 10, "bold"),
                 bg="#EEF3FD", fg="#2563EB").pack(side="left")
        tk.Label(top, text="SECURE ACCESS", font=("Segoe UI", 8, "bold"),
                 bg="#EEF3FD", fg="#8A96AB").pack(side="right")

        glass_fill = "#FFFFFF"
        card = RoundedCard(card_host, fill=glass_fill, page_bg="#EEF3FD", radius=24,
                           border="#E1E8F5", border_width=1, shadow=True, glass=True,
                           width=410, padx=30, pady=30)
        card.pack(fill="x")

        tk.Label(card.body, text="Welcome back 👋", font=("Segoe UI", 22, "bold"),
                 bg=glass_fill, fg="#10233F").pack(anchor="w")
        tk.Label(card.body, text="Sign in to continue your conversations.",
                 font=("Segoe UI", 10), bg=glass_fill, fg="#72819A").pack(anchor="w", pady=(4, 24))

        # Username
        tk.Label(card.body, text="USERNAME / NEXA ID", font=("Segoe UI", 8, "bold"),
                 bg=glass_fill, fg="#66758D").pack(anchor="w", pady=(0, 6))
        self.username_field = CustomEntry(card.body, "Username")
        self.username_field.pack(fill="x", pady=(0, 15))

        # Password with an eye toggle.
        tk.Label(card.body, text="PASSWORD", font=("Segoe UI", 8, "bold"),
                 bg=glass_fill, fg="#66758D").pack(anchor="w", pady=(0, 6))
        pass_row = tk.Frame(card.body, bg=glass_fill)
        pass_row.pack(fill="x", pady=(0, 8))
        self.password_field = CustomEntry(pass_row, "Password", show="*")
        self.password_field.pack(side="left", fill="x", expand=True)
        self._password_visible = False
        eye = tk.Button(pass_row, text="Show", font=("Segoe UI", 8, "bold"),
                         bg="#EEF3FF", fg="#3658C9", bd=0, relief="flat",
                         cursor="hand2", padx=10, pady=7, command=self._toggle_password)
        eye.place(relx=1.0, rely=0.5, anchor="e", x=-8)
        self._eye_button = eye

        # Trust/status strip. It is visual only and makes the product feel intentional.
        trust = tk.Frame(card.body, bg="#F4F8FF")
        trust.pack(fill="x", pady=(4, 12))
        tk.Label(trust, text="✓", font=("Segoe UI", 10, "bold"), bg="#F4F8FF", fg="#16A34A").pack(side="left", padx=(10, 4), pady=7)
        tk.Label(trust, text="Your chat data stays on your local app database.",
                 font=("Segoe UI", 8), bg="#F4F8FF", fg="#66758D").pack(side="left", pady=7)

        self.button_area = tk.Frame(card.body, bg=glass_fill)
        self.button_area.pack(fill="x", pady=(4, 0))

        tk.Label(card.body, text="New to NexaChat?  Create an account to get started.",
                 font=("Segoe UI", 8), bg=glass_fill, fg="#8A96AB").pack(anchor="center", pady=(18, 0))

        # Bottom brand footer.
        tk.Label(card_host, text="NexaChat  •  Connect · Chat · Grow",
                 font=("Segoe UI", 8), bg="#EEF3FD", fg="#8A96AB").pack(pady=(14, 0))

    def _toggle_password(self):
        self._password_visible = not self._password_visible
        self.password_field.entry.config(show="" if self._password_visible else "*")
        if hasattr(self, "_eye_button"):
            self._eye_button.config(text="Hide" if self._password_visible else "Show")

    def _draw_background(self, event=None):
        w = max(1, self.winfo_width())
        h = max(1, self.winfo_height())
        self.bg_canvas.delete("bg")
        # Very light layered background blooms.
        self.bg_canvas.create_oval(-180, h-280, 280, h+180, fill="#DDEBFF", outline="", tags="bg")
        self.bg_canvas.create_oval(w-260, -170, w+180, 270, fill="#E8E1FF", outline="", tags="bg")
        self.bg_canvas.create_line(0, 90, w, 40, fill="#E3EAF7", width=2, tags="bg")
        self.bg_canvas.tag_lower("bg")
        self.bg_canvas.coords(self._shell_window, 0, 0)
        self.bg_canvas.itemconfig(self._shell_window, width=w, height=h)

    def _draw_auth_art(self, canvas):
        w = canvas.winfo_width()
        h = canvas.winfo_height()
        if w < 10 or h < 10:
            return
        canvas.delete("art")
        # Soft decorative rings.
        canvas.create_oval(w-220, -90, w+90, 220, outline="#214A91", width=2, tags="art")
        canvas.create_oval(w-170, -40, w+40, 170, outline="#1B75B9", width=1, tags="art")
        canvas.create_oval(-100, h-170, 160, h+90, outline="#193E7A", width=2, tags="art")
        # Network dots / connection lines.
        pts = [(w-95, h-110), (w-145, h-55), (w-50, h-45), (w-105, h-15)]
        for a,b in [(0,1),(0,2),(1,3),(2,3)]:
            canvas.create_line(*pts[a], *pts[b], fill="#2A5A9F", width=2, tags="art")
        for x,y in pts:
            canvas.create_oval(x-5,y-5,x+5,y+5,fill="#22D3EE",outline="",tags="art")
        canvas.tag_lower("art")

    def get_data(self):
        return self.username_field.get(), self.password_field.get()

# --- 5. CHAT HEADER ---
class ChatHeader(tk.Frame):
    def __init__(self, parent, name, is_blocked=False, back_callback=None, block_callback=None,
                 clear_callback=None, search_callback=None, **kwargs):
        super().__init__(parent, bg="white", height=66, **kwargs)
        self.pack(fill="x", side="top")
        self.pack_propagate(False)
        self.search_callback = search_callback
        self.is_search_visible = False

        shadow = tk.Frame(self, bg=BORDER_COLOR, height=1)
        shadow.place(relx=0, rely=1.0, relwidth=1, anchor="sw")

        if back_callback:
            back_btn = tk.Canvas(self, width=34, height=34, bg="white", highlightthickness=0, cursor="hand2")
            back_btn.create_oval(2, 2, 32, 32, fill=PRIMARY_LIGHT, outline=PRIMARY_LIGHT)
            back_btn.create_text(17, 17, text="‹", fill=PRIMARY_COLOR, font=("Segoe UI", 16, "bold"))
            back_btn.bind("<Button-1>", lambda e: back_callback())
            back_btn.pack(side="left", padx=(14, 6))

        text_container = tk.Frame(self, bg="white")
        text_container.pack(side="left", padx=(8, 2))

        self.name_lbl = tk.Label(text_container, text=name, font=("Segoe UI", 12, "bold"), bg="white", fg=TEXT_COLOR)
        self.name_lbl.pack(anchor="w")

        self.status_var = tk.StringVar(value="")
        self.status_lbl = tk.Label(text_container, textvariable=self.status_var, font=("Segoe UI", 8), bg="white", fg=MUTED_TEXT)
        self.status_lbl.pack(anchor="w")

        self.search_frame = tk.Frame(self, bg="white")
        self.search_frame.pack(side="right", padx=(0, 6))

        self.search_btn = tk.Button(
            self.search_frame, text="🔍", font=("Segoe UI Emoji", 12),
            bd=0, bg="white", cursor="hand2", command=self.toggle_search, activebackground="white"
        )
        self.search_btn.pack(side="right", padx=5)

        self.search_entry = tk.Entry(self.search_frame, font=("Segoe UI", 10), bg=BG_COLOR, bd=0,
                                      relief="flat", highlightthickness=1, highlightbackground=BORDER_COLOR,
                                      highlightcolor=PRIMARY_COLOR)
        self.search_entry.bind("<KeyRelease>", self.on_search_type)

        if clear_callback:
            self.clear_btn = tk.Button(self, text="Clear Chat", fg=NOTIF_RED, bg="white", bd=0, cursor="hand2",
                                     command=clear_callback, font=("Segoe UI", 9, "bold"), activebackground="white")
            self.clear_btn.pack(side="right", padx=6)
        
        if block_callback:
            btn_text = "Unblock" if is_blocked else "Block"
            btn_color = SUCCESS_COLOR if is_blocked else NOTIF_RED
            self.block_btn = tk.Button(self, text=btn_text, fg=btn_color, bg="white", bd=0, cursor="hand2",
                                     command=block_callback, font=("Segoe UI", 9, "bold"), activebackground="white")
            self.block_btn.pack(side="right", padx=6)

    def toggle_search(self):
        if not self.is_search_visible:
            self.search_entry.pack(side="right", padx=5, ipady=5)
            self.search_entry.focus_set()
            if hasattr(self, 'block_btn'): self.block_btn.pack_forget()
            if hasattr(self, 'clear_btn'): self.clear_btn.pack_forget()
            self.is_search_visible = True
        else:
            self.search_entry.delete(0, tk.END)
            self.search_entry.pack_forget()
            if hasattr(self, 'block_btn'): self.block_btn.pack(side="right", padx=10)
            if hasattr(self, 'clear_btn'): self.clear_btn.pack(side="right", padx=10)
            self.is_search_visible = False
            if self.search_callback: self.search_callback("")

    def on_search_type(self, event):
        if self.search_callback:
            self.search_callback(self.search_entry.get())

    def update_header_status(self, is_online=None, is_typing=None, last_seen=None, member_count=None):
        if member_count is not None:
            self.status_var.set(f"{member_count} members")
            self.status_lbl.config(fg="#6B7280")
        elif is_typing:
            self.status_var.set("typing...")
            self.status_lbl.config(fg=SUCCESS_COLOR)
        elif is_online:
            self.status_var.set("Online")
            self.status_lbl.config(fg=SUCCESS_COLOR)
        else:
            self.status_var.set(f"Last seen: {last_seen}" if last_seen else "Offline")
            self.status_lbl.config(fg="#6B7280")

# --- 6. REPLY PREVIEW BAR ---
class ReplyPreviewBar(tk.Frame):
    """
    Input box paina reply preview chupistundi (WhatsApp style).
    User 'Reply' click chessinappudu ee bar appear avutundi.
    Original message text + cancel (X) button untundi.
    """
    def __init__(self, parent, sender_name, message_text, on_cancel):
        super().__init__(parent, bg="#EEF0FF",
                         highlightbackground=PRIMARY_COLOR, highlightthickness=1,
                         padx=8, pady=4)

        # Left colored strip (WhatsApp style)
        left_bar = tk.Frame(self, bg=PRIMARY_COLOR, width=3)
        left_bar.pack(side="left", fill="y", padx=(0, 8))

        info_frame = tk.Frame(self, bg="#EEF0FF")
        info_frame.pack(side="left", fill="both", expand=True)

        # Sender name
        tk.Label(info_frame, text=f"↩ {sender_name}",
                 font=("Segoe UI", 9, "bold"), bg="#EEF0FF", fg=PRIMARY_COLOR).pack(anchor="w")

        # Message preview (max 60 chars)
        preview = message_text[:60] + "..." if len(message_text) > 60 else message_text
        tk.Label(info_frame, text=preview, font=("Segoe UI", 9),
                 bg="#EEF0FF", fg="#6B7280").pack(anchor="w")

        # Cancel (X) button
        tk.Button(self, text="✕", font=("Segoe UI", 10, "bold"),
                  bg="#EEF0FF", fg="#6B7280", bd=0, cursor="hand2",
                  command=on_cancel).pack(side="right", padx=5)


# --- 7. CHAT BUBBLE ---
class ChatBubble(tk.Frame):
    def __init__(self, parent, message, timestamp="--:--", is_sender=True, msg_id=None,
                 status="sent", delete_callback=None, star_callback=None, is_starred=0,
                 message_type='text', file_path=None, sender_name=None, chat_bg=None,
                 reply_callback=None, reply_to_text=None, reply_to_sender=None,
                 scroll_to_callback=None, reply_to_id=None,
                 edit_callback=None, is_edited=0):
        """
        edit_callback : Right-click 'Edit' select chessinappudu call avutundi (msg_id, text pass avutundi)
        is_edited     : 1 aithe message edit ayyindi — '(edited)' label chupistundi
        """
        bg = chat_bg if chat_bg else DEFAULT_CHAT_BG
        super().__init__(parent, bg=bg)
        self.msg_id = msg_id
        self.status = status
        self.message = message
        self.delete_callback = delete_callback
        self.star_callback = star_callback
        self.reply_callback = reply_callback
        self.edit_callback = edit_callback
        self.is_starred = is_starred
        self.is_sender = is_sender

        bg_bubble = SENDER_COLOR if is_sender else RECEIVER_COLOR
        text_fg = SENDER_TEXT if is_sender else TEXT_COLOR
        muted_fg = _blend(SENDER_COLOR, "#FFFFFF", 0.55) if is_sender else TIME_COLOR
        align_anchor = "e" if is_sender else "w"

        bubble_container = tk.Frame(self, bg=bg)
        bubble_container.pack(anchor=align_anchor, padx=15, pady=3, fill="x")

        # A canvas hosts a rounded-rect background behind self.bubble (drawn once
        # the bubble's natural size is known, right at the end of __init__).
        self._bubble_canvas = tk.Canvas(bubble_container, bg=bg, highlightthickness=0, bd=0)
        self.bubble = tk.Frame(self._bubble_canvas, bg=bg_bubble, padx=12, pady=8)
        self.bubble.bind("<Button-3>", self.show_context_menu)

        # Group chat lo sender name chupiyyadam
        if sender_name and not is_sender:
            tk.Label(self.bubble, text=sender_name, font=("Segoe UI", 9, "bold"),
                     bg=bg_bubble, fg=PRIMARY_COLOR).pack(anchor="w")

        # --- Reply preview block (original message ki chinna preview) ---
        if reply_to_text:
            if is_sender:
                reply_bg = _blend(bg_bubble, "#FFFFFF", 0.20)
                reply_text_fg = "#EEF0FF"
                reply_sender_fg = "#FFFFFF"
            else:
                reply_bg = "#EEF0FA"
                reply_text_fg = "#555A70"
                reply_sender_fg = PRIMARY_COLOR
            reply_frame = tk.Frame(self.bubble, bg=reply_bg, padx=6, pady=4,
                                   cursor="hand2" if scroll_to_callback else "arrow")
            reply_frame.pack(fill="x", anchor="w", pady=(0, 5))

            strip = tk.Frame(reply_frame, bg=reply_sender_fg, width=3)
            strip.pack(side="left", fill="y", padx=(0, 6))

            inner = tk.Frame(reply_frame, bg=reply_bg)
            inner.pack(side="left", fill="both", expand=True)

            sender_label = reply_to_sender if reply_to_sender else "Unknown"
            tk.Label(inner, text=sender_label, font=("Segoe UI", 8, "bold"),
                     bg=reply_bg, fg=reply_sender_fg).pack(anchor="w")

            preview_text = reply_to_text[:60] + "..." if len(reply_to_text) > 60 else reply_to_text
            tk.Label(inner, text=preview_text, font=("Segoe UI", 8),
                     bg=reply_bg, fg=reply_text_fg, wraplength=220).pack(anchor="w")

            if scroll_to_callback and reply_to_id:
                for widget in (reply_frame, inner, strip):
                    widget.bind("<Button-1>",
                                lambda e, rid=reply_to_id: scroll_to_callback(rid))

        # --- Message content ---
        if message_type == 'image' and file_path and os.path.exists(file_path):
            try:
                img = Image.open(file_path)
                img.thumbnail((250, 250))
                self.img_tk = ImageTk.PhotoImage(img)
                self.img_label = tk.Label(self.bubble, image=self.img_tk, bg=bg_bubble)
                self.img_label.pack(anchor="w")
                self.img_label.bind("<Button-3>", self.show_context_menu)
            except:
                tk.Label(self.bubble, text="⚠️ Image Error", bg=bg_bubble, fg="red").pack()
        else:
            self.lbl = tk.Label(self.bubble, text=message, bg=bg_bubble, fg=text_fg,
                                font=("Segoe UI", 11), wraplength=280, justify="left")
            self.lbl.pack(anchor="w")
            self.lbl.bind("<Button-3>", self.show_context_menu)

        # --- Time + edited label + star + tick ---
        info_frame = tk.Frame(self.bubble, bg=bg_bubble)
        info_frame.pack(anchor="e", pady=(3, 0))

        if self.is_starred:
            tk.Label(info_frame, text="⭐", font=("Segoe UI", 8),
                     bg=bg_bubble, fg="orange").pack(side="left", padx=(0, 3))

        # (edited) label — message edit ayyite chupistundi
        if is_edited:
            tk.Label(info_frame, text="✏️ edited", font=("Segoe UI", 7, "italic"),
                     bg=bg_bubble, fg=muted_fg).pack(side="left", padx=(0, 4))

        self.time_lbl = tk.Label(info_frame, text=timestamp, font=("Segoe UI", 8),
                                 bg=bg_bubble, fg=muted_fg)
        self.time_lbl.pack(side="left")

        if is_sender:
            tick_symbol = "✓✓" if self.status == "seen" else "✓"
            tick_color = "#FFFFFF" if self.status == "seen" else muted_fg
            self.tick_lbl = tk.Label(info_frame, text=tick_symbol,
                                     font=("Segoe UI", 10, "bold"),
                                     bg=bg_bubble, fg=tick_color)
            self.tick_lbl.pack(side="left", padx=(3, 0))
            self.tick_lbl.bind("<Button-3>", self.show_context_menu)

        # --- Finalize: measure the built bubble, draw the rounded background,
        # embed the bubble frame inside the canvas, then place the canvas. ---
        self.bubble.update_idletasks()
        req_w = self.bubble.winfo_reqwidth()
        req_h = self.bubble.winfo_reqheight()
        radius = 15
        pad = radius
        cw, ch = req_w + 2 * pad, req_h + 2 * pad
        self._bubble_canvas.config(width=cw, height=ch)
        draw_round_rect(self._bubble_canvas, 0, 0, cw, ch, radius, fill=bg_bubble, outline=bg_bubble, tags="bg_poly")
        self._bubble_canvas.create_window(pad, pad, anchor="nw", window=self.bubble, width=req_w, height=req_h)
        self._bubble_canvas.pack(anchor=align_anchor)

    def flash_highlight(self, color="#FFFBEB", duration=800):
        """Briefly flashes the bubble (frame + rounded background together) — used
        when jumping to a message via a reply's 'scroll to original' click."""
        try:
            original_fill = self.bubble.cget("bg")
            self.bubble.config(bg=color)
            self._bubble_canvas.itemconfig("bg_poly", fill=color, outline=color)

            def _restore():
                if self.winfo_exists():
                    self.bubble.config(bg=original_fill)
                    self._bubble_canvas.itemconfig("bg_poly", fill=original_fill, outline=original_fill)
            self.after(duration, _restore)
        except Exception:
            pass

    def show_context_menu(self, event):
        menu = Menu(self, tearoff=0)

        # Reply option — top lo pettadam
        if self.reply_callback and self.msg_id:
            menu.add_command(label="↩ Reply",
                             command=lambda: self.reply_callback(self.msg_id))
            menu.add_separator()

        # Edit option — only sender's own messages ki chupistundi
        if self.edit_callback and self.msg_id and self.is_sender:
            menu.add_command(label="✏️ Edit",
                             command=lambda: self.edit_callback(self.msg_id, self.message))
            menu.add_separator()

        star_label = "Unstar Message" if self.is_starred else "Star Message"
        if self.star_callback:
            menu.add_command(label=star_label,
                             command=lambda: self.star_callback(self.msg_id))
        menu.add_separator()
        if self.delete_callback and self.msg_id:
            menu.add_command(label="Delete Message",
                             command=lambda: self.delete_callback(self.msg_id))
        menu.post(event.x_root, event.y_root)


class EmojiPicker(tk.Toplevel):
    def __init__(self, parent, callback):
        super().__init__(parent)
        self.title("Emoji")
        self.geometry("250x200")
        self.callback = callback
        emojis = ["😀", "😂", "😍", "😎", "👍", "🔥", "🙏", "❤️", "✨", "🎉", "😢", "😡", "🙄", "🤔", "👏", "🙌"]
        container = tk.Frame(self, bg="white", padx=10, pady=10)
        container.pack(expand=True, fill="both")
        r, c = 0, 0
        for emoji in emojis:
            tk.Button(container, text=emoji, font=("Segoe UI", 14), bg="white", bd=0, 
                      command=lambda e=emoji: self.on_select(e)).grid(row=r, column=c, padx=5, pady=5)
            c += 1
            if c > 3: c = 0; r += 1
            
    def on_select(self, emoji):
        self.callback(emoji)
        self.destroy()

# --- 8. SEARCH BAR (CONTACTS) ---
class SearchBar(tk.Frame):
    def __init__(self, parent, callback):
        page_bg = parent.cget("bg") if hasattr(parent, "cget") else "white"
        super().__init__(parent, bg=page_bg, padx=14, pady=10)
        self._radius = 16
        self._fill = BG_COLOR
        self.canvas = tk.Canvas(self, bg=page_bg, height=38, width=10, highlightthickness=0, bd=0)
        self.canvas.pack(fill="x", expand=True)

        inner = tk.Frame(self.canvas, bg=self._fill)
        tk.Label(inner, text="🔍", bg=self._fill, fg=MUTED_TEXT, font=("Segoe UI", 10)).pack(side="left", padx=(12, 4))
        self.entry = tk.Entry(inner, font=("Segoe UI", 10), bg=self._fill, bd=0, fg=TEXT_COLOR)
        self.entry.insert(0, "search contacts...")
        self.entry.pack(fill="x", side="left", expand=True, padx=(0, 12), pady=8)
        self.entry.bind("<KeyRelease>", lambda e: callback(self.entry.get()))

        self._win = self.canvas.create_window(0, 19, anchor="w", window=inner)
        self.canvas.bind("<Configure>", self._redraw)

    def _redraw(self, event=None):
        w = self.canvas.winfo_width()
        if w < 4:
            return
        self.canvas.delete("bg")
        draw_round_rect(self.canvas, 1, 1, w - 1, 37, self._radius, fill=self._fill, outline="", tags="bg")
        self.canvas.tag_lower("bg")
        self.canvas.coords(self._win, 2, 19)
        self.canvas.itemconfig(self._win, width=w - 4)

# --- 9. USER LIST ITEM (With Notification Badge) ---
class UserListItem(tk.Frame):
    def __init__(self, parent, name, is_online=0, last_seen="", profile_pic="",
                 unread_count=0, command=None):
        super().__init__(parent, bg="white", cursor="hand2", width=260, height=72)
        self.pack_propagate(False)
        self.command = command
        self.name = name
        self._hover_bg = "#F7F7FD"
        self._base_bg = "white"

        self.dp_canvas = tk.Canvas(self, width=54, height=54, bg="white", highlightthickness=0)
        self.dp_canvas.pack(side="left", padx=(14, 10), pady=9)
        self.set_profile_pic(profile_pic)

        info_container = tk.Frame(self, bg="white")
        info_container.pack(side="left", fill="both", expand=True, padx=2, pady=10)

        name_font = ("Segoe UI", 11, "bold") if unread_count > 0 else ("Segoe UI", 11)
        self.name_lbl = tk.Label(info_container, text=name, font=name_font,
                                  bg="white", fg=TEXT_COLOR, anchor="w")
        self.name_lbl.pack(fill="x")

        status_text = "Online" if is_online else f"Last seen: {last_seen}" if last_seen else "Offline"
        self.status_lbl = tk.Label(info_container, text=status_text, font=("Segoe UI", 9),
                                    bg="white", fg=STATUS_GREEN if is_online else MUTED_TEXT, anchor="w")
        self.status_lbl.pack(fill="x", pady=(2, 0))

        right_frame = tk.Frame(self, bg="white")
        right_frame.pack(side="right", padx=14, pady=5)

        if unread_count > 0:
            badge_text = str(unread_count) if unread_count < 100 else "99+"
            badge_size = 22 if unread_count < 10 else 26
            self.badge_canvas = tk.Canvas(right_frame, width=badge_size, height=22,
                                          bg="white", highlightthickness=0)
            self.badge_canvas.pack(anchor="e", pady=(0, 2))
            self.badge_canvas.create_oval(1, 1, badge_size - 1, 21,
                                          fill=STATUS_GREEN, outline=STATUS_GREEN)
            self.badge_canvas.create_text(badge_size // 2, 11, text=badge_text,
                                          fill="white", font=("Segoe UI", 8, "bold"))

        status_color = SUCCESS_COLOR if is_online else "#D5D7E8"
        self.status_dot = tk.Canvas(right_frame, width=15, height=15, bg="white", highlightthickness=0)
        self.dot_id = self.status_dot.create_oval(2, 2, 12, 12,
                                                   fill=status_color, outline=status_color)
        self.status_dot.pack(anchor="e")

        tk.Frame(self, bg="#EEEFF7", height=1).pack(side="bottom", fill="x")

        self._bg_widgets = [self, info_container, self.name_lbl, self.status_lbl,
                             self.dp_canvas, right_frame, self.status_dot]
        clickable = list(self._bg_widgets)
        if unread_count > 0:
            clickable.append(self.badge_canvas)
        for widget in clickable:
            widget.bind("<Button-1>", lambda e: self.command() if self.command else None)
        for widget in self._bg_widgets:
            widget.bind("<Enter>", self._on_enter)
            widget.bind("<Leave>", self._on_leave)

    def _on_enter(self, e):
        for w in self._bg_widgets:
            try:
                w.config(bg=self._hover_bg)
            except tk.TclError:
                pass
        self.dp_canvas.config(bg=self._hover_bg)
        self.status_dot.config(bg=self._hover_bg)
        if hasattr(self, 'badge_canvas'):
            self.badge_canvas.config(bg=self._hover_bg)

    def _on_leave(self, e):
        for w in self._bg_widgets:
            try:
                w.config(bg=self._base_bg)
            except tk.TclError:
                pass
        self.dp_canvas.config(bg=self._base_bg)
        self.status_dot.config(bg=self._base_bg)
        if hasattr(self, 'badge_canvas'):
            self.badge_canvas.config(bg=self._base_bg)

    def set_profile_pic(self, path):
        size = (44, 44)
        try:
            if path and os.path.exists(path):
                img = Image.open(path)
                img = ImageOps.fit(img, size, centering=(0.5, 0.5))
                mask = Image.new('L', size, 0)
                draw = ImageDraw.Draw(mask)
                draw.ellipse((0, 0) + size, fill=255)
                img.putalpha(mask)
                self.photo = ImageTk.PhotoImage(img)
                self.dp_canvas.create_oval(3, 3, 51, 51, outline=BORDER_COLOR, width=1)
                self.dp_canvas.create_image(27, 27, image=self.photo)
            else:
                raise Exception
        except:
            self.dp_canvas.delete("all")
            ring_color = _blend(PRIMARY_COLOR, "#FFFFFF", 0.75)
            self.dp_canvas.create_oval(1, 1, 53, 53, fill=ring_color, outline=ring_color)
            self.dp_canvas.create_oval(5, 5, 49, 49, fill=PRIMARY_COLOR, outline=PRIMARY_COLOR)
            self.dp_canvas.create_text(27, 27, text=self.name[0].upper(),
                                       fill="white", font=("Segoe UI", 13, "bold"))

    def update_status(self, is_online, last_seen, unread_count=0):
        st_text = "Online" if is_online else f"Last seen: {last_seen}" if last_seen else "Offline"
        self.status_lbl.config(text=st_text, fg=STATUS_GREEN if is_online else MUTED_TEXT)
        color = SUCCESS_COLOR if is_online else "#D5D7E8"
        self.status_dot.itemconfig(self.dot_id, fill=color, outline=color)

        if hasattr(self, 'badge_canvas'):
            self.badge_canvas.destroy()
            del self.badge_canvas

        if unread_count > 0:
            badge_text = str(unread_count) if unread_count < 100 else "99+"
            badge_size = 22 if unread_count < 10 else 26
            right_frame = self.status_dot.master
            self.badge_canvas = tk.Canvas(right_frame, width=badge_size, height=22,
                                          bg=self._base_bg, highlightthickness=0)
            self.badge_canvas.pack(anchor="e", pady=(0, 2), before=self.status_dot)
            self.badge_canvas.create_oval(1, 1, badge_size - 1, 21,
                                          fill=STATUS_GREEN, outline=STATUS_GREEN)
            self.badge_canvas.create_text(badge_size // 2, 11, text=badge_text,
                                          fill="white", font=("Segoe UI", 8, "bold"))
            self.badge_canvas.bind("<Button-1>",
                                   lambda e: self.command() if self.command else None)
            self.badge_canvas.bind("<Enter>", self._on_enter)
            self.badge_canvas.bind("<Leave>", self._on_leave)

        name_font = ("Segoe UI", 11, "bold") if unread_count > 0 else ("Segoe UI", 11)
        self.name_lbl.config(font=name_font)

# --- 10. GROUP LIST ITEM ---
class GroupListItem(tk.Frame):
    def __init__(self, parent, group_name, member_count=0, command=None):
        super().__init__(parent, bg="white", cursor="hand2", width=260, height=72)
        self.pack_propagate(False)
        self.command = command
        self.name = group_name
        self._hover_bg = "#F7F7FD"
        self._base_bg = "white"

        self.dp_canvas = tk.Canvas(self, width=54, height=54, bg="white", highlightthickness=0)
        self.dp_canvas.pack(side="left", padx=(14, 10), pady=9)
        ring_color = _blend(GROUP_ACCENT, "#FFFFFF", 0.78)
        self.dp_canvas.create_oval(1, 1, 53, 53, fill=ring_color, outline=ring_color)
        self.dp_canvas.create_oval(5, 5, 49, 49, fill=GROUP_ACCENT, outline=GROUP_ACCENT)
        self.dp_canvas.create_text(27, 27, text="👥", font=("Segoe UI", 15))

        info_container = tk.Frame(self, bg="white")
        info_container.pack(side="left", fill="both", expand=True, padx=2, pady=10)

        self.name_lbl = tk.Label(info_container, text=group_name, font=("Segoe UI", 11, "bold"),
                                  bg="white", fg=TEXT_COLOR, anchor="w")
        self.name_lbl.pack(fill="x")
        self.member_lbl = tk.Label(info_container, text=f"{member_count} members", font=("Segoe UI", 9),
                                    bg="white", fg=MUTED_TEXT, anchor="w")
        self.member_lbl.pack(fill="x", pady=(2, 0))

        tk.Frame(self, bg="#EEEFF7", height=1).pack(side="bottom", fill="x")

        self._bg_widgets = [self, self.dp_canvas, info_container, self.name_lbl, self.member_lbl]
        for widget in self._bg_widgets:
            widget.bind("<Button-1>", lambda e: self.command() if self.command else None)
            widget.bind("<Enter>", self._on_enter)
            widget.bind("<Leave>", self._on_leave)

    def _on_enter(self, e):
        for w in self._bg_widgets:
            try:
                w.config(bg=self._hover_bg)
            except tk.TclError:
                pass

    def _on_leave(self, e):
        for w in self._bg_widgets:
            try:
                w.config(bg=self._base_bg)
            except tk.TclError:
                pass

# --- 11. DATE HEADER ---
class DateHeader(tk.Frame):
    def __init__(self, parent, date_text, chat_bg=None):
        bg = chat_bg if chat_bg else DEFAULT_CHAT_BG
        super().__init__(parent, bg=bg)
        self.pack(fill="x", pady=12)
        pill = tk.Canvas(self, height=26, bg=bg, highlightthickness=0)
        pill.pack()
        tmp = tk.Label(pill, text=date_text, font=("Segoe UI", 9, "bold"))
        tmp.update_idletasks()
        tw = tmp.winfo_reqwidth(); tmp.destroy()
        pw = tw + 28
        pill.config(width=pw)
        draw_round_rect(pill, 1, 1, pw - 1, 25, 13, fill=PRIMARY_LIGHT, outline="")
        pill.create_text(pw / 2, 13, text=date_text, font=("Segoe UI", 9, "bold"), fill=PRIMARY_DARK)

# --- 12. BLOCKED HISTORY POPUP ---

class StarredMessagesPopup(tk.Toplevel):
    def __init__(self, parent, messages, primary_color):
        super().__init__(parent)
        self.title("Starred Messages")
        self.geometry("450x550")
        self.configure(bg="white")
        
        header = tk.Frame(self, bg=primary_color, pady=15)
        header.pack(fill="x")
        tk.Label(header, text="⭐ Starred Messages", fg="white", bg=primary_color, font=("Segoe UI", 14, "bold")).pack()
        
        container = tk.Frame(self, bg="white")
        container.pack(fill="both", expand=True, padx=10, pady=10)
        
        canvas = tk.Canvas(container, bg="white", highlightthickness=0)
        scrollbar = tk.Scrollbar(container, orient="vertical", command=canvas.yview)
        self.scrollable_frame = tk.Frame(canvas, bg="white")

        self.scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw", width=410)
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        if not messages:
            tk.Label(self.scrollable_frame, text="No starred messages found.", bg="white", font=("Segoe UI", 10, "italic"), fg="#6B7280").pack(pady=20)
        else:
            for msg_id, text, timestamp, sender, msg_type, file_path in messages:
                card = tk.Frame(self.scrollable_frame, bg="#f8f9fa", highlightbackground="#ddd", highlightthickness=1, padx=10, pady=8)
                card.pack(fill="x", pady=5)
                tk.Label(card, text=f"From: {sender}", font=("Segoe UI", 9, "bold"), bg="#f8f9fa", fg=PRIMARY_COLOR).pack(anchor="w")
                
                if msg_type == 'image' and file_path and os.path.exists(file_path):
                     tk.Label(card, text="[Image Message]", font=("Segoe UI", 10, "italic"), bg="#f8f9fa").pack(anchor="w")
                else:
                    tk.Label(card, text=text, bg="#f8f9fa", font=("Segoe UI", 11), wraplength=380, justify="left").pack(anchor="w", pady=5)
                
                tk.Label(card, text=timestamp, bg="#f8f9fa", fg="#6B7280", font=("Segoe UI", 8)).pack(anchor="e")

        tk.Button(self, text="Close", command=self.destroy, bg="#F3F4FA", bd=0, pady=10, font=("Segoe UI", 10, "bold")).pack(fill="x")

# --- 14. CREATE GROUP POPUP ---
class CreateGroupPopup(tk.Toplevel):
    def __init__(self, parent, all_users, current_user_id, on_create_callback):
        super().__init__(parent)
        self.title("Create New Group")
        self.geometry("400x500")
        self.configure(bg="white")
        self.on_create_callback = on_create_callback
        self.selected_users = []

        header = tk.Frame(self, bg="#8B5CF6", pady=15)
        header.pack(fill="x")
        tk.Label(header, text="👥 Create Group", fg="white", bg="#8B5CF6", font=("Segoe UI", 14, "bold")).pack()

        name_frame = tk.Frame(self, bg="white", padx=20, pady=10)
        name_frame.pack(fill="x")
        tk.Label(name_frame, text="Group Name:", font=("Segoe UI", 10, "bold"), bg="white").pack(anchor="w")
        self.group_name_entry = tk.Entry(name_frame, font=("Segoe UI", 12), bg="#F3F4FA", bd=0, highlightthickness=1, highlightbackground="#ddd")
        self.group_name_entry.pack(fill="x", ipady=8, pady=5)

        tk.Label(self, text="Select Members:", font=("Segoe UI", 10, "bold"), bg="white", padx=20).pack(anchor="w", pady=(5, 0))

        list_frame = tk.Frame(self, bg="white")
        list_frame.pack(fill="both", expand=True, padx=20, pady=5)

        canvas = tk.Canvas(list_frame, bg="white", highlightthickness=0)
        scrollbar = tk.Scrollbar(list_frame, orient="vertical", command=canvas.yview)
        self.members_frame = tk.Frame(canvas, bg="white")
        self.members_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.members_frame, anchor="nw", width=340)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.check_vars = {}
        for uid, uname, *_ in all_users:
            if uid != current_user_id:
                var = tk.BooleanVar()
                self.check_vars[uid] = (var, uname)
                cb = tk.Checkbutton(self.members_frame, text=uname, variable=var,
                                    font=("Segoe UI", 11), bg="white", anchor="w",
                                    activebackground="white", cursor="hand2")
                cb.pack(fill="x", pady=3)

        tk.Button(self, text="✅ Create Group", font=("Segoe UI", 12, "bold"), bg="#8B5CF6", fg="white",
                  bd=0, pady=10, cursor="hand2", command=self.on_submit).pack(fill="x", padx=20, pady=10)

    def on_submit(self):
        group_name = self.group_name_entry.get().strip()
        if not group_name:
            messagebox.showwarning("Warning", "Group name enter cheyyandi!", parent=self)
            return

        selected = [uid for uid, (var, _) in self.check_vars.items() if var.get()]
        if not selected:
            messagebox.showwarning("Warning", "Kallaalo oka member select cheyyandi!", parent=self)
            return

        self.on_create_callback(group_name, selected)
        self.destroy()

# --- 15. GROUP MEMBERS POPUP ---
class GroupMembersPopup(tk.Toplevel):
    def __init__(self, parent, group_id, group_name, members, is_admin, all_users, current_user_id,
                 add_member_callback, remove_member_callback):
        super().__init__(parent)
        self.title(f"Group Info: {group_name}")
        self.geometry("380x500")
        self.configure(bg="white")

        header = tk.Frame(self, bg="#8B5CF6", pady=15)
        header.pack(fill="x")
        tk.Label(header, text=f"👥 {group_name}", fg="white", bg="#8B5CF6", font=("Segoe UI", 13, "bold")).pack()
        tk.Label(header, text=f"{len(members)} members", fg="#ddd", bg="#8B5CF6", font=("Segoe UI", 9)).pack()

        tk.Label(self, text="Members:", font=("Segoe UI", 10, "bold"), bg="white", padx=15).pack(anchor="w", pady=(10, 0))

        list_frame = tk.Frame(self, bg="white")
        list_frame.pack(fill="both", expand=True, padx=15, pady=5)

        for uid, uname, _, is_online, mem_is_admin in members:
            row = tk.Frame(list_frame, bg="#f8f9fa", padx=10, pady=6)
            row.pack(fill="x", pady=2)

            av = tk.Canvas(row, width=35, height=35, bg="#f8f9fa", highlightthickness=0)
            av.pack(side="left", padx=(0, 8))
            av.create_oval(2, 2, 33, 33, fill=PRIMARY_COLOR, outline=PRIMARY_COLOR)
            av.create_text(18, 18, text=uname[0].upper(), fill="white", font=("Segoe UI", 11, "bold"))

            info = tk.Frame(row, bg="#f8f9fa")
            info.pack(side="left", fill="both", expand=True)
            label = uname + (" 👑 Admin" if mem_is_admin else "")
            tk.Label(info, text=label, font=("Segoe UI", 10, "bold"), bg="#f8f9fa").pack(anchor="w")
            st = "Online" if is_online else "Offline"
            tk.Label(info, text=st, font=("Segoe UI", 8), fg=SUCCESS_COLOR if is_online else "#6B7280", bg="#f8f9fa").pack(anchor="w")

            if is_admin and uid != current_user_id and not mem_is_admin:
                tk.Button(row, text="Remove", font=("Segoe UI", 8), bg="#EF4444", fg="white", bd=0,
                          cursor="hand2", padx=5,
                          command=lambda u=uid, n=uname: remove_member_callback(group_id, u, n, self)).pack(side="right")

        if is_admin:
            existing_ids = {m[0] for m in members}
            addable = [(uid, uname) for uid, uname, *_ in all_users if uid not in existing_ids and uid != current_user_id]
            if addable:
                tk.Label(self, text="Add Member:", font=("Segoe UI", 10, "bold"), bg="white", padx=15).pack(anchor="w", pady=(5, 0))
                add_frame = tk.Frame(self, bg="white", padx=15)
                add_frame.pack(fill="x")
                self.add_var = tk.StringVar()
                names = [uname for _, uname in addable]
                ids = [uid for uid, _ in addable]
                combo = ttk.Combobox(add_frame, textvariable=self.add_var, values=names, state="readonly", font=("Segoe UI", 10))
                combo.pack(side="left", fill="x", expand=True, pady=5)
                tk.Button(add_frame, text="Add", bg="#8B5CF6", fg="white", bd=0, padx=10, cursor="hand2",
                          command=lambda: add_member_callback(group_id, ids[names.index(self.add_var.get())], self) if self.add_var.get() else None).pack(side="right", padx=5)

        tk.Button(self, text="Close", command=self.destroy, bg="#F3F4FA", bd=0, pady=8, font=("Segoe UI", 10)).pack(fill="x", padx=15, pady=10)


# ==================== STATUS UI COMPONENTS ====================

# --- 16. STATUS AVATAR ---
class StatusAvatar(tk.Canvas):
    def __init__(self, parent, name, profile_pic="", has_status=False, all_viewed=False,
                 size=56, command=None, **kwargs):
        super().__init__(parent, width=size+8, height=size+8, bg="white",
                         highlightthickness=0, cursor="hand2" if command else "arrow", **kwargs)
        self.command = command
        self.size = size
        self.name = name

        cx = cy = (size + 8) // 2

        if has_status:
            ring_color = STATUS_GREY if all_viewed else STATUS_GREEN
            self.create_oval(2, 2, size+6, size+6, outline=ring_color, width=3)

        self._draw_pic(profile_pic, cx, cy, size)

        if command:
            self.bind("<Button-1>", lambda e: command())

    def _draw_pic(self, path, cx, cy, size):
        r = size // 2
        try:
            if path and os.path.exists(path):
                img = Image.open(path)
                img = ImageOps.fit(img, (size, size), centering=(0.5, 0.5))
                mask = Image.new('L', (size, size), 0)
                draw = ImageDraw.Draw(mask)
                draw.ellipse((0, 0, size, size), fill=255)
                img.putalpha(mask)
                self._photo = ImageTk.PhotoImage(img)
                self.create_image(cx, cy, image=self._photo)
            else:
                raise Exception("No pic")
        except:
            self.create_oval(cx-r, cy-r, cx+r, cy+r, fill=PRIMARY_COLOR, outline=PRIMARY_COLOR)
            self.create_text(cx, cy, text=self.name[0].upper(), fill="white",
                             font=("Segoe UI", size//4, "bold"))


# --- 17. STATUS LIST ITEM ---
class StatusListItem(tk.Frame):
    def __init__(self, parent, username, latest_time, profile_pic="",
                 has_unviewed=True, status_count=1, command=None):
        super().__init__(parent, bg="white", cursor="hand2", height=72)
        self.pack_propagate(False)
        self.command = command

        avatar = StatusAvatar(self, username, profile_pic=profile_pic,
                              has_status=True, all_viewed=not has_unviewed, size=48,
                              command=command)
        avatar.pack(side="left", padx=10, pady=10)
        avatar.config(bg="white")

        info = tk.Frame(self, bg="white")
        info.pack(side="left", fill="both", expand=True, pady=12)

        tk.Label(info, text=username, font=("Segoe UI", 11, "bold"), bg="white", anchor="w").pack(fill="x")

        try:
            dt = datetime.strptime(latest_time, "%Y-%m-%d %H:%M:%S")
            time_str = dt.strftime("%I:%M %p")
        except:
            time_str = latest_time or ""

        status_txt = f"{status_count} status{'es' if status_count > 1 else ''} • {time_str}"
        tk.Label(info, text=status_txt, font=("Segoe UI", 8), bg="white",
                 fg=STATUS_GREEN if has_unviewed else "#6B7280", anchor="w").pack(fill="x")

        tk.Frame(self, bg="#E9EAF5", height=1).pack(side="bottom", fill="x")

        for w in (self, info):
            w.bind("<Button-1>", lambda e: command() if command else None)


# --- 18. MY STATUS ITEM ---
class MyStatusItem(tk.Frame):
    def __init__(self, parent, username, profile_pic="", status_count=0,
                 add_command=None, view_command=None):
        super().__init__(parent, bg="white", height=72)
        self.pack_propagate(False)

        has_status = status_count > 0

        avatar = StatusAvatar(self, username, profile_pic=profile_pic,
                              has_status=has_status, all_viewed=True,
                              size=48, command=view_command if has_status else add_command)
        avatar.config(bg="white")
        avatar.pack(side="left", padx=10, pady=10)

        add_btn = tk.Canvas(avatar, width=18, height=18, bg="white", highlightthickness=0, cursor="hand2")
        add_btn.place(relx=1.0, rely=1.0, anchor="se", x=-2, y=-2)
        add_btn.create_oval(1, 1, 17, 17, fill=STATUS_GREEN, outline="white")
        add_btn.create_text(9, 9, text="+", fill="white", font=("Segoe UI", 10, "bold"))
        add_btn.bind("<Button-1>", lambda e: add_command() if add_command else None)

        info = tk.Frame(self, bg="white")
        info.pack(side="left", fill="both", expand=True, pady=12)

        tk.Label(info, text="My Status", font=("Segoe UI", 11, "bold"), bg="white", anchor="w").pack(fill="x")

        sub = f"{status_count} active status" if has_status else "Tap to add status"
        tk.Label(info, text=sub, font=("Segoe UI", 8), bg="white", fg="#6B7280", anchor="w").pack(fill="x")

        tk.Frame(self, bg="#E9EAF5", height=1).pack(side="bottom", fill="x")


# --- 19. STATUS VIEWER POPUP ---
class StatusViewerPopup(tk.Toplevel):
    def __init__(self, parent, statuses, current_index, current_user_id, db,
                 on_view_callback=None, is_own=False):
        super().__init__(parent)
        self.title("Status")
        # Smaller window — black area తగ్గుతుంది
        self.geometry("400x580")
        self.resizable(False, False)
        self.configure(bg="black")

        self.statuses = statuses
        self.current_index = current_index
        self.current_user_id = current_user_id
        self.db = db
        self.on_view_callback = on_view_callback
        self.is_own = is_own
        self.progress_after = None

        # ── TOP BAR ──────────────────────────────────────────────
        self.top_bar = tk.Frame(self, bg="black", pady=6)
        self.top_bar.pack(fill="x", side="top")

        self.progress_frame = tk.Frame(self.top_bar, bg="black")
        self.progress_frame.pack(fill="x", padx=10, pady=(4, 0))

        info_row = tk.Frame(self.top_bar, bg="black")
        info_row.pack(fill="x", padx=10, pady=4)

        self.user_lbl = tk.Label(info_row, text="", font=("Segoe UI", 10, "bold"),
                                 bg="black", fg="white")
        self.user_lbl.pack(side="left")

        self.time_lbl = tk.Label(info_row, text="", font=("Segoe UI", 8),
                                 bg="black", fg="#aaa")
        self.time_lbl.pack(side="left", padx=8)

        tk.Button(info_row, text="✕", font=("Segoe UI", 11, "bold"), bg="black", fg="white",
                  bd=0, cursor="hand2", command=self.destroy).pack(side="right")

        # ── BOTTOM BAR — side="bottom" తో pack చేయడం వల్ల always visible ──
        tk.Frame(self, bg="#333", height=1).pack(fill="x", side="bottom")

        self.bottom_bar = tk.Frame(self, bg="#1a1a1a", pady=8)
        self.bottom_bar.pack(fill="x", side="bottom")

        self.views_lbl = tk.Label(self.bottom_bar, text="", font=("Segoe UI", 9),
                                  bg="#1a1a1a", fg="white")
        self.views_lbl.pack(side="left", padx=12)

        if self.is_own:
            # Delete button
            tk.Button(self.bottom_bar, text="🗑️ Delete", font=("Segoe UI", 9),
                      bg="#1a1a1a", fg="#EF4444", bd=0, cursor="hand2",
                      command=self.delete_current).pack(side="right", padx=10)
            # View Details button — green, prominent
            tk.Button(self.bottom_bar, text="👁️ View Details", font=("Segoe UI", 9, "bold"),
                      bg="#25D366", fg="white", bd=0, cursor="hand2",
                      padx=8, pady=3,
                      command=self.show_viewers).pack(side="right", padx=6)

        # ── CONTENT AREA — top/bottom bar ke madhya ──────────────
        self.content_frame = tk.Frame(self, bg="black")
        self.content_frame.pack(fill="both", expand=True)

        # Left nav arrow
        self.left_nav = tk.Frame(self.content_frame, bg="black", width=45, cursor="hand2")
        self.left_nav.pack(side="left", fill="y")
        self.left_nav.pack_propagate(False)
        self.left_nav.bind("<Button-1>", lambda e: self.prev_status())
        tk.Label(self.left_nav, text="❮", font=("Segoe UI", 16), bg="black", fg="#666",
                 cursor="hand2").pack(expand=True)

        # Right nav arrow
        self.right_nav = tk.Frame(self.content_frame, bg="black", width=45, cursor="hand2")
        self.right_nav.pack(side="right", fill="y")
        self.right_nav.pack_propagate(False)
        self.right_nav.bind("<Button-1>", lambda e: self.next_status())
        tk.Label(self.right_nav, text="❯", font=("Segoe UI", 16), bg="black", fg="#666",
                 cursor="hand2").pack(expand=True)

        # Status display area — image/text ikkade render avutundi
        self.status_display = tk.Frame(self.content_frame, bg="black")
        self.status_display.pack(fill="both", expand=True)

        # Window fully render ayyaka load_status call cheyyadam
        # (winfo_width/height correct values return cheyyataniki)
        self.after(50, self.load_status)

    def load_status(self):
        if self.progress_after:
            self.after_cancel(self.progress_after)

        for w in self.status_display.winfo_children():
            w.destroy()
        for w in self.progress_frame.winfo_children():
            w.destroy()

        if not self.statuses or self.current_index >= len(self.statuses):
            self.destroy()
            return

        # Progress bars
        for i in range(len(self.statuses)):
            bar_bg = tk.Frame(self.progress_frame, bg="#555", height=3)
            bar_bg.pack(side="left", fill="x", expand=True, padx=2, pady=3)
            if i < self.current_index:
                tk.Frame(bar_bg, bg="white", height=3).place(relwidth=1.0, relheight=1.0)
            elif i == self.current_index:
                self.active_bar_bg = bar_bg
                self.active_bar = tk.Frame(bar_bg, bg="white", height=3)
                self.active_bar.place(relwidth=0.0, relheight=1.0)

        st = self.statuses[self.current_index]

        if self.is_own:
            status_id, user_id, stype, content, fpath, bg_color, font_size, created_at, expires_at, view_count = st
            username = "Me"
        else:
            status_id, user_id, username, profile_pic, stype, content, fpath, bg_color, font_size, created_at, is_viewed = st

        self.user_lbl.config(text=username)
        try:
            dt = datetime.strptime(created_at, "%Y-%m-%d %H:%M:%S")
            self.time_lbl.config(text=dt.strftime("%I:%M %p"))
        except:
            self.time_lbl.config(text="")

        if stype == 'image' and fpath and os.path.exists(fpath):
            try:
                img = Image.open(fpath)
                self.update_idletasks()
                avail_w = self.status_display.winfo_width() or 310
                avail_h = self.status_display.winfo_height() or 440

                img_w, img_h = img.size
                ratio = min(avail_w / img_w, avail_h / img_h, 1.0)
                new_w = max(1, int(img_w * ratio))
                new_h = max(1, int(img_h * ratio))
                img = img.resize((new_w, new_h), Image.LANCZOS)

                self._img_tk = ImageTk.PhotoImage(img)
                lbl = tk.Label(self.status_display, image=self._img_tk,
                               bg="black", anchor="center")
                lbl.pack(expand=True)
            except Exception as e:
                print(f"Image load error: {e}")
                tk.Label(self.status_display, text="⚠️ Image load error",
                         bg="black", fg="red", font=("Segoe UI", 12)).pack(expand=True)
        else:
            # bg_color / font_size None or empty string aithe safe defaults use cheyyadam
            raw_bg = bg_color if bg_color and str(bg_color).strip() else "#128C7E"
            # Validate color — invalid string aithe default ki fallback
            try:
                self.winfo_rgb(raw_bg)   # self (Toplevel) use cheyyadam — always rendered
                safe_bg = raw_bg
            except Exception:
                safe_bg = "#128C7E"

            try:
                safe_fs = int(font_size) if font_size else 20
                if safe_fs < 8 or safe_fs > 72:
                    safe_fs = 20
            except (TypeError, ValueError):
                safe_fs = 20

            safe_text = str(content) if content else ""

            text_frame = tk.Frame(self.status_display, bg=safe_bg)
            text_frame.pack(fill="both", expand=True)
            tk.Label(text_frame, text=safe_text,
                     font=("Segoe UI", safe_fs, "bold"),
                     bg=safe_bg, fg="white",
                     wraplength=300, justify="center").pack(expand=True)

        # Views count update
        if self.is_own:
            total_views = self.db.get_status_total_views(status_id)
            unique_viewers = len(self.db.get_status_viewers(status_id))
            self.views_lbl.config(
                text=f"👁️ {total_views} views  •  {unique_viewers} viewers"
            )
        else:
            if self.db:
                self.db.mark_status_viewed(status_id, self.current_user_id)
                if self.on_view_callback:
                    self.on_view_callback()
            self.views_lbl.config(text="")

        self._animate_progress(0, status_id)

    def _animate_progress(self, step, status_id):
        total_steps = 50
        if step <= total_steps:
            if hasattr(self, 'active_bar'):
                self.active_bar.place(relwidth=step/total_steps, relheight=1.0)
            self.progress_after = self.after(100, lambda: self._animate_progress(step+1, status_id))
        else:
            self.next_status()

    def next_status(self):
        if self.progress_after:
            self.after_cancel(self.progress_after)
        if self.current_index < len(self.statuses) - 1:
            self.current_index += 1
            self.load_status()
        else:
            self.destroy()

    def prev_status(self):
        if self.progress_after:
            self.after_cancel(self.progress_after)
        if self.current_index > 0:
            self.current_index -= 1
            self.load_status()

    def delete_current(self):
        if not self.statuses:
            return
        st = self.statuses[self.current_index]
        status_id = st[0]
        if messagebox.askyesno("Delete", "Ee status delete cheyalaa?", parent=self):
            if self.db.delete_status(status_id, self.current_user_id):
                self.statuses.pop(self.current_index)
                if not self.statuses:
                    self.destroy()
                    if self.on_view_callback:
                        self.on_view_callback()
                    return
                self.current_index = min(self.current_index, len(self.statuses)-1)
                self.load_status()
                if self.on_view_callback:
                    self.on_view_callback()

    def show_viewers(self):
        """View Details button — detailed repeat view tracking popup open chestundi."""
        if not self.statuses:
            return
        st = self.statuses[self.current_index]
        status_id = st[0]
        # get_status_view_details — repeat views grouped by user
        view_details = self.db.get_status_view_details(status_id)
        StatusViewDetailsPopup(self, view_details)

    def destroy(self):
        if self.progress_after:
            try:
                self.after_cancel(self.progress_after)
            except:
                pass
        super().destroy()


# --- 20. STATUS VIEW DETAILS POPUP ---
class StatusViewDetailsPopup(tk.Toplevel):
    """
    Status owner ki detailed view info chupistundi.
    Repeat views kuda track avutayi.
    Format: User A - 3 views (10:00 AM, 12:30 PM, 6:45 PM)
            User B - 1 view (2:15 PM)
    """
    def __init__(self, parent, view_details):
        """
        view_details: list of (username, view_count, [timestamps])
        """
        super().__init__(parent)
        self.title("View Details")
        self.geometry("380x500")
        self.configure(bg="white")

        total_views = sum(d[1] for d in view_details)
        unique_viewers = len(view_details)

        # Header
        header = tk.Frame(self, bg="#128C7E", pady=12)
        header.pack(fill="x")
        tk.Label(header, text="👁️ View Details",
                 fg="white", bg="#128C7E", font=("Segoe UI", 13, "bold")).pack()
        tk.Label(header,
                 text=f"{total_views} total views  •  {unique_viewers} unique viewers",
                 fg="#ddd", bg="#128C7E", font=("Segoe UI", 9)).pack()

        # Scrollable list
        container = tk.Frame(self, bg="white")
        container.pack(fill="both", expand=True, padx=10, pady=10)

        canvas = tk.Canvas(container, bg="white", highlightthickness=0)
        scrollbar = tk.Scrollbar(container, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg="white")
        scroll_frame.bind("<Configure>",
                          lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scroll_frame, anchor="nw", width=340)
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        if not view_details:
            tk.Label(scroll_frame, text="Inka evaru chudaledu.",
                     bg="white", fg="#6B7280", font=("Segoe UI", 10, "italic")).pack(pady=30)
        else:
            for username, count, timestamps in view_details:
                # User card
                card = tk.Frame(scroll_frame, bg="#f8f9fa",
                                highlightbackground="#EDEEF5", highlightthickness=1,
                                padx=10, pady=8)
                card.pack(fill="x", pady=4)

                top_row = tk.Frame(card, bg="#f8f9fa")
                top_row.pack(fill="x")

                # Avatar circle
                av = tk.Canvas(top_row, width=36, height=36,
                               bg="#f8f9fa", highlightthickness=0)
                av.pack(side="left", padx=(0, 10))
                av.create_oval(2, 2, 34, 34, fill=PRIMARY_COLOR, outline=PRIMARY_COLOR)
                av.create_text(18, 18, text=username[0].upper(),
                               fill="white", font=("Segoe UI", 11, "bold"))

                info = tk.Frame(top_row, bg="#f8f9fa")
                info.pack(side="left", fill="both", expand=True)

                tk.Label(info, text=username,
                         font=("Segoe UI", 10, "bold"), bg="#f8f9fa").pack(anchor="w")
                view_word = "view" if count == 1 else "views"
                tk.Label(info, text=f"{count} {view_word}",
                         font=("Segoe UI", 9), fg=PRIMARY_COLOR, bg="#f8f9fa").pack(anchor="w")

                # Timestamps — date + time format
                time_strs = []
                for ts in timestamps:
                    try:
                        dt = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
                        # Today aithe time only, otherwise date + time
                        if dt.date() == datetime.now().date():
                            time_strs.append(dt.strftime("%I:%M %p"))
                        else:
                            time_strs.append(dt.strftime("%d %b, %I:%M %p"))
                    except:
                        time_strs.append(ts)

                times_text = "  •  ".join(time_strs)
                tk.Label(card, text=f"🕐 {times_text}",
                         font=("Segoe UI", 8), fg="#6B7280", bg="#f8f9fa",
                         wraplength=300, justify="left").pack(anchor="w", pady=(4, 0))

        tk.Button(self, text="Close", command=self.destroy,
                  bg="#F3F4FA", bd=0, pady=8,
                  font=("Segoe UI", 10, "bold")).pack(fill="x")


# --- 21. ADD STATUS POPUP ---
class AddStatusPopup(tk.Toplevel):
    def __init__(self, parent, on_post_callback):
        super().__init__(parent)
        self.title("Add Status")
        self.geometry("420x560")
        self.configure(bg="white")
        self.on_post_callback = on_post_callback
        self.selected_color = "#128C7E"
        self.selected_image_path = None
        self.status_type = tk.StringVar(value="text")

        header = tk.Frame(self, bg="#128C7E", pady=12)
        header.pack(fill="x")
        tk.Label(header, text="📢 Add Status", fg="white", bg="#128C7E",
                 font=("Segoe UI", 14, "bold")).pack()

        type_frame = tk.Frame(self, bg="white", pady=10)
        type_frame.pack(fill="x", padx=20)
        tk.Label(type_frame, text="Status Type:", font=("Segoe UI", 10, "bold"), bg="white").pack(anchor="w")

        type_btns = tk.Frame(type_frame, bg="white")
        type_btns.pack(fill="x", pady=5)

        self.text_rb = tk.Radiobutton(type_btns, text="✏️ Text", variable=self.status_type,
                                      value="text", bg="white", font=("Segoe UI", 10),
                                      command=self.toggle_type)
        self.text_rb.pack(side="left", padx=10)

        self.img_rb = tk.Radiobutton(type_btns, text="🖼️ Image", variable=self.status_type,
                                     value="image", bg="white", font=("Segoe UI", 10),
                                     command=self.toggle_type)
        self.img_rb.pack(side="left", padx=10)

        self.preview_frame = tk.Frame(self, height=200, bg=self.selected_color)
        self.preview_frame.pack(fill="x", padx=20, pady=10)
        self.preview_frame.pack_propagate(False)

        self.preview_lbl = tk.Label(self.preview_frame, text="Status Preview",
                                    bg=self.selected_color, fg="white",
                                    font=("Segoe UI", 16, "bold"), wraplength=360)
        self.preview_lbl.pack(expand=True)

        self.text_section = tk.Frame(self, bg="white")
        self.text_section.pack(fill="x", padx=20, pady=5)

        tk.Label(self.text_section, text="Status Text:", font=("Segoe UI", 10, "bold"), bg="white").pack(anchor="w")
        self.text_entry = tk.Text(self.text_section, height=4, font=("Segoe UI", 12),
                                  bg="#F3F4FA", bd=0, padx=10, pady=8, wrap="word")
        self.text_entry.pack(fill="x")
        self.text_entry.bind("<KeyRelease>", self.update_preview)

        color_row = tk.Frame(self.text_section, bg="white")
        color_row.pack(fill="x", pady=8)
        tk.Label(color_row, text="Background:", font=("Segoe UI", 9), bg="white").pack(side="left")

        self.bg_colors = ["#128C7E", "#075E54", "#25D366", "#EF4444",
                          "#3498db", "#9b59b6", "#f39c12", "#2c3e50",
                          "#e91e63", "#ff5722"]
        for c in self.bg_colors:
            btn = tk.Canvas(color_row, width=24, height=24, bg="white",
                            highlightthickness=2, highlightbackground="#ddd", cursor="hand2")
            btn.pack(side="left", padx=3)
            btn.create_oval(2, 2, 22, 22, fill=c, outline=c)
            btn.bind("<Button-1>", lambda e, col=c: self.set_color(col))

        fs_row = tk.Frame(self.text_section, bg="white")
        fs_row.pack(fill="x", pady=5)
        tk.Label(fs_row, text="Font Size:", font=("Segoe UI", 9), bg="white").pack(side="left")
        self.font_size_var = tk.IntVar(value=20)
        tk.Scale(fs_row, from_=12, to=36, orient="horizontal",
                 variable=self.font_size_var, bg="white", showvalue=True,
                 command=lambda v: self.update_preview()).pack(side="left", fill="x", expand=True)

        self.img_section = tk.Frame(self, bg="white")

        tk.Label(self.img_section, text="Select Image:", font=("Segoe UI", 10, "bold"), bg="white").pack(anchor="w", padx=20)
        tk.Button(self.img_section, text="📂 Browse Image", font=("Segoe UI", 10),
                  bg="#F3F4FA", bd=1, pady=8, cursor="hand2",
                  command=self.browse_image).pack(fill="x", padx=20, pady=5)
        self.img_name_lbl = tk.Label(self.img_section, text="No image selected",
                                     font=("Segoe UI", 9), bg="white", fg="#6B7280")
        self.img_name_lbl.pack(anchor="w", padx=20)

        tk.Button(self, text="📤 Post Status", font=("Segoe UI", 12, "bold"),
                  bg="#128C7E", fg="white", bd=0, pady=12, cursor="hand2",
                  command=self.post_status).pack(fill="x", padx=20, pady=15)

    def toggle_type(self):
        st = self.status_type.get()
        if st == "text":
            self.img_section.pack_forget()
            self.text_section.pack(fill="x", padx=20, pady=5)
            self.preview_frame.config(bg=self.selected_color)
            self.preview_lbl.config(bg=self.selected_color, text="Status Preview")
        else:
            self.text_section.pack_forget()
            self.img_section.pack(fill="both", padx=0, pady=5)
            self.preview_frame.config(bg="black")
            self.preview_lbl.config(bg="black", text="🖼️ Image Preview")

    def set_color(self, color):
        self.selected_color = color
        self.preview_frame.config(bg=color)
        self.preview_lbl.config(bg=color)
        self.update_preview()

    def update_preview(self, event=None):
        text = self.text_entry.get("1.0", tk.END).strip()
        fs = self.font_size_var.get()
        self.preview_lbl.config(text=text if text else "Status Preview",
                                font=("Segoe UI", fs, "bold"))

    def browse_image(self):
        path = filedialog.askopenfilename(
            title="Select Image",
            filetypes=[("Image files", "*.jpg *.png *.jpeg *.gif *.bmp")]
        )
        if path:
            self.selected_image_path = path
            fname = os.path.basename(path)
            self.img_name_lbl.config(text=f"✅ {fname}", fg=SUCCESS_COLOR)
            try:
                img = Image.open(path)
                img.thumbnail((360, 180))
                self._prev_img = ImageTk.PhotoImage(img)
                self.preview_lbl.config(image=self._prev_img, text="", bg="black")
            except:
                pass

    def post_status(self):
        st = self.status_type.get()

        if st == "text":
            text = self.text_entry.get("1.0", tk.END).strip()
            if not text:
                messagebox.showwarning("Warning", "Status text enter cheyyandi!", parent=self)
                return
            self.on_post_callback(
                content=text,
                status_type='text',
                file_path=None,
                bg_color=self.selected_color,
                font_size=self.font_size_var.get()
            )
        else:
            if not self.selected_image_path:
                messagebox.showwarning("Warning", "Image select cheyyandi!", parent=self)
                return
            self.on_post_callback(
                content="",
                status_type='image',
                file_path=self.selected_image_path,
                bg_color="#000000",
                font_size=20
            )

        self.destroy()


# ==================== MOTIVATION MODE UI ====================
# --- 22. MOTIVATION MODE POPUP ---
import random as _random

# Motivation Mode colour palette
_MM_BG       = "#0F0F1A"
_MM_CARD     = "#1A1A2E"
_MM_CARD2    = "#16213E"
_MM_ACCENT   = "#E94560"
_MM_ACCENT2  = "#0F3460"
_MM_GOLD     = "#F5A623"
_MM_GREEN    = "#2ECC71"
_MM_PURPLE   = "#9B59B6"
_MM_TEAL     = "#1ABC9C"
_MM_TEXT     = "#F0EAD6"
_MM_TEXT2    = "#A0A0C0"
_MM_MUTED    = "#5A5A7A"

_EXIT_MSGS = [
    "You've got this! 💪",
    "Keep shining! ✨",
    "One day at a time! 🌟",
    "Believe in yourself! 🙏",
    "Stay strong, keep going! 🔥",
]

REPEAT_WINDOW = 15   # avoid repeating last N quotes


class MotivationModePopup(tk.Toplevel):
    """
    Full-featured Motivation Mode popup.
    Opens as a Toplevel window — existing chat app untouched.
    Features:
      - Situation picker (8 options)
      - Quote display (English + Telugu)
      - Next / Save / Voice / Change Mode / Exit buttons
      - Saved Quotes viewer
      - Repeat-avoid logic (last 15 quotes not repeated)
      - Auto-suggestion (most-used situation tracked via DB)
      - Exit confirmation with motivational message
    """

    def __init__(self, parent, current_user_id, db):
        super().__init__(parent)
        self.title("🌟 Motivation Mode")
        self.geometry("680x560")
        self.minsize(600, 480)
        self.configure(bg=_MM_BG)
        self.resizable(True, True)

        self.current_user_id = current_user_id
        self.db = db

        # Import data helpers from database module
        from database import SITUATIONS, get_quotes_for_situation, get_situation_by_id
        self._SITUATIONS            = SITUATIONS
        self._get_quotes            = get_quotes_for_situation
        self._get_situation_by_id   = get_situation_by_id

        # State
        self._current_situation = None
        self._pool: list        = []
        self._shown_ids: list   = []
        self._current_quote     = None

        # Build UI
        self._build_header()
        self._content = tk.Frame(self, bg=_MM_BG)
        self._content.pack(fill="both", expand=True)

        # Esc key → exit
        self.bind("<Escape>", lambda e: self._confirm_exit())

        # Show auto-suggestion if available, then situation picker
        self._show_situation_picker()

    # ── Header ────────────────────────────────────────────────────────────
    def _build_header(self):
        hdr = tk.Frame(self, bg=_MM_CARD, pady=10)
        hdr.pack(fill="x")
        tk.Label(hdr, text="🌟  Motivation Mode",
                 bg=_MM_CARD, fg=_MM_GOLD,
                 font=("Georgia", 16, "bold")).pack(side="left", padx=16)
        tk.Button(hdr, text="❌ Exit", font=("Segoe UI", 9, "bold"),
                  bg=_MM_ACCENT, fg="white", bd=0, padx=10, pady=4,
                  cursor="hand2", command=self._confirm_exit).pack(side="right", padx=12)
        tk.Button(hdr, text="❤️ Saved", font=("Segoe UI", 9),
                  bg=_MM_ACCENT2, fg=_MM_GOLD, bd=0, padx=10, pady=4,
                  cursor="hand2", command=self._open_saved).pack(side="right", padx=4)
        tk.Frame(self, bg=_MM_ACCENT, height=2).pack(fill="x")

    # ── Clear content area ────────────────────────────────────────────────
    def _clear_content(self):
        for w in self._content.winfo_children():
            w.destroy()

    # ── Auto-suggestion banner ────────────────────────────────────────────
    def _get_auto_suggestion(self):
        try:
            top = self.db.motivation_get_top_situation(self.current_user_id)
            if top:
                sit = self._get_situation_by_id(top)
                if sit:
                    return f"💡 Looks like you often need: {sit['label']}"
        except Exception:
            pass
        return None

    # ── 1. Situation Picker ───────────────────────────────────────────────
    def _show_situation_picker(self):
        self._clear_content()

        # Auto-suggestion banner
        suggestion = self._get_auto_suggestion()
        if suggestion:
            banner = tk.Frame(self._content, bg=_MM_PURPLE + "44", pady=6)
            banner.pack(fill="x", padx=12, pady=(8, 0))
            tk.Label(banner, text=suggestion,
                     bg=_MM_PURPLE + "44", fg=_MM_GOLD,
                     font=("Segoe UI", 9, "italic")).pack()

        # Title
        tk.Label(self._content, text="మీ current situation ఏమిటి?",
                 bg=_MM_BG, fg=_MM_TEXT2,
                 font=("Segoe UI", 11)).pack(pady=(12, 6))

        # Grid of situation cards
        grid = tk.Frame(self._content, bg=_MM_BG)
        grid.pack(fill="both", expand=True, padx=16, pady=4)

        for idx, sit in enumerate(self._SITUATIONS):
            row, col = divmod(idx, 2)
            self._make_situation_card(grid, sit, row, col)

        grid.columnconfigure(0, weight=1)
        grid.columnconfigure(1, weight=1)

    def _make_situation_card(self, parent, sit, row, col):
        card = tk.Frame(parent, bg=_MM_CARD, cursor="hand2",
                        highlightbackground=sit["color"],
                        highlightthickness=1)
        card.grid(row=row, column=col, padx=6, pady=5, sticky="ew")

        # Left colour strip
        tk.Frame(card, bg=sit["color"], width=5).pack(side="left", fill="y")

        lbl = tk.Label(card, text=sit["label"],
                       bg=_MM_CARD, fg=_MM_TEXT,
                       font=("Segoe UI", 11, "bold"),
                       anchor="w", padx=12, pady=12)
        lbl.pack(side="left", fill="x", expand=True)

        sid = sit["id"]
        for w in (card, lbl):
            w.bind("<Button-1>", lambda e, s=sid: self._situation_selected(s))
            w.bind("<Enter>",    lambda e, c=card: c.configure(bg=_MM_CARD2))
            w.bind("<Leave>",    lambda e, c=card: c.configure(bg=_MM_CARD))

    # ── 2. Situation selected ─────────────────────────────────────────────
    def _situation_selected(self, situation_id: str):
        self._current_situation = situation_id
        self._pool = self._get_quotes(situation_id)[:]
        _random.shuffle(self._pool)
        self._shown_ids.clear()

        # Track usage for auto-suggestion
        try:
            self.db.motivation_log_usage(self.current_user_id, situation_id)
        except Exception:
            pass

        self._current_quote = self._pick_next()
        if self._current_quote:
            self._show_quote_screen()
        else:
            self._show_toast("No quotes found for this situation.", color=_MM_ACCENT)

    # ── Pick next quote (repeat-avoid) ────────────────────────────────────
    def _pick_next(self):
        if not self._pool:
            return None
        candidates = [q for q in self._pool
                      if q["id"] not in self._shown_ids[-REPEAT_WINDOW:]]
        if not candidates:
            self._shown_ids.clear()
            candidates = self._pool[:]
        chosen = _random.choice(candidates)
        self._shown_ids.append(chosen["id"])
        return chosen

    # ── 3. Quote Screen ───────────────────────────────────────────────────
    def _show_quote_screen(self):
        self._clear_content()
        sit = self._get_situation_by_id(self._current_situation)
        sit_color = sit["color"] if sit else _MM_ACCENT
        sit_label = sit["label"] if sit else "Motivation"

        # Situation label
        tk.Label(self._content, text=sit_label,
                 bg=_MM_BG, fg=sit_color,
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=16, pady=(10, 2))

        # Quote card frame
        card = tk.Frame(self._content, bg=_MM_CARD, padx=20, pady=16)
        card.pack(fill="x", padx=16, pady=6)

        # Top accent bar
        self._card_bar = tk.Frame(card, bg=sit_color, height=3)
        self._card_bar.pack(fill="x", pady=(0, 12))

        # Opening quote mark
        tk.Label(card, text="\u201c", bg=_MM_CARD, fg=sit_color,
                 font=("Georgia", 32)).pack(anchor="w")

        # English text
        self._en_var = tk.StringVar()
        tk.Label(card, textvariable=self._en_var,
                 bg=_MM_CARD, fg=_MM_TEXT,
                 font=("Georgia", 12, "italic"),
                 wraplength=580, justify="left").pack(fill="x", pady=(0, 10))

        # Telugu text
        self._te_var = tk.StringVar()
        tk.Label(card, textvariable=self._te_var,
                 bg=_MM_CARD, fg=_MM_TEXT2,
                 font=("Segoe UI", 10),
                 wraplength=580, justify="left").pack(fill="x", pady=(0, 10))

        # Source + category
        self._src_var = tk.StringVar()
        self._src_lbl = tk.Label(card, textvariable=self._src_var,
                                  bg=_MM_CARD, fg=_MM_GOLD,
                                  font=("Segoe UI", 8, "italic"), anchor="e")
        self._src_lbl.pack(fill="x")

        # Quote ID
        self._qid_var = tk.StringVar()
        tk.Label(self._content, textvariable=self._qid_var,
                 bg=_MM_BG, fg=_MM_MUTED,
                 font=("Segoe UI", 8)).pack(anchor="e", padx=20)

        self._update_quote_display()

        # ── Action buttons row 1 ──────────────────────────────────────────
        btn1 = tk.Frame(self._content, bg=_MM_BG)
        btn1.pack(pady=(8, 2))

        self._save_btn = tk.Button(btn1, text="❤️ Save",
                                    font=("Segoe UI", 10, "bold"),
                                    bg=_MM_GOLD, fg="#000000",
                                    bd=0, padx=14, pady=6, cursor="hand2",
                                    command=self._toggle_save)
        self._save_btn.pack(side="left", padx=5)

        tk.Button(btn1, text="➡️ Next Quote",
                  font=("Segoe UI", 10, "bold"),
                  bg=_MM_GREEN, fg="white",
                  bd=0, padx=14, pady=6, cursor="hand2",
                  command=self._next_quote).pack(side="left", padx=5)

        tk.Button(btn1, text="🔊 Voice",
                  font=("Segoe UI", 10),
                  bg=_MM_TEAL, fg="white",
                  bd=0, padx=14, pady=6, cursor="hand2",
                  command=self._speak_quote).pack(side="left", padx=5)

        # ── Action buttons row 2 ──────────────────────────────────────────
        btn2 = tk.Frame(self._content, bg=_MM_BG)
        btn2.pack(pady=(2, 8))

        tk.Button(btn2, text="🔄 Change Mode",
                  font=("Segoe UI", 10),
                  bg=_MM_PURPLE, fg="white",
                  bd=0, padx=14, pady=6, cursor="hand2",
                  command=self._show_situation_picker).pack(side="left", padx=5)

        tk.Button(btn2, text="❤️ Saved Quotes",
                  font=("Segoe UI", 10),
                  bg=_MM_ACCENT2, fg=_MM_GOLD,
                  bd=0, padx=14, pady=6, cursor="hand2",
                  command=self._open_saved).pack(side="left", padx=5)

        tk.Button(btn2, text="❌ Exit",
                  font=("Segoe UI", 10),
                  bg=_MM_ACCENT, fg="white",
                  bd=0, padx=14, pady=6, cursor="hand2",
                  command=self._confirm_exit).pack(side="left", padx=5)

    def _update_quote_display(self):
        q = self._current_quote
        if not q:
            return
        self._en_var.set(f"\u201c{q['text_en']}\u201d")
        self._te_var.set(q["text_te"])
        saved = self._is_saved(q)
        self._src_var.set(
            f"— {q['source']}  [{q['category']}]" + ("  ❤️" if saved else "")
        )
        self._qid_var.set(f"#{q['id']}")
        # Update save button label
        if hasattr(self, '_save_btn') and self._save_btn.winfo_exists():
            self._save_btn.config(text="💔 Unsave" if saved else "❤️ Save")

    # ── Quote actions ─────────────────────────────────────────────────────
    def _next_quote(self):
        q = self._pick_next()
        if not q:
            self._show_toast("All quotes shown! Reshuffling…", color=_MM_PURPLE)
            return
        self._current_quote = q
        self._update_quote_display()

    def _toggle_save(self):
        if not self._current_quote:
            return
        qid = self._current_quote["id"]
        if self._is_saved(self._current_quote):
            try:
                self.db.motivation_unsave_quote(self.current_user_id, qid)
            except Exception:
                pass
            self._show_toast("Removed from saved.", color=_MM_ACCENT)
        else:
            try:
                self.db.motivation_save_quote(self.current_user_id, qid)
            except Exception:
                pass
            self._show_toast("Quote saved! ❤️", color=_MM_GOLD)
        self._update_quote_display()

    def _is_saved(self, quote) -> bool:
        try:
            return self.db.motivation_is_saved(self.current_user_id, quote["id"])
        except Exception:
            return False

    def _speak_quote(self):
        if not self._current_quote:
            return
        text = self._current_quote["text_en"]
        self._show_toast("🔊 Speaking…", color=_MM_TEAL)
        self.after(100, lambda: self._do_speak(text))

    @staticmethod
    def _do_speak(text: str):
        try:
            import pyttsx3
            engine = pyttsx3.init()
            engine.say(text)
            engine.runAndWait()
        except Exception:
            pass   # pyttsx3 not installed — silently skip

    # ── Saved Quotes viewer ───────────────────────────────────────────────
    def _open_saved(self):
        try:
            saved_ids = self.db.motivation_get_saved_quote_ids(self.current_user_id)
        except Exception:
            saved_ids = []

        from database import QUOTES as _ALL_QUOTES
        saved_quotes = [q for q in _ALL_QUOTES if q["id"] in saved_ids]

        dlg = tk.Toplevel(self)
        dlg.title("❤️ Saved Quotes")
        dlg.geometry("600x480")
        dlg.configure(bg=_MM_BG)
        dlg.grab_set()

        # Header
        hdr = tk.Frame(dlg, bg=_MM_CARD, pady=10)
        hdr.pack(fill="x")
        tk.Label(hdr, text=f"❤️  Saved Quotes  ({len(saved_quotes)})",
                 bg=_MM_CARD, fg=_MM_GOLD,
                 font=("Georgia", 14, "bold")).pack()

        if not saved_quotes:
            tk.Label(dlg, text="No saved quotes yet.\nPress ❤️ Save on any quote to save it!",
                     bg=_MM_BG, fg=_MM_TEXT2,
                     font=("Segoe UI", 11), justify="center").pack(expand=True)
        else:
            # Scrollable list
            outer = tk.Frame(dlg, bg=_MM_BG)
            outer.pack(fill="both", expand=True, padx=8, pady=8)

            canvas = tk.Canvas(outer, bg=_MM_BG, highlightthickness=0)
            sb = tk.Scrollbar(outer, orient="vertical", command=canvas.yview)
            inner = tk.Frame(canvas, bg=_MM_BG)
            inner.bind("<Configure>",
                       lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
            canvas.create_window((0, 0), window=inner, anchor="nw")
            canvas.configure(yscrollcommand=sb.set)
            canvas.pack(side="left", fill="both", expand=True)
            sb.pack(side="right", fill="y")

            for q in saved_quotes:
                row = tk.Frame(inner, bg=_MM_CARD, padx=12, pady=8)
                row.pack(fill="x", pady=4, padx=4)

                tk.Label(row, text=f"\u201c{q['text_en']}\u201d",
                         bg=_MM_CARD, fg=_MM_TEXT,
                         font=("Georgia", 10, "italic"),
                         wraplength=480, justify="left", anchor="w").pack(fill="x")
                tk.Label(row, text=q["text_te"],
                         bg=_MM_CARD, fg=_MM_TEXT2,
                         font=("Segoe UI", 9),
                         wraplength=480, justify="left", anchor="w").pack(fill="x")
                tk.Label(row, text=f"— {q['source']}  [{q['category']}]",
                         bg=_MM_CARD, fg=_MM_GOLD,
                         font=("Segoe UI", 8, "italic"), anchor="e").pack(fill="x")

                def _remove(qid=q["id"], r=row, d=dlg):
                    try:
                        self.db.motivation_unsave_quote(self.current_user_id, qid)
                    except Exception:
                        pass
                    r.destroy()

                tk.Button(row, text="Remove", font=("Segoe UI", 8, "bold"),
                          bg="#C0392B", fg="white", bd=0, padx=8, pady=3,
                          cursor="hand2", command=_remove).pack(anchor="e", pady=(4, 0))

        tk.Button(dlg, text="Close", font=("Segoe UI", 10, "bold"),
                  bg=_MM_ACCENT2, fg="white", bd=0, pady=8,
                  cursor="hand2", command=dlg.destroy).pack(fill="x", padx=16, pady=8)

    # ── Exit confirmation ─────────────────────────────────────────────────
    def _confirm_exit(self):
        msg = _random.choice(_EXIT_MSGS)

        dlg = tk.Toplevel(self)
        dlg.title("")
        dlg.configure(bg=_MM_CARD)
        dlg.geometry("320x160")
        dlg.resizable(False, False)
        dlg.grab_set()
        dlg.overrideredirect(True)

        # Centre over popup
        self.update_idletasks()
        px = self.winfo_rootx() + self.winfo_width()  // 2 - 160
        py = self.winfo_rooty() + self.winfo_height() // 2 - 80
        dlg.geometry(f"+{px}+{py}")

        tk.Frame(dlg, bg=_MM_ACCENT, height=3).pack(fill="x")
        tk.Label(dlg, text="Leaving Motivation Mode?",
                 bg=_MM_CARD, fg=_MM_TEXT,
                 font=("Segoe UI", 12, "bold"), pady=10).pack()
        tk.Label(dlg, text=msg,
                 bg=_MM_CARD, fg=_MM_GOLD,
                 font=("Segoe UI", 10)).pack()

        btn_row = tk.Frame(dlg, bg=_MM_CARD)
        btn_row.pack(pady=14)

        def _yes():
            dlg.destroy()
            self.destroy()

        tk.Button(btn_row, text="Yes, Exit", font=("Segoe UI", 10, "bold"),
                  bg=_MM_ACCENT, fg="white", bd=0, padx=12, pady=6,
                  cursor="hand2", command=_yes).pack(side="left", padx=8)
        tk.Button(btn_row, text="Stay", font=("Segoe UI", 10),
                  bg=_MM_ACCENT2, fg="white", bd=0, padx=12, pady=6,
                  cursor="hand2", command=dlg.destroy).pack(side="left", padx=8)

    # ── Toast notification ────────────────────────────────────────────────
    def _show_toast(self, message: str, color: str = _MM_GREEN, duration: int = 2000):
        toast = tk.Frame(self._content, bg=color, padx=14, pady=6)
        tk.Label(toast, text=message, bg=color, fg="white",
                 font=("Segoe UI", 9, "bold")).pack()
        toast.place(relx=0.5, rely=0.97, anchor="s")
        self.after(duration, lambda: toast.destroy() if toast.winfo_exists() else None)


# ==================== CHAT ANALYTICS POPUP ====================
# --- 23. CHAT ANALYTICS POPUP ---

class ChatAnalyticsPopup(tk.Toplevel):
    """
    Chat Analytics — user chat data analyze chesi report chupistundi.
    Features:
      - Top 5 contacts (message count)
      - Daily & weekly chat time + peak hour
      - Top 5 most used words
      - Mood / tone analysis (positive/negative/neutral)
      - Mental health insight
      - Smart insights + weekly summary
    """

    # Common stop words to filter out
    _STOP_WORDS = {
        "the","is","are","i","you","a","an","and","or","but","in","on","at",
        "to","for","of","with","it","this","that","was","be","have","do",
        "he","she","we","they","my","your","his","her","our","their","me",
        "him","us","them","what","how","when","where","who","which","will",
        "can","could","would","should","may","might","shall","not","no","yes",
        "ok","okay","hi","hello","hey","bye","thanks","thank","please","sorry",
        "ha","haha","lol","oh","ah","hmm","yeah","yep","nope","nah","just",
        "so","if","as","by","up","out","about","from","into","than","then",
        "its","it's","i'm","i'll","i've","don't","can't","won't","isn't",
        "aren't","wasn't","weren't","didn't","doesn't","hasn't","haven't",
        "na","ga","ki","lo","ni","ee","aa","oka","undi","chey","chestanu",
        "ante","ila","ela","em","emi","enti","ento","kuda","mee","nee","nenu",
        "meeru","meru","avutundi","ayyindi","chesanu","chestunnanu","ledu",
        "unnanu","unna","undi","unte","aithe","kadha","kada","ra","re","da",
    }

    # Positive / negative word sets for mood analysis
    _POSITIVE_WORDS = {
        "good","great","happy","love","awesome","excellent","wonderful","nice",
        "thanks","thank","glad","joy","best","amazing","fantastic","perfect",
        "yes","sure","okay","ok","fine","cool","wow","yay","super","brilliant",
        "beautiful","sweet","kind","helpful","fun","enjoy","excited","proud",
        "hope","smile","laugh","haha","lol","😊","😄","❤️","👍","🎉","✨",
        "baagundi","manchidi","happy","sukham","anandham","chala","super",
    }
    _NEGATIVE_WORDS = {
        "bad","sad","hate","angry","terrible","awful","horrible","worst",
        "no","not","never","problem","issue","fail","failed","wrong","sorry",
        "miss","lost","hurt","pain","cry","tired","bored","stress","worried",
        "upset","frustrated","annoyed","disappointed","depressed","lonely",
        "😢","😭","😠","😞","💔","😔","😤","🙁",
        "chedduga","kastam","baadha","problem","ledu","kadu","vaddu",
    }

    def __init__(self, parent, current_user_id, current_username, db):
        super().__init__(parent)
        self.title("📊 Chat Analytics")
        self.geometry("750x620")
        self.minsize(680, 560)
        self.configure(bg="#0d1117")
        self.resizable(True, True)

        self.current_user_id   = current_user_id
        self.current_username  = current_username
        self.db                = db

        self._build_ui()

    # ── Build UI ──────────────────────────────────────────────────────────
    def _build_ui(self):
        # Header
        hdr = tk.Frame(self, bg="#161b22", pady=12)
        hdr.pack(fill="x")
        tk.Label(hdr, text="📊  Chat Analytics",
                 bg="#161b22", fg="#58a6ff",
                 font=("Georgia", 15, "bold")).pack(side="left", padx=16)
        tk.Label(hdr, text=f"Report for: {self.current_username}",
                 bg="#161b22", fg="#8b949e",
                 font=("Segoe UI", 9)).pack(side="left", padx=8)
        tk.Button(hdr, text="✕ Close", font=("Segoe UI", 9, "bold"),
                  bg="#21262d", fg="#f85149", bd=0, padx=10, pady=4,
                  cursor="hand2", command=self.destroy).pack(side="right", padx=12)
        tk.Frame(self, bg="#30363d", height=1).pack(fill="x")

        # Loading label
        self._loading_lbl = tk.Label(self, text="⏳ Analyzing your chats…",
                                      bg="#0d1117", fg="#8b949e",
                                      font=("Segoe UI", 12))
        self._loading_lbl.pack(expand=True)

        # Run analysis after window renders
        self.after(100, self._run_analysis)

    def _run_analysis(self):
        """Fetch data, compute analytics, render report."""
        try:
            messages  = self.db.get_analytics_messages(self.current_user_id)
            contacts  = self.db.get_analytics_contacts(self.current_user_id)
        except Exception as e:
            self._loading_lbl.config(text=f"Error loading data: {e}")
            return

        if not messages:
            self._loading_lbl.config(
                text="No chat data found yet.\nStart chatting to see your analytics! 💬"
            )
            return

        self._loading_lbl.destroy()

        # Compute all analytics
        top_contacts   = self._compute_top_contacts(contacts)
        time_stats     = self._compute_time_stats(messages)
        top_words      = self._compute_top_words(messages)
        mood_stats     = self._compute_mood(messages)
        insights       = self._compute_insights(messages, contacts, time_stats, mood_stats)

        # Render scrollable report
        self._render_report(top_contacts, time_stats, top_words, mood_stats, insights)

    # ── Analytics computations ────────────────────────────────────────────

    def _compute_top_contacts(self, contacts):
        """Top 5 contacts by total message count."""
        result = []
        for row in contacts[:5]:
            cid, uname, sent, received = row
            total = (sent or 0) + (received or 0)
            result.append({"name": uname, "sent": sent or 0,
                            "received": received or 0, "total": total})
        return result

    def _compute_time_stats(self, messages):
        """
        Session-based time calculation.
        Gap < 5 min → same session.
        Returns dict with daily_avg_min, weekly_avg_min, peak_period, total_messages.
        """
        from datetime import datetime as dt, timedelta

        timestamps = []
        for row in messages:
            try:
                ts = dt.strptime(row[3], "%Y-%m-%d %H:%M:%S")
                timestamps.append(ts)
            except Exception:
                pass

        if not timestamps:
            return {"daily_avg_min": 0, "weekly_avg_min": 0,
                    "peak_period": "Unknown", "total_messages": len(messages),
                    "total_days": 0}

        timestamps.sort()

        # Session calculation
        session_minutes = 0
        session_start   = timestamps[0]
        prev            = timestamps[0]

        for ts in timestamps[1:]:
            gap = (ts - prev).total_seconds() / 60
            if gap > 5:
                session_minutes += (prev - session_start).total_seconds() / 60 + 1
                session_start = ts
            prev = ts
        session_minutes += (prev - session_start).total_seconds() / 60 + 1

        # Days span
        first_day = timestamps[0].date()
        last_day  = timestamps[-1].date()
        total_days = max((last_day - first_day).days + 1, 1)
        total_weeks = max(total_days / 7, 1)

        daily_avg  = round(session_minutes / total_days, 1)
        weekly_avg = round(session_minutes / total_weeks, 1)

        # Peak period
        hours = [ts.hour for ts in timestamps]
        morning   = sum(1 for h in hours if 5  <= h < 12)
        afternoon = sum(1 for h in hours if 12 <= h < 17)
        evening   = sum(1 for h in hours if 17 <= h < 21)
        night     = sum(1 for h in hours if h >= 21 or h < 5)
        peak_map  = {"Morning 🌅": morning, "Afternoon ☀️": afternoon,
                     "Evening 🌆": evening, "Night 🌙": night}
        peak_period = max(peak_map, key=peak_map.get)

        return {
            "daily_avg_min":  daily_avg,
            "weekly_avg_min": weekly_avg,
            "peak_period":    peak_period,
            "total_messages": len(messages),
            "total_days":     total_days,
        }

    def _compute_top_words(self, messages):
        """Top 5 most used words after stop-word removal."""
        import re
        from collections import Counter

        word_counts = Counter()
        for row in messages:
            text = row[2] or ""
            # Keep only alphabetic words
            words = re.findall(r"[a-zA-Z\u0C00-\u0C7F]+", text.lower())
            for w in words:
                if w not in self._STOP_WORDS and len(w) > 2:
                    word_counts[w] += 1

        return word_counts.most_common(5)

    def _compute_mood(self, messages):
        """
        Simple keyword-based mood analysis.
        Returns dict with overall, positive_pct, negative_pct, neutral_pct,
        weekly_summary, negative_peak_period.
        """
        from collections import defaultdict
        from datetime import datetime as dt

        pos_total = neg_total = neu_total = 0
        weekly_mood = defaultdict(lambda: {"pos": 0, "neg": 0, "neu": 0})
        hour_neg    = defaultdict(int)

        for row in messages:
            # Only sent messages for mood (user's own words)
            if row[0] != self.current_user_id:
                continue
            text  = (row[2] or "").lower()
            words = set(text.split())

            pos = bool(words & self._POSITIVE_WORDS)
            neg = bool(words & self._NEGATIVE_WORDS)

            try:
                ts   = dt.strptime(row[3], "%Y-%m-%d %H:%M:%S")
                week = ts.strftime("Week of %b %d")
                hour_neg[ts.hour] += (1 if neg else 0)
            except Exception:
                week = "Unknown"

            if pos and not neg:
                pos_total += 1
                weekly_mood[week]["pos"] += 1
            elif neg and not pos:
                neg_total += 1
                weekly_mood[week]["neg"] += 1
            else:
                neu_total += 1
                weekly_mood[week]["neu"] += 1

        total = pos_total + neg_total + neu_total or 1
        pos_pct = round(pos_total / total * 100)
        neg_pct = round(neg_total / total * 100)
        neu_pct = 100 - pos_pct - neg_pct

        if pos_pct >= neg_pct and pos_pct >= neu_pct:
            overall = "Positive 😊"
        elif neg_pct >= pos_pct and neg_pct >= neu_pct:
            overall = "Negative 😔"
        else:
            overall = "Neutral 😐"

        # Negative peak hour → period
        if hour_neg:
            peak_h = max(hour_neg, key=hour_neg.get)
            if 5 <= peak_h < 12:
                neg_peak = "Morning"
            elif 12 <= peak_h < 17:
                neg_peak = "Afternoon"
            elif 17 <= peak_h < 21:
                neg_peak = "Evening"
            else:
                neg_peak = "Night"
        else:
            neg_peak = "N/A"

        # Weekly summary — last 4 weeks
        weekly_summary = []
        for week, counts in sorted(weekly_mood.items())[-4:]:
            w_total = counts["pos"] + counts["neg"] + counts["neu"] or 1
            if counts["pos"] >= counts["neg"]:
                mood_label = "😊 Positive"
            elif counts["neg"] > counts["pos"]:
                mood_label = "😔 Negative"
            else:
                mood_label = "😐 Neutral"
            weekly_summary.append(f"{week}: {mood_label}")

        return {
            "overall":       overall,
            "positive_pct":  pos_pct,
            "negative_pct":  neg_pct,
            "neutral_pct":   neu_pct,
            "weekly_summary": weekly_summary,
            "neg_peak":      neg_peak,
        }

    def _compute_insights(self, messages, contacts, time_stats, mood_stats):
        """Generate smart insights and mental health tips."""
        insights = []
        tips     = []

        # Peak time insight
        insights.append(f"You are mostly active during {time_stats['peak_period']}.")

        # Top contact insight
        if contacts:
            top_name = contacts[0][1]
            insights.append(f"You spend the most time chatting with {top_name}.")

        # High chat time warning
        daily = time_stats["daily_avg_min"]
        if daily > 120:
            tips.append("⚠️ You chat more than 2 hours daily. Consider taking breaks.")
        elif daily > 60:
            tips.append("💡 You chat about 1 hour daily — a healthy amount!")
        else:
            tips.append("✅ Your daily chat time looks balanced.")

        # Negative mood warning
        neg_pct = mood_stats["negative_pct"]
        if neg_pct > 40:
            tips.append(f"⚠️ {neg_pct}% of your messages show negative tone. "
                        f"Negative mood is higher during {mood_stats['neg_peak']}. "
                        "Try talking to someone you trust or take a short break.")
        elif neg_pct > 20:
            tips.append(f"💛 Some negativity detected ({neg_pct}%). "
                        "It's okay — everyone has tough days. Stay kind to yourself.")
        else:
            tips.append("💚 Your overall tone is healthy and positive. Keep it up!")

        # Total messages insight
        total = time_stats["total_messages"]
        if total > 1000:
            insights.append(f"You've exchanged {total:,} messages — you're very active!")
        elif total > 200:
            insights.append(f"You've exchanged {total:,} messages so far.")

        return {"insights": insights, "tips": tips}

    # ── Render report ─────────────────────────────────────────────────────

    def _render_report(self, top_contacts, time_stats, top_words, mood_stats, insights):
        """Build the scrollable report UI."""
        # Scrollable container
        outer = tk.Frame(self, bg="#0d1117")
        outer.pack(fill="both", expand=True)

        canvas = tk.Canvas(outer, bg="#0d1117", highlightthickness=0)
        sb = tk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        report = tk.Frame(canvas, bg="#0d1117")
        report.bind("<Configure>",
                    lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=report, anchor="nw")
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        # Mouse wheel scroll — winfo_exists check prevents error after popup closes
        def _on_mousewheel(event):
            try:
                if canvas.winfo_exists():
                    canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            except Exception:
                pass

        canvas.bind_all("<MouseWheel>", _on_mousewheel)
        # Unbind when popup is destroyed
        self.bind("<Destroy>", lambda e: canvas.unbind_all("<MouseWheel>") if e.widget is self else None)

        pad = {"padx": 16, "pady": 6}

        # ── Section helper ────────────────────────────────────────────────
        def section(title, color="#58a6ff"):
            f = tk.Frame(report, bg="#161b22", pady=8)
            f.pack(fill="x", **pad)
            tk.Label(f, text=title, bg="#161b22", fg=color,
                     font=("Segoe UI", 11, "bold"), padx=12).pack(anchor="w")
            tk.Frame(f, bg=color, height=1).pack(fill="x", padx=12, pady=(2, 0))
            return f

        def row_label(parent, text, value, val_color="#c9d1d9"):
            r = tk.Frame(parent, bg="#161b22")
            r.pack(fill="x", padx=12, pady=2)
            tk.Label(r, text=text, bg="#161b22", fg="#8b949e",
                     font=("Segoe UI", 10), width=28, anchor="w").pack(side="left")
            tk.Label(r, text=str(value), bg="#161b22", fg=val_color,
                     font=("Segoe UI", 10, "bold"), anchor="w").pack(side="left")

        def plain_label(parent, text, color="#c9d1d9"):
            tk.Label(parent, text=text, bg="#161b22", fg=color,
                     font=("Segoe UI", 10), padx=12, pady=2,
                     wraplength=660, justify="left", anchor="w").pack(fill="x")

        # ── 1. Top Contacts ───────────────────────────────────────────────
        sec = section("👥  Top Contacts")
        if top_contacts:
            for i, c in enumerate(top_contacts, 1):
                row_label(sec, f"  #{i}  {c['name']}",
                          f"{c['total']} msgs  (↑{c['sent']} sent  ↓{c['received']} received)",
                          "#79c0ff")
        else:
            plain_label(sec, "No contact data available yet.")

        # ── 2. Chat Time ──────────────────────────────────────────────────
        sec2 = section("⏱️  Daily & Weekly Chat Time", "#3fb950")
        row_label(sec2, "  Total messages:",    f"{time_stats['total_messages']:,}", "#3fb950")
        row_label(sec2, "  Days tracked:",      f"{time_stats['total_days']}", "#3fb950")
        row_label(sec2, "  Daily avg chat:",    f"{time_stats['daily_avg_min']} min", "#3fb950")
        row_label(sec2, "  Weekly avg chat:",   f"{time_stats['weekly_avg_min']} min", "#3fb950")
        row_label(sec2, "  Peak chatting time:", time_stats['peak_period'], "#ffa657")

        # ── 3. Top Words ──────────────────────────────────────────────────
        sec3 = section("💬  Top 5 Most Used Words", "#d2a8ff")
        if top_words:
            for rank, (word, count) in enumerate(top_words, 1):
                row_label(sec3, f"  #{rank}  \"{word}\"", f"{count} times", "#d2a8ff")
        else:
            plain_label(sec3, "Not enough text data yet.")

        # ── 4. Mood Analysis ──────────────────────────────────────────────
        mood_color = "#3fb950" if "Positive" in mood_stats["overall"] else \
                     "#f85149" if "Negative" in mood_stats["overall"] else "#e3b341"
        sec4 = section("😊  Mood / Tone Analysis", mood_color)
        row_label(sec4, "  Overall mood:",      mood_stats["overall"],       mood_color)
        row_label(sec4, "  Positive messages:", f"{mood_stats['positive_pct']}%", "#3fb950")
        row_label(sec4, "  Negative messages:", f"{mood_stats['negative_pct']}%", "#f85149")
        row_label(sec4, "  Neutral messages:",  f"{mood_stats['neutral_pct']}%",  "#8b949e")
        row_label(sec4, "  Negative peak time:", mood_stats["neg_peak"],     "#ffa657")

        if mood_stats["weekly_summary"]:
            plain_label(sec4, "  Weekly Mood Summary:", "#8b949e")
            for line in mood_stats["weekly_summary"]:
                plain_label(sec4, f"    • {line}")

        # ── 5. Mental Health Insights ─────────────────────────────────────
        sec5 = section("💚  Mental Health Insights", "#3fb950")
        for tip in insights["tips"]:
            plain_label(sec5, f"  {tip}")

        # ── 6. Smart Insights ─────────────────────────────────────────────
        sec6 = section("✨  Smart Insights", "#ffa657")
        for insight in insights["insights"]:
            plain_label(sec6, f"  • {insight}")

        # ── 7. Weekly Summary ─────────────────────────────────────────────
        sec7 = section("📋  Weekly Report Summary", "#58a6ff")
        top_name = top_contacts[0]["name"] if top_contacts else "N/A"
        top_word = top_words[0][0] if top_words else "N/A"
        row_label(sec7, "  Most chatted person:", top_name,                    "#79c0ff")
        row_label(sec7, "  Daily avg chat time:", f"{time_stats['daily_avg_min']} min", "#3fb950")
        row_label(sec7, "  Top used word:",       f"\"{top_word}\"",           "#d2a8ff")
        row_label(sec7, "  Overall mood:",        mood_stats["overall"],       mood_color)
        row_label(sec7, "  Peak active time:",    time_stats["peak_period"],   "#ffa657")

        # Bottom padding
        tk.Frame(report, bg="#0d1117", height=20).pack()

